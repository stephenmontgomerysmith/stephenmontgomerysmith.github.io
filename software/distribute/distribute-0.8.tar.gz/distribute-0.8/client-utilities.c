/*
 * Copyright (c) 2001 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <distribute.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdarg.h>
#include <sys/time.h>
#include <sys/resource.h>

#define RETRY { \
    if (server!=NULL) fclose(server); \
    retry_count++; \
    success = 0; \
    goto retry; \
  }

void get_client_data(char **input, char *hostname, int port_nr,
                     char *password) {
  FILE *server;
  int retry_count=0, success;

  retry:
/* retry every minute up to 2 days. */
  if (retry_count>2*24*60) exit(1);
  if (retry_count>0) sleep(60);

  if ((server=connect_to_server(hostname,port_nr))==NULL) RETRY
  setlinebuf(server);
  if (fputs("request data\r\n",server)<0) RETRY
  if (fputs(password,server)<0) RETRY
  if (fgetstring(input,server)==NULL) RETRY
  rn2n(input);
  if (strcmp(*input,"No data\n")==0) RETRY
  fclose(server);
}

void send_client_data(char *input, char *output, char *hostname, int port_nr,
                      char *password) {
  FILE *server;
  int retry_count=0, success;
  char *in2=NULL, *out2=NULL;

  strcpyalloc(&in2,input);
  strcpyalloc(&out2,output);
  n2rn(&in2);
  n2rn(&out2);
  retry:
/* retry every minute up to 2 days. */
  if (retry_count>2*24*60) exit(1);
  if (retry_count>0) sleep(60);

  if ((server=connect_to_server(hostname,port_nr))==NULL) RETRY
  setlinebuf(server);
  if (fputs("sending data\r\n",server)<0) goto end;
  if (fputs(password,server)<0) goto end;
  if (fputs(in2,server)<0) goto end;
  if (fputs(out2,server)<0) goto end;
end:
  if (in2==NULL) free(in2);
  if (out2==NULL) free(out2);
  fclose(server);
}

void get_client_arguments(int argc, char **argv,
                          char **password, char **hostname, int *port_nr,
                          int nr_extra, ...) {
  int i=1;
  int foreground = 0;
  int nice = 20;
  int error = 0;
  int n;
  char **arg_descr, ***arg_ptr;
  va_list ap;

  if ((arg_descr=malloc(nr_extra*sizeof(char*)))==NULL ||
      (arg_ptr=malloc(nr_extra*sizeof(char**)))==NULL) {
    fprintf(stderr,"Allocation error\n");
    exit(1);
  }
  va_start(ap,nr_extra);
  for (n=0;n<nr_extra;n++)
    if ((arg_descr[n] = va_arg(ap,char*))==NULL ||
        (arg_ptr[n] = va_arg(ap,char**))==NULL) {
      fprintf(stderr,"Internal error\n");
      exit(1);
    }
  va_end(ap);

  while (i<argc && !error) {
    if (strcmp(argv[i],"-f")==0) {
      foreground = 1;
      i++;
    } else if (strncmp(argv[i],"-n",2)==0) {
      if (strlen(argv[i])==2) {
        if (i+1<argc) {
          nice = atoi(argv[i+1]);
          i+=2;
        }
        else error = 1;
      } else {
        nice = atoi(argv[i]+2);
        i++;
      }
    } else break;
  }

  for (n=0;n<nr_extra && !error;n++)
    if (i<argc) {
      *(arg_ptr[n]) = argv[i];
      i++;
    }
    else error = 1;

  *password = NULL;
  if (i<argc) {
    strcpyalloc(password,argv[i]);
    if ((*password = realloc(*password,strlen(*password)+2))==NULL) {
      fprintf(stderr,"Allocation error\n");
      exit(1);
    }
    strcat(*password,"\r\n");
    i++;
  }
  else error = 1;

  if (i<argc) {
    *hostname = argv[i];
    i++;
  }
  else error = 1;

  if (i<argc) {
    *port_nr = atoi(argv[i]);
    i++;
  }
  else error = 1;

  if (error || i!=argc) {
    i=strlen(argv[0])-1;
    while(i>=0 && argv[0][i]!='/') i--;
    fprintf(stderr,"usage: %s [-f] [-n number]",argv[0]+i+1);
    for (n=0;n<nr_extra;n++)
      fprintf(stderr," %s",arg_descr[n]);
    fprintf(stderr," password hostname port\n");
    exit(1);
  }

  if (setpriority(PRIO_PROCESS,0,nice)<0) {
    fprintf(stderr,"Cannot set nice level\n");
    exit(1);
  }
  if (!foreground) daemon(1,0);

  free(arg_descr);
  free(arg_ptr);
}
