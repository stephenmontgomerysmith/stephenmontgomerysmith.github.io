/*
 * Copyright (c) 2001 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>

pid_t *child_list=NULL, nr_children=0;

static void sig_chld(int signo) {
  pid_t pid;
  int stat,i;
  int die = 0;
  char message[] = "Cannot open program\n";

  while ((pid=waitpid(-1,&stat,WNOHANG))>0)
    if (!WIFSTOPPED(stat)) {
      if (WIFEXITED(stat) && WEXITSTATUS(stat)==127)
        write(STDERR_FILENO,message,sizeof(message)-1);
      die = 1;
      for (i=0;i<nr_children;i++)
        if (child_list[i]==pid)
          child_list[i] = -1;
    }
  if (die) exit(1);
}

static void sig_exit(int signo) {
  char message[] = "Terminated\n";
  write(STDERR_FILENO,message,sizeof(message)-1);
  exit(1);
}

static void kill_children() {
  int i;
  
  for (i=0;i<nr_children;i++) if (child_list[i]>0) {
    killpg(child_list[i], SIGTERM);
    child_list[i] = -1;
  }
}

int bipipe(FILE **from_prog, FILE **to_prog, char *program_name) {
  int out_pipe[2] = {-1,-1};
  int in_pipe[2] = {-1,-1};
  int nullfd = -1;
  pid_t pid;

  *to_prog = NULL;
  *from_prog = NULL;

  if ((nullfd = open("/dev/null",O_RDWR))<0) goto error;
  if (pipe(out_pipe)<0) goto error;
  if (pipe(in_pipe)<0) goto error;

  signal(SIGCHLD, sig_chld);
  signal(SIGHUP, sig_exit);
  signal(SIGINT, sig_exit);
  signal(SIGQUIT, sig_exit);
  signal(SIGILL, sig_exit);
  signal(SIGTRAP, sig_exit);
  signal(SIGABRT, sig_exit);
  signal(SIGFPE, sig_exit);
  signal(SIGBUS, sig_exit);
  signal(SIGSEGV, sig_exit);
  signal(SIGSYS, sig_exit);
  signal(SIGPIPE, sig_exit);
  signal(SIGALRM, sig_exit);
  signal(SIGTERM, sig_exit);
  signal(SIGXCPU, sig_exit);
  signal(SIGXFSZ, sig_exit);
  signal(SIGVTALRM, sig_exit);
  signal(SIGPROF, sig_exit);
  signal(SIGUSR1, sig_exit);
  signal(SIGUSR2, sig_exit);
  atexit(kill_children);

  if ((pid=fork())<0) goto error;
  else if (pid==0) {
    if (setpgid(0,getpid())>=0 &&
        dup2(out_pipe[1],STDOUT_FILENO)>=0 &&
        dup2(nullfd,STDERR_FILENO)>=0 &&
        dup2(in_pipe[0],STDIN_FILENO)>=0);
      execlp("/bin/sh","sh","-c",program_name,NULL);
    _exit(127);
  }

  nr_children++;
  if ((child_list = realloc(child_list,nr_children*sizeof(pid_t)))==NULL) {
    kill(pid,SIGTERM);
    fprintf(stderr,"Allocation error\n");
    exit(1);
  }
  child_list[nr_children-1] = pid;
  if (setpgid(pid,pid)<0) goto error;
  *from_prog = fdopen(out_pipe[0],"r");
  *to_prog = fdopen(in_pipe[1],"w");
  if (*from_prog==NULL || *to_prog==NULL) goto error;
  setlinebuf(*to_prog);
  return 0;

error:
  if (*from_prog!=NULL)
    fclose(*from_prog);
  else
    if (out_pipe[0]>=0) close(out_pipe[0]);
  if (*to_prog!=NULL)
    fclose(*to_prog);
  else
    if (in_pipe[1]>=0) close(in_pipe[1]);
  if (out_pipe[1]>=0) close(out_pipe[1]);
  if (in_pipe[0]>=0) close(in_pipe[0]);
  if (nullfd>=0) close(nullfd);
  return -1;
}
