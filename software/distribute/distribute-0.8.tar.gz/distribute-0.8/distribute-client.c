/*
 * Copyright (c) 2001 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <distribute.h>

int main(int argc, char **argv) {
  char *input=NULL, *output=NULL;
  FILE *from_prog, *to_prog;
  char *program_name;
  char *password;
  char *hostname;
  int port_nr;

  get_client_arguments(argc,argv,&password,&hostname,&port_nr,
                       1,"program-name",&program_name);

  if (bipipe(&from_prog, &to_prog ,program_name)!=0) {
    fprintf(stderr,"Cannot open program\n");
    exit(1);
  }

  while (1) {
    get_client_data(&input,hostname,port_nr,password);
    if (fputs(input,to_prog)<0) exit(1);
    if (fgetstring(&output,from_prog)==NULL) exit(1);
    send_client_data(input,output,hostname,port_nr,password);
  }
}
