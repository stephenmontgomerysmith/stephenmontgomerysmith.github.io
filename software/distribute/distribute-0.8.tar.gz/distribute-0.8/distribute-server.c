/*
 * Copyright (c) 2001 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <distribute.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <db3/db.h>

char rules_file_name[] = "distribute.allow";
char password[1000];
int time_out;
int port_nr;

pthread_mutex_t read_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t db_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
  int connfd;
  struct in_addr addr;
  u_short port;
}
arg_pass_type;

DB *queue_db, *use_db;

int de_queue() {
  DBT key = {NULL,0,0,0,0,DB_DBT_REALLOC};
  DBT data = {NULL,0,0,0,0,DB_DBT_REALLOC};
  DBC *cursor;
  int *queue_time;
  int ret_val = 0;

  pthread_mutex_lock(&db_mutex);
  if (queue_db->cursor(queue_db,NULL,&cursor,0) != 0) {
    fprintf(stderr,"Cannot create cursor for queue database\n");
    exit(1);
  }
  while(cursor->c_get(cursor,&key,&data,DB_NEXT)==0) {
    ret_val = 1;
    queue_time = (int*)data.data;
    (*queue_time)--;
//  fprintf(stderr,"De-queue: %d %s",*queue_time, (char*)key.data);
    if (*queue_time<0) {
      if (queue_db->del(queue_db,NULL,&key,0) != 0 ||
          use_db->put(use_db,NULL,&key,&data,0) != 0) {
        fprintf(stderr,"Unable to delete from or put in db\n");
        exit(1);
      }
    }
    else {
      if (queue_db->del(queue_db,NULL,&key,0) != 0 ||
          queue_db->put(queue_db,NULL,&key,&data,0) != 0) {
        fprintf(stderr,"Unable to delete from or put in db\n");
        exit(1);
      }
    }
  }
  if (cursor->c_close(cursor)!=0) {
    fprintf(stderr,"Cannot close cursor\n");
    exit(1);
  }
  pthread_mutex_unlock(&db_mutex);

  if (key.data!=NULL) free(key.data);
  if (data.data!=NULL) free(data.data);

  return ret_val;
}

void *repeat_de_queue(void *arg) {
  pthread_detach(pthread_self());
  while(1) {
    sleep(60);
    de_queue();
  }
}

void *process_client(void *arg) {
  int connfd = ((arg_pass_type*)arg)->connfd;
  struct in_addr addr = ((arg_pass_type*)arg)->addr;
  u_short port = ((arg_pass_type*)arg)->port;

  FILE *client;
  char *read_s=NULL, *input=NULL, *output=NULL;
  char info[1000];
  char s_time[1000];

  DBT getkey = {NULL,0,0,0,0,DB_DBT_REALLOC};
  DBT putkey;
  int queue_time;
  DBT data = {&queue_time,sizeof(int),sizeof(int),0,0,DB_DBT_USERMEM};
  DBC *cursor=NULL;

  int duplicate;
  int input_obtained;
  int found;
  int r;

  free(arg);

  pthread_detach(pthread_self());
  if ((client=fdopen(connfd,"r+"))==NULL) goto end;

  if (fgetstring(&read_s,client)==NULL) goto end;

  if (strcmp(read_s,"request data\r\n")==0) {
    if (fgetstring(&read_s,client)==NULL) goto end;
    if (strcmp(read_s,password)!=0) goto end;

/* Get input - first try database, then stdin. */
    do {
      pthread_mutex_lock(&db_mutex);
      if (use_db->cursor(use_db,NULL,&cursor,0) != 0) {
        fprintf(stderr,"Cannot create cursor for database\n");
        exit(1);
      }
      if (cursor->c_get(cursor,&getkey,&data,DB_FIRST)==0) {
        if (use_db->del(use_db,NULL,&getkey,0) != 0) {
          fprintf(stderr,"Cannot delete from database\n");
          exit(1);
        }
        strcpyalloc(&input,getkey.data);
        input_obtained = 1;
        duplicate = 0;
      }
      else do {
        pthread_mutex_unlock(&db_mutex);
        pthread_mutex_lock(&read_mutex);
        if (fgetstring(&input,stdin)!=NULL) {
          input_obtained = 1;
          pthread_mutex_unlock(&read_mutex);
          pthread_mutex_lock(&db_mutex);
          putkey.size = strlen(input)+1;
          putkey.data = input;
          duplicate = 
            queue_db->get(queue_db,NULL,&putkey,&data,0) == 0 ||
            use_db->get(use_db,NULL,&putkey,&data,0) == 0;
          if (duplicate)
            fprintf(stderr, "duplicate inputs\n");
        }
        else {
          input_obtained = 0;
          duplicate = 0;
          if (!de_queue()) {
            pthread_mutex_lock(&print_mutex);
            printf("Finished [%s]\n", str_time(s_time));
            pthread_mutex_unlock(&print_mutex);
            exit(0);
          }
        }
      } while(input_obtained && duplicate);
      cursor->c_close(cursor);
      pthread_mutex_unlock(&db_mutex);
    } while (!input_obtained);

/* Send input, and add input to database. */
    if (strcmp(input,"No data\n") != 0) {
      putkey.size = strlen(input)+1;
      putkey.data = input;
      queue_time = time_out;
      if (queue_db->put(queue_db,NULL,&putkey,&data,0) != 0) {
        fprintf(stderr,"Unable to put to db\n");
        exit(1);
      }
    }
    pthread_mutex_unlock(&db_mutex);
    n2rn(&input);
    if (fputs(input,client)<0) goto end;
  }

  else if (strcmp(read_s,"sending data\r\n")==0) {
    if (fgetstring(&read_s,client)==NULL) goto end;
    if (fgetstring(&input,client)==NULL) goto end;
    rn2n(&input);
    if (fgetstring(&output,client)==NULL) goto end;
    rn2n(&output);

    if (strcmp(read_s,password)!=0) goto end;
    sprintf(info, "Data from %s:%d [%s]\n",inet_ntoa(addr),ntohs(port),
              str_time(s_time));
    pthread_mutex_lock(&db_mutex);
    putkey.data = input;
    putkey.size = strlen(input)+1;
    found = queue_db->del(queue_db,NULL,&putkey,0)==0 ||
            use_db->del(use_db,NULL,&putkey,0)==0;
    pthread_mutex_unlock(&db_mutex);
    pthread_mutex_lock(&print_mutex);
    if (found)
      printf("%s%s%s",info,input,output);
    else
      fprintf(stderr,"Unrecognised %s%s%s",info,input,output);
    pthread_mutex_unlock(&print_mutex);
  }

  else if (strcmp(read_s,"new rules\r\n")==0 && addr.s_addr==htonl(0x7f000001)) {
    if ((r=get_rules(rules_file_name))<0)
      fputs("Malformed distribute.allow\n",client);
    else if (r==1)
      fputs("No distrubute.allow file - all rules deleted\n",client);
    else
      fputs("New rules applied\n",client);
    print_rules(client);
  }

  else if (strcmp(read_s,"finished\r\n")==0 && addr.s_addr==htonl(0x7f000001)) {
    pthread_mutex_lock(&print_mutex);
    printf("Program terminated by localhost [%s]\n",str_time(s_time));
    pthread_mutex_unlock(&print_mutex);
    exit(0);
  }

end:
  if (read_s!=NULL) free(read_s);
  if (input!=NULL) free(input);
  if (output!=NULL) free(output);
  if (getkey.data!=NULL) free(getkey.data);
  if (client!=NULL) fclose(client);
  return NULL;
}

int main (int argc, char **argv) {
  int listenfd;
  struct sockaddr_in servaddr;
  socklen_t slen;
  pthread_t tid;
  arg_pass_type *arg;

  if (argc != 4) {
    fprintf(stderr,
"usage: distribute-server password port time-out\n");
    exit(1);
  }
  if (strlen(argv[1]) > 997) {
    fprintf(stderr,"Password too long\n");
    exit(1);
  }
  strcpy(password,argv[1]);
  strcat(password,"\r\n");
  port_nr = atoi(argv[2]);
  time_out = atoi(argv[3]);

  if (get_rules(rules_file_name)<0) {
    fprintf(stderr,"Malformed distribution.allow\n");
    exit(1);
  }
  fprintf(stderr,"Firewall information:\n");
  print_rules(stderr);

  setlinebuf(stdout);

  if (db_create(&queue_db,NULL,0)!=0 ||
      queue_db->open(queue_db,NULL,NULL,DB_BTREE,DB_CREATE,0) !=0 ||
      db_create(&use_db,NULL,0)!=0 ||
      use_db->open(use_db,NULL,NULL,DB_BTREE,DB_CREATE,0) !=0) {
    fprintf(stderr,"Unable to create database\n");
    exit(1);
  }

  pthread_create(&tid,NULL,repeat_de_queue,NULL);

  listenfd=socket(AF_INET,SOCK_STREAM,0);
  bzero(&servaddr,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
  servaddr.sin_port=htons(port_nr);
  if (bind(listenfd,(struct sockaddr*)&servaddr,sizeof(servaddr)) < 0)
  {
    perror("Could not bind");
    exit(1);
  }
  listen(listenfd,6);

  while (1)
  {
    slen=sizeof(servaddr);
    arg = malloc(sizeof(arg_pass_type));
    arg->connfd = accept(listenfd,(struct sockaddr*)&servaddr,&slen);
    arg->addr = servaddr.sin_addr;
    arg->port = servaddr.sin_port;
    if (check_rule(ntohl(arg->addr.s_addr)))
      pthread_create(&tid,NULL,process_client,(void*) arg);
    else {
      fprintf(stderr,"Connection attempt from %s:%d\n",
              inet_ntoa(arg->addr),ntohs(arg->port));
      close(arg->connfd);
    }
  }
}
