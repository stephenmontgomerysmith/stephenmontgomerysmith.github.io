#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gmp.h>

/* N is the length of the interval to work on with each batch.
   Should be an even number. */
#define N 10000000
#define NRBITS ((N+1)/2)
#define USEMEM ((NRBITS+7)/8)

/* MAX_NEG - if checking whether p, p-a_1, ...,  p-a_k are primes,
   this at least as large as the maximum value of a_k. */
#define MAX_NEG $max_neg
#define MAX_NEG_BITS (MAX_NEG<<1)
#define MAX_NEG_MEM ((MAX_NEG_BITS+7)/8)

/* The number of batches to do each time. */
#define BATCH 100

int *small_prime, nr_small_primes;

/*
bit n of bitarray represents 2n+1, or base*N+2n+1
(and n might be negative, down to -MAX_NEG).
*/
unsigned char whole_bit_array[USEMEM+MAX_NEG_MEM];
unsigned char *bitarray=whole_bit_array+MAX_NEG_MEM;
#define TEST(b,n) (b[(n)>>3] & 1<<((n)&0x7))
#define SET(b,n) (b)[(n)>>3] |= 1<<((n)&0x7)

mpz_t s,t;

/* Compute primes up to N. */

void make_small_primes() {
  int m,n;
  int max_n;

  mpz_set_ui(s,N);
  mpz_sqrt(s,s);
  max_n = (mpz_get_ui(s)-1)/2;
  bzero(whole_bit_array,sizeof(whole_bit_array));
  for (n=1;n<=max_n;n++)
    if (!TEST(bitarray,n)) {
      for (m=n+(2*n+1);m<NRBITS;m+=(2*n+1))
        SET(bitarray,m);
    }

  nr_small_primes = 0;
  for (n=1;n<NRBITS;n++)
    if (!TEST(bitarray,n))
      nr_small_primes++;

  small_prime = malloc((nr_small_primes+1)*sizeof(int));
  m = 0;
  for (n=1;n<NRBITS;n++)
    if (!TEST(bitarray,n)) {
      small_prime[m] = 2*n+1;
      m++;
    }
  small_prime[m] = 1<<30;
}

/* Compute primes in [base*N-MAX_NEG,(base+1)*N).
   It requires that base<N .*/

void make_large_primes(int base) {
  int *m;
  int max_p;
  int start,n;

/* max_p = sqrt(N*(base+1)) */
  mpz_set_ui(s,N);
  mpz_mul_ui(s,s,base+1);
  mpz_sqrt(s,s);
  max_p = mpz_get_ui(s);
  bzero(whole_bit_array,sizeof(whole_bit_array));
  if (base==0) for (n=0;n>=-MAX_NEG_BITS;n--)
    SET(bitarray,0);
/* s = N*base-MAX_NEG+1 */
  mpz_set_ui(s,base);
  mpz_mul_ui(s,s,N);
  mpz_sub_ui(s,s,MAX_NEG-1);
  for (m=small_prime;*m<=max_p;m++) {
    if (base==0)
      start = 3*(*m);
    else {
/* start = N*base + (2*k+1)(*m), where k is picked so that 
   start is as small as possible with start>=1-MAX_NEG. */
      start = (*m)-mpz_mod_ui(t,s,2*(*m));
      if (start<0) start+=2*(*m);
      start -= MAX_NEG-1;
    }
    for (n=start>>1;n<NRBITS;n+=*m)
      SET(bitarray,n);
  }
}

/* Count how many primes in the interval [base*N,(base+1)*N) have the
   required properties. */

void count_large_primes(int *count, int base) {
  int n;

  make_large_primes(base);
  for (n=0;n<NRBITS;n++) if (!TEST(bitarray,n)) {
$test
  }
}

int main() {
  int base, b;
  int count[$nr_counts];
  int c;

  setlinebuf(stdout);
  mpz_init(s);
  mpz_init(t);
  make_small_primes();

  fprintf(stderr,
"This program counts the number of primes p between\n"
"%ub and %u(b+1)\n"
"for which p, p-a_1,...,p-a_k are prime, for various lists a_1,...,a_k.\n"
"Enter b (must be less than %u):\n",
N*BATCH,N*BATCH,N/BATCH);

  while (1) {
    if (scanf("%d",&b)!=1) exit(0);
    if (b>=N/BATCH)
      printf("Input too large\n");
    else {
      for (c=0;c<$nr_counts;c++)
        count[c] = 0;
      for (base=b*BATCH;base<b*BATCH+BATCH;base++)
        count_large_primes(count,base);
      for (c=0;c<$nr_counts;c++) {
        if (c!=0) printf(" ");
        printf("%d",count[c]);
      }
      printf("\n");
    }
  }
}
