#include "jeff-stokes.h"

void Ct_from_Y(Matrix& Ct, double Y[]) {
  Ct.resize(3,3);
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    Ct(i,j) = Y[Y_Ct+(i-1)*3+j-1];
}

void ode::get_C(Matrix& C) {
  Ct_from_Y(C,Y);
  C = C.t();
}

void Y_from_Ct(double Y[], Matrix Ct) {
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    Y[Y_Ct+(i-1)*3+j-1] = Ct(i,j);
}

void ode::set_C(Matrix C) {
  C = C.t();
  Y_from_Ct(Y,C);
}

void ode::set_lambda_U(double lambda, Matrix U) {
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    RPAR[RPAR_U+(i-1)*3+j-1] = U(i,j);

  SymmetricMatrix G;
  G << U+U.t();
  int G_count = RPAR_G;
  for (int i=1;i<=3;i++) for (int j=i;j<=3;j++)
    RPAR[G_count++] = G(i,j);

  Matrix WplG;
  WplG = 0.5*(U-U.t() + lambda*G);
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    RPAR[RPAR_WplG+(i-1)*3+j-1] = WplG(i,j);
}

void Y_from_kappa(double Y[], Matrix kappa) {
  Y[Y_kappa] = kappa(1,1);
  Y[Y_kappa+1] = kappa(2,1);
  Y[Y_kappa+2] = kappa(3,1);
}

void ode::set_kappa(double theta, double phi) {
  Matrix kappa(3,1);
  kappa << cos(phi*M_PI/180)*sin(theta*M_PI/180)
        << sin(phi*M_PI/180)*sin(theta*M_PI/180)
        << cos(theta*M_PI/180);
  Y_from_kappa(Y,kappa);
}

void kappa_from_Y(Matrix& kappa,double Y[]) {
  kappa.resize(3,1);
  kappa << Y[Y_kappa]
        << Y[Y_kappa+1]
        << Y[Y_kappa+2];
}

void ode::get_kappa(Matrix& kappa) {
  kappa_from_Y(kappa, Y);
}

SymmetricMatrix Basis[5];

void createBasis() {
  for (int i=0;i<5;i++) Basis[i].resize(3);
  Basis[0] << 1
           << 0 << -1
           << 0 << 0 << 0;
  Basis[1] << 0
           << 1 << 0
           << 0 << 0 << 0;
  Basis[2] << 0
           << 0 << 1
           << 0 << 0 << -1;
  Basis[3] << 0
           << 0 << 0
           << 1 << 0 << 0;
  Basis[4] << 0
           << 0 << 0
           << 0 << 1 << 0;
  for (int i=0;i<5;i++) {
    for (int j=0;j<i;j++) {
      Basis[i] -= trace(Basis[i]*Basis[j].t())/trace(Basis[j]*Basis[j].t())*Basis[j];
    }
    Basis[i] /= sqrt(trace(Basis[i]*Basis[i].t()));
  }
}

void ode::initialize() {
  t = 0;
  H = 1e-2;
  for (int i=0;i<5;i++) for (int j=0; j<5;j++)
    Y[i*5+j] = (i==j) ? 1 : 0;
  createBasis();
}

void ode::set_beta(double beta) {
  RPAR[RPAR_beta] = beta;
}

void ode::get_L(Matrix& L) {
  L.resize(5,5);
  for (int i=1;i<=5;i++)
    for (int j=1;j<=5;j++)
      L(i,j) = Y[Y_L+(i-1)*5+j-1];
}

void G_from_RPAR(SymmetricMatrix& G, double RPAR[]) {
  G.resize(3);
  int G_count = RPAR_G;
  for (int i=1;i<=3;i++) for (int j=i;j<=3;j++)
    G(i,j) = RPAR[G_count++];
}

void U_from_RPAR(Matrix& U, double RPAR[]) {
  U.resize(3,3);
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    U(i,j) = RPAR[RPAR_U+(i-1)*3+j-1];
}

void WplG_from_RPAR(Matrix& WplG, double RPAR[]) {
  WplG.resize(3,3);
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    WplG(i,j) = RPAR[RPAR_WplG+(i-1)*3+j-1];
}

Matrix MM(double t, double Y[], double RPAR[]) {
  Matrix C;
  Ct_from_Y(C,Y);
  C = C.t();
  Matrix kappa;
  kappa_from_Y(kappa,Y);
  SymmetricMatrix G(3);
  G_from_RPAR(G,RPAR);
  double beta = RPAR[RPAR_beta];

  IdentityMatrix Id(3);
  SymmetricMatrix B;
  B << C.t()*C;

  SymmetricMatrix kk(3);
  kk << kappa*kappa.t();

  SymmetricMatrix N(3), iN(3);
  N << trace(kk)*Id + 2*beta*ddot(BtoA4(B),kk);
  iN = N.i();
  Matrix iNkk(3,3);
  iNkk = iN*kk;

  Matrix Itemp(3,3);
  Itemp = - beta*(Id - 1/trace(iNkk)*iNkk)*iN;

  Matrix ret(5,5), Itu(3,1);
  SymmetricMatrix CttBC;
  Matrix tG, tW, dtBdt;
  for (int i=1;i<=5;i++) {
    CttBC << C.t()*Basis[i-1]*C;
    Itu = Itemp*ddot(BdBtodA4(B,CttBC),G)*kappa;
    tG = kappa*Itu.t() + Itu*kappa.t();
    tW = kappa*Itu.t() - Itu*kappa.t();
    dtBdt = - 1./2*C*(tW + tG)*C.i() - 1./2*C.t().i()*(- tW + tG)*C.t();
    for (int j=1;j<=5;j++)
      ret(j,i) = trace(dtBdt*Basis[j-1]);
  }
  return ret;
}

Matrix MM(ode &o) {
  return MM(o.t, o.Y, o.RPAR);
}

void FCN(int *N, double *X, double *Y, double *F, double *RPAR, int *IPAR) {
  Matrix Lrow(5,1), M(5,5);

  if (RPAR[RPAR_no_L] == 0) {
    M = MM(*X, Y, RPAR);

    for (int i=0;i<5;i++) {
      for (int j=1;j<=5;j++)
        Lrow(j,1) = Y[i*5+j-1];
      Lrow = M*Lrow;
      for (int j=1;j<=5;j++)
        F[i*5+j-1] = Lrow(j,1);
    }
  }

  Matrix Ct, WplG, dCt;
  Ct_from_Y(Ct,Y);
  WplG_from_RPAR(WplG,RPAR);
  dCt = - WplG.t()*Ct;
  Y_from_Ct(F,dCt);

  Matrix kappa, U, dkappa;
  kappa_from_Y(kappa,Y);
  U_from_RPAR(U,RPAR);
  dkappa = - U.t()*kappa;
  Y_from_kappa(F,dkappa);
}

void JAC(int *N, double *X, double *Y, double *DFY, int *LDFY, double *RPAR, int *IPAR) {
  Matrix M(5,5);
  M = MM(*X, Y, RPAR);

  memset(DFY,0,sizeof(double) * *LDFY * *N);
// dF(i+5*n)/dY(j+5*n) = M(i,j)

#define dfy(a,b) DFY[((a)-1)+*LDFY*((b)-1)]
  for (int n=0;n<5;n++) for (int i=1;i<=5;i++) for (int j=1;j<=5;j++)
    dfy(i-j+2+1,j+5*n) = M(i,j);

  Matrix WplG;
  WplG_from_RPAR(WplG,RPAR);
  for (int n=0;n<3;n++) for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    dfy(i-j+2+1,j+3*n+Y_Ct) = - WplG(j,i);

  Matrix U;
  U_from_RPAR(U,RPAR);
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++)
    dfy(i-j+2+1,j+Y_kappa) = - U(j,i);
}

void MAS(int *N, double *AM, int *LMAS, double *RPAR, int *IPAR) {
  exit(1);
}

void SOLOUT(int *NR, double *XOLD, double *X, double *Y, double *CONT, int *LRC, int *N, double *RPAR, int *IPAR, int *IRTRN) {
  exit(1);
}

void advance_ode(ode &o, double t_end, double tol) {
  Matrix L(5,5);
  DiagonalMatrix D(5);

  int N = Y_length;
  double RTOL = tol;
  double ATOL = tol;
  int ITOL = 0;
  int IJAC = 1;
  int MLJAC=2;
  int MUJAC=2;
  int IMAS = 0;
  int MLMAS;
  int MUMAS;
  int IOUT = 0;
  double WORK[Y_length*(Y_length+0+3*Y_length+12)+20];
  int LWORK = Y_length*(Y_length+0+3*Y_length+12)+20;
  int IWORK[3*Y_length+20];
  int LIWORK = 3*Y_length+20;
  int *IPAR = NULL;
  int IDID;

  memset(WORK, 0, sizeof(WORK));
  memset(IWORK, 0, sizeof(IWORK));
  radau5_(&N, FCN, &o.t, o.Y, &t_end, &o.H, &RTOL, &ATOL, &ITOL,
          JAC, &IJAC, &MLJAC, &MUJAC,
          MAS, &IMAS, &MLMAS, &MUMAS,
          SOLOUT, &IOUT,
          WORK, &LWORK, IWORK, &LIWORK, o.RPAR, IPAR, &IDID) ;
  if (IDID!=1) {
    cerr << "It didn't work" << endl;
    exit(1);
  }
}
