Copyright 2009 Stephen Montgomery-Smith, except dc_lapack.f and radau5.f, whose copyright and license terms are written in the file hairer-license.txt.

License
=======

The source code is released under the the BSD license: http://www.opensource.org/licenses/bsd-license.php

Any binaries must be released under the GNU public license, in compliance with the license with gsl.

Creating the Binaries
=====================

You need blas, lapack, newmat-11 and gsl to build the binaries.  Edit the Makefile to accomodate mixing fortran with C++ source code.

Using the binaries
==================

There are three binaries:
* jeff-stokes: prints out spectral norm of L for various kappa and t.
* calc-m: prints out largest real value of M for various kappa and t.
* floquet: prints out largest absolute eigenvalue of L for various kappa, after going through one period.

Options can be specified by adding "variable=value" on the command line (no spaces around the "=").  Not all variables are for all program.  Find out which can be set, and what the default values are, by running the program, or examining the source code.

t_end, t_step: specifies range of t.
theta_start, theta_end, theta_step: specifies range of theta, in degrees, for direction of kappa.
phi_start, phi_end, phi_step: specifies range of phi, in degrees, for direction of kappa.
beta.
lambda.
rho.
U: a 3x3 matrix, specify using 9 numbers separated by a "," or ":".
C: also a 3x3 matrix.
use_svd: if set to zero, will output spectral radius of L instead of spectral norm.
tol: absolute and relative tolerance given to ODE solver.

This work was supported by the National Science Foundation, Division of Civil, Mechanical and Manufacturing Innovation, award number 0727399 (NSF CMMI 0727399).
