#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;
#include <newmat/newmat.h>
#include <newmat/newmatap.h>
#include <newmat/newmatio.h>
#include <gsl/gsl_sf.h>

#include "ode.h"

class Elliptic_I {
  public:
    double I[2][4][4][4];
    Elliptic_I(double x, double y, double z);
};

class SymmetricTensor4 {
  public:
    SymmetricTensor4();
    double& element(int i, int j, int k, int l);
    double& operator()(int i, int j, int k, int l);
  private:
    double data[3][3][3][3];
    void sort(int& i,int& j);
};

ostream& operator<<(ostream& output, SymmetricTensor4 T);
SymmetricMatrix BtoA2(SymmetricMatrix B);
SymmetricTensor4 BtoA4(SymmetricMatrix B);
SymmetricTensor4 BdBtodA4(SymmetricMatrix B, SymmetricMatrix dB);
SymmetricMatrix ddot(SymmetricTensor4 T, SymmetricMatrix M);

void get_arg(int argc, char **argv, string s, double& a);
void get_arg(int argc, char **argv, string s, Matrix& A);
void get_arg(int argc, char **argv, string s, int& a);

void eigenvalues(Matrix A, Matrix &evals);

extern "C"
void radau5_(int *N,
             void FCN(int *N, double *X, double *Y, double *F, double *RPAR, int *IPAR),
             double *X, double *Y, double *XEND, double *H,
             double *RTOL, double *ATOL, int *ITOL,
             void JAC(int *N, double *X, double *Y, double *DFY, int *LDFY, double *RPAR, int *IPAR),
             int *IJAC, int *MLJAC, int *MUJAC,
             void MAS(int *N, double *AM, int *LMAS, double *RPAR, int *IPAR),
             int *IMAS, int *MLMAS, int *MUMAS,
             void SOLOUT(int *NR, double *XOLD, double *X, double *Y, double *CONT, int *LRC, int *N, double *RPAR, int *IPAR, int *IRTRN),
             int *IOUT,
             double *WORK, int *LWORK, int *IWORK, int *LIWORK, double *RPAR,int *IPAR, int *IDID) ;


extern "C"
void dgeev_(char *JOBVL, char *JOBVR, int *N, double *A, int *LDA, double *WR, double *WI, double *VL, int *LDVL, double *VR, int *LDVR, double *WORK, int *LWORK, int *INFO);

