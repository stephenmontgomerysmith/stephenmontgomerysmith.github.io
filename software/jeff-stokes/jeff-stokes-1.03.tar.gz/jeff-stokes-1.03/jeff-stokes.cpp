#include "jeff-stokes.h"

void printL(Matrix U, Matrix C, double phi, double theta, double beta, double lambda, double t_end, double t_step, double tol, int use_svd) {
  Matrix L, evals(5,2);
  DiagonalMatrix D(5);
  ode o;

  o.set_C(C);

  o.set_lambda_U(lambda, U);
  o.set_kappa(theta, phi);
  o.set_beta(beta);
  o.initialize();

  for (double t=t_step;t<=t_end;t+=t_step) {
    advance_ode(o,t,tol);

    o.get_L(L);

    double max = 0;
    if (use_svd) {
      SVD(L,D);
      for (int i=1;i<=5;i++) {
        double e = D(i);
        if (e>max) max = e;
      }
    } else {
      eigenvalues(L,evals);
      for (int i=1;i<=5;i++) {
        double e = hypot(evals(i,1),evals(i,2));
        if (e>max) max = e;
      }
    }
    cout << t << "\t" << phi << "\t" << theta << "\t" << max << endl;
  }
}

int main(int argc, char **argv) {
  double t_end = 10;
  double t_step = 1;
  get_arg(argc,argv,"t_end",t_end);
  get_arg(argc,argv,"t_step",t_step);

  double tol = 1e-6;
  get_arg(argc,argv,"tol",tol);

  Matrix U(3,3);
  U << 0 << 1 << 0
    << 0 << 0 << 0
    << 0 << 0 << 0;
  get_arg(argc,argv,"U",U);

  double beta = 1000;
  get_arg(argc,argv,"beta",beta);

  double lambda = 1;
  get_arg(argc,argv,"lambda",lambda);

  double rho = 1;
  get_arg(argc,argv,"rho",rho);
  Matrix C(3,3);
  C = 0;
  C(1,1) = C(3,3) = 1/sqrt(rho);
  C(2,2) = rho;

  get_arg(argc,argv,"C",C);

  double theta_start = 90;
  double theta_end = 90;
  double theta_step = 1;
  get_arg(argc,argv,"theta_start",theta_start);
  get_arg(argc,argv,"theta_end",theta_end);
  get_arg(argc,argv,"theta_step",theta_step);

  double phi_start = 0;
  double phi_end = 180;
  double phi_step = 1;
  get_arg(argc,argv,"phi_start",phi_start);
  get_arg(argc,argv,"phi_end",phi_end);
  get_arg(argc,argv,"phi_step",phi_step);

  int use_svd = 1;
  get_arg(argc,argv,"use_svd",use_svd);

  for (double theta=theta_start;theta<=theta_end;theta+=theta_step)
    for (double phi=phi_start;phi<=phi_end;phi+=phi_step)
      printL(U,C,phi,theta,beta,lambda,t_end,t_step,tol,use_svd);
}
