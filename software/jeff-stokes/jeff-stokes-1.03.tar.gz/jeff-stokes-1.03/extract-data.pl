#!/usr/bin/perl

while (<>) {
  next if /\=/;
  ($t,$phi,$theta,$L) = split /\s+/,$_;
  if (!defined($LL{$t}) || $L > $LL{$t}) {
    $LL{$t} = "$L";
    $pt{$t} = "$phi\t$theta";
  }
}

foreach $t (sort {$a<=>$b} keys %LL) {
  $L = $LL{$t};
  $d = int(log($L)/log(10));
  $dd = exp(log(10)*($d-1));
  $L = int($L/$dd+0.5)*$dd;
  $L = int($L) if $L>100;
  print "$t\t$pt{$t}\t$L\n";
}
