#include "jeff-stokes.h"

void printL(double phi, double theta, double beta, double lambda, double tol) {
  Matrix evals(5,2);
  Matrix L;
  DiagonalMatrix D(5);
  ode o;

  Matrix C(3,3);
  C = 0;
  C(1,1) = C(2,2) = C(3,3) = 1;
  o.set_C(C);

  Matrix U(3,3);
  U << 0 << 1 << 0
    << 0 << 0 << 0
    << 0 << 0 << 0;
  o.set_lambda_U(lambda, U);
  o.set_kappa(theta, phi);
  o.set_beta(beta);
  o.initialize();

  double t = 2*M_PI/sqrt(1-lambda*lambda);
  advance_ode(o,t,tol);
  o.get_L(L);

  eigenvalues(L,evals);

  double max = 0;
  for (int i=1;i<=5;i++) {
    double e = hypot(evals(i,1),evals(i,2));
    if (e>max) max = e;
  }

  cout << t << "\t" << phi << "\t" << theta << "\t" << max << endl;
}

int main(int argc, char **argv) {
  double tol = 1e-6;
  get_arg(argc,argv,"tol",tol);

  double beta = 10;
  get_arg(argc,argv,"beta",beta);

  double lambda = 0.8;
  get_arg(argc,argv,"lambda",lambda);

  double theta_start = 90;
  double theta_end = 90;
  double theta_step = 1;
  get_arg(argc,argv,"theta_start",theta_start);
  get_arg(argc,argv,"theta_end",theta_end);
  get_arg(argc,argv,"theta_step",theta_step);

  double phi_start = 90;
  double phi_end = 90;
  double phi_step = 1;
  get_arg(argc,argv,"phi_start",phi_start);
  get_arg(argc,argv,"phi_end",phi_end);
  get_arg(argc,argv,"phi_step",phi_step);

  for (double theta=theta_start;theta<=theta_end;theta+=theta_step)
    for (double phi=phi_start;phi<=phi_end;phi+=phi_step)
      printL(phi,theta,beta,lambda,tol);
}
