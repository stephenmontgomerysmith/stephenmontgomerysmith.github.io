#include "jeff-stokes.h"

Elliptic_I::Elliptic_I(double x, double y, double z) {
/* Cheap way to avoid divide by zero errors */
  if (fabs(x-y)<1e-5 && fabs(x-z)<1e-5) {
    y = x+1e-5;
    z = x+2e-5;
  }
  if (fabs(x-y)<1e-6)
    y = x+1e-6;
  if (fabs(x-z)<1e-6)
    z = x+1e-6;
  if (fabs(y-z)<1e-6)
    z = y+1e-6;
  I[0][1][0][0] = 2./3*gsl_sf_ellint_RD(y,z,x,GSL_PREC_DOUBLE);
  I[0][0][1][0] = 2./3*gsl_sf_ellint_RD(x,z,y,GSL_PREC_DOUBLE);
  I[0][0][0][1] = 2./3*gsl_sf_ellint_RD(x,y,z,GSL_PREC_DOUBLE);
  I[1][1][1][0] = (x*I[0][1][0][0] - y*I[0][0][1][0])/(x-y); 
  I[1][1][0][1] = (x*I[0][1][0][0] - z*I[0][0][0][1])/(x-z); 
  I[1][0][1][1] = (y*I[0][0][1][0] - z*I[0][0][0][1])/(y-z); 
  I[1][2][0][0] = (2./3)*(I[0][1][0][0] - 1./2*I[1][1][1][0] - 
      1./2*I[1][1][0][1]); 
  I[1][0][2][0] = (2./3)*(I[0][0][1][0] - 1./2*I[1][1][1][0] - 
      1./2*I[1][0][1][1]); 
  I[1][0][0][2] = (2./3)*(I[0][0][0][1] - 1./2*I[1][0][1][1] - 
      1./2*I[1][1][0][1]); 
  I[1][2][1][0] = (I[1][2][0][0] - I[1][1][1][0])/(y-x); 
  I[1][2][0][1] = (I[1][2][0][0] - I[1][1][0][1])/(z-x); 
  I[1][1][2][0] = (I[1][0][2][0] - I[1][1][1][0])/(x-y); 
  I[1][0][2][1] = (I[1][0][2][0] - I[1][0][1][1])/(z-y); 
  I[1][1][0][2] = (I[1][0][0][2] - I[1][1][0][1])/(x-z); 
  I[1][0][1][2] = (I[1][0][0][2] - I[1][0][1][1])/(y-z); 
  I[0][2][0][0] = (I[0][1][0][0] - I[1][2][0][0])/x; 
  I[1][3][0][0] = (2./5)*(I[0][2][0][0] - 1./2*I[1][2][1][0] - 
      1./2*I[1][2][0][1]); 
  I[0][0][2][0] = (I[0][0][1][0] - I[1][0][2][0])/y; 
  I[1][0][3][0] = (2./5)*(I[0][0][2][0] - 1./2*I[1][1][2][0] - 
      1./2*I[1][0][2][1]); 
  I[0][0][0][2] = (I[0][0][0][1] - I[1][0][0][2])/z; 
  I[1][0][0][3] = (2./5)*(I[0][0][0][2] - 1./2*I[1][1][0][2] - 
      1./2*I[1][0][1][2]); 
  I[1][1][1][1] = (I[1][1][0][1] - I[1][0][1][1])/(y-x);
}

#define iterate(i) for (int i=1;i<=3;i++)

SymmetricTensor4::SymmetricTensor4() {memset(data,0,sizeof(data));}

void SymmetricTensor4::sort(int& i,int& j){ int t; if(i>j){t=i;i=j;j=t;}}

double& SymmetricTensor4::element(int i, int j, int k, int l) {
  sort(i,j);
  sort(j,k);
  sort(k,l);
  sort(i,j);
  sort(j,k);
  sort(i,j);
  return data[i-1][j-1][k-1][l-1];
}
double& SymmetricTensor4::operator()(int i, int j, int k, int l) {return element(i,j,k,l);}

SymmetricTensor6::SymmetricTensor6() {memset(data,0,sizeof(data));}

void SymmetricTensor6::sort(int& i,int& j){ int t; if(i>j){t=i;i=j;j=t;}}

double& SymmetricTensor6::element(int i, int j, int k, int l, int m, int n) {
  sort(i,j);
  sort(j,k);
  sort(k,l);
  sort(l,m);
  sort(m,n);

  sort(i,j);
  sort(j,k);
  sort(k,l);
  sort(l,m);

  sort(i,j);
  sort(j,k);
  sort(k,l);

  sort(i,j);
  sort(j,k);

  sort(i,j);

  return data[i-1][j-1][k-1][l-1][m-1][n-1];
}
double& SymmetricTensor6::operator()(int i, int j, int k, int l, int m, int n) {return element(i,j,k,l,m,n);}

ostream& operator<<(ostream& output, SymmetricTensor4 T) {
  iterate(i) iterate(j) iterate(k) iterate(l)
    output << T(i,j,k,l) << (i==3&&j==3&&k==3&&l==3?"\n":" ");
  return output;
}

SymmetricMatrix BtoA2(SymmetricMatrix B) {
  DiagonalMatrix D,E(3);
  Matrix V;
  SymmetricMatrix A;

  EigenValues(B,D,V);
  Elliptic_I a(D(1,1),D(2,2),D(3,3));
  E(1,1) = 0.5*a.I[0][1][0][0];
  E(2,2) = 0.5*a.I[0][0][1][0];
  E(3,3) = 0.5*a.I[0][0][0][1];
  A << V*E*V.t();
  return A;
}

static int delta(int i, int j) {
  return i==j;
}

SymmetricTensor4 BtoA4(SymmetricMatrix B) {
  DiagonalMatrix D;
  Matrix V;

  EigenValues(B,D,V);
  Elliptic_I a(D(1,1),D(2,2),D(3,3));

  SymmetricTensor4 AA;
  iterate(i)
    AA(i,i,i,i) = 3./4*a.I[1][2*delta(1,i)][2*delta(2,i)][2*delta(3,i)];
  iterate(i) iterate(j) if (i<j)
    AA(i,i,j,j) = 1./4*a.I[1][delta(1,i)+delta(1,j)][delta(2,i)+delta(2,j)][delta(3,i)+delta(3,j)];
  SymmetricTensor4 A;
  iterate(i) iterate(j) iterate(k) iterate(l) if (i<=j&&j<=k&&k<=l)
    iterate(m) iterate(n) iterate(p) iterate(q)
      A(i,j,k,l) += AA(m,n,p,q)*V(i,m)*V(j,n)*V(k,p)*V(l,q);
  return A;
}

SymmetricTensor4 BdBtodA4_old(SymmetricMatrix B, SymmetricMatrix dB) {
  DiagonalMatrix D;
  Matrix V;

  EigenValues(B,D,V);
  Elliptic_I a(D(1,1),D(2,2),D(3,3));
  dB << V.t()*dB*V;

  SymmetricTensor4 AA;

  iterate(i) {
    AA(i,i,i,i) = -3./2*a.I[1][3*delta(1,i)][3*delta(2,i)][3*delta(3,i)]*dB(i,i);
    iterate(r)
      AA(i,i,i,i) += -3./8*a.I[1][2*delta(1,i)+delta(1,r)][2*delta(2,i)+delta(2,r)][2*delta(3,i)+delta(3,r)]*dB(r,r);
  }

  iterate(i) iterate(j) if (i<j) {
    AA(i,i,j,j) = -1./4*a.I[1][2*delta(1,i)+delta(1,j)][2*delta(2,i)+delta(2,j)][2*delta(3,i)+delta(3,j)]*dB(i,i)
                  -1./4*a.I[1][2*delta(1,j)+delta(1,i)][2*delta(2,j)+delta(2,i)][2*delta(3,j)+delta(3,i)]*dB(j,j);
    iterate(r)
      AA(i,i,j,j) += - 1./8*a.I[1][delta(1,i)+delta(1,j)+delta(1,r)][delta(2,i)+delta(2,j)+delta(2,r)][delta(3,i)+delta(3,j)+delta(3,r)]*dB(r,r);
  }

  iterate(i) iterate(j) if (i!=j)
    AA(i,i,i,j) = -3./4*a.I[1][2*delta(1,i)+delta(1,j)][2*delta(2,i)+delta(2,j)][2*delta(3,i)+delta(3,j)]*dB(i,j);

  iterate(i) iterate(j) iterate(k) if (i<j && i!=k && j!=k)
    AA(i,j,k,k) = -1./4*a.I[1][delta(1,i)+delta(1,j)+delta(1,k)][delta(2,i)+delta(2,j)+delta(2,k)][delta(3,i)+delta(3,j)+delta(3,k)]*dB(i,j);

  SymmetricTensor4 A;
  iterate(i) iterate(j) iterate(k) iterate(l) if (i<=j&&j<=k&&k<=l)
    iterate(m) iterate(n) iterate(p) iterate(q)
      A(i,j,k,l) += AA(m,n,p,q)*V(i,m)*V(j,n)*V(k,p)*V(l,q);
  return A;
}

SymmetricTensor4 BdBtodA4(SymmetricMatrix B, SymmetricMatrix dB) {
  DiagonalMatrix D;
  Matrix V;

  EigenValues(B,D,V);
  Elliptic_I a(D(1,1),D(2,2),D(3,3));
  dB << V.t()*dB*V;

  SymmetricTensor6 dA4dB;

  iterate(i)
    dA4dB(i,i,i,i,i,i) = -15./8*a.I[1][3*delta(1,i)][3*delta(2,i)][3*delta(3,i)];
  iterate(i) iterate(j) if (i!=j)
    dA4dB(i,i,i,i,j,j) = -3./8*a.I[1][2*delta(1,i)+delta(1,j)][2*delta(2,i)+delta(2,j)][2*delta(3,i)+delta(3,j)];
  iterate(i) iterate(j) iterate(k) if (i<j && j<k)
    dA4dB(i,i,j,j,k,k) = -1./8*a.I[1][delta(1,i)+delta(1,j)+delta(1,k)][delta(2,i)+delta(2,j)+delta(2,k)][delta(3,i)+delta(3,j)+delta(3,k)];

  SymmetricTensor4 AA;

  iterate(i) iterate(j) iterate(k) iterate(l) if (i<=j && j<=k && k<=l)
    iterate(m) iterate(n)
      AA(i,j,k,l) += dA4dB(i,j,k,l,m,n)*dB(m,n);

  SymmetricTensor4 A;
  iterate(i) iterate(j) iterate(k) iterate(l) if (i<=j&&j<=k&&k<=l)
    iterate(m) iterate(n) iterate(p) iterate(q)
      A(i,j,k,l) += AA(m,n,p,q)*V(i,m)*V(j,n)*V(k,p)*V(l,q);
  return A;
}

SymmetricMatrix ddot(SymmetricTensor4 T, SymmetricMatrix M) {
  SymmetricMatrix N(3);
  N = 0;
  iterate(i) iterate(j) if (i<=j) iterate(k) iterate(l) {
    N(i,j) += T(i,j,k,l)*M(k,l);
  }
  return N;
}

void eigenvalues(Matrix A, Matrix &evals) {
  char JOBVL = 'N';
  char JOBVR = 'N';
  int N = 5;
  double AA[25];
  double WR[5];
  double WI[5];
  int LDVL = 1;
  double WORK[1000];
  int LWORK = 1000;
  int INFO;

  for (int i=1;i<=5;i++) for (int j=1;j<=5;j++)
    AA[(i-1)*5+j-1] = A(i,j);

  dgeev_(&JOBVL,&JOBVR,&N,AA,&N,WR,WI,NULL,&LDVL,NULL,&LDVL,WORK,&LWORK,&INFO);
  if (INFO!=0) {
    cerr << "eigenvalues not computed" << endl;
    exit(1);
  }

  evals.resize(5,2);

  for (int i=1;i<=5;i++) {
    evals(i,1) = WR[i-1];
    evals(i,2) = WI[i-1];
  }
}

void get_arg(int argc, char **argv, string s, double& a) {
  s.append("=");
  for(int i=1;i<argc;i++) {
    if (s.compare(0,s.size(),argv[i],s.size()) == 0) {
      a = strtod(argv[i]+s.size(),NULL);
      break;
    }
  }
  cout << s << a << endl;
}

void get_arg(int argc, char **argv, string s, int& a) {
  s.append("=");
  for(int i=1;i<argc;i++) {
    if (s.compare(0,s.size(),argv[i],s.size()) == 0) {
      a = strtol(argv[i]+s.size(),NULL,10);
      break;
    }
  }
  cout << s << a << endl;
}

void get_arg(int argc, char **argv, string s, Matrix& A) {
  string ss = s;
  s.append("=");
  for(int k=1;k<argc;k++) {
    if (s.compare(0,s.size(),argv[k],s.size()) == 0) {
      A.resize(3,3);
      char *input=argv[k]+s.size();
      for (int i=1;i<=3;i++) for (int j=1;j<=3;j++) {
        A(i,j) = strtod(input,&input);
        if (i!=3 || j!=3)
          if (*input == ',' || *input == ':') input++;
          else {
            cerr << "Improper input for " << ss << endl;
            exit(1);
          }
      }
      break;
    }
  }
  cout << s;
  for (int i=1;i<=3;i++) for (int j=1;j<=3;j++) {
    cout << A(i,j);
    if (i==3 && j==3) cout << endl;
    else if (j==3) cout << ":";
    else cout << ",";
  }
}

