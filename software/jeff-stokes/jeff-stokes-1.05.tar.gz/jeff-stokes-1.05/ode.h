#define	RPAR_WplG	0
#define RPAR_U		9
#define	RPAR_G		18
#define	RPAR_beta	24
#define RPAR_lambda	25
#define RPAR_no_L	26
#define RPAR_length	27
// RPAR[0-8] = 0.5*(W+lambda*G)(i,j) 1<=i,j<=3
// RPAR[9-17] = U(i,j) 1<=i,j<=3
// RPAR[18-23] = G(i,j) 1<=i<=j<=3
// RPAR[24] = beta
// RPAR[25] = lambda
// RPAR[26] = no_L

#define Y_L		0
#define Y_Ct		25
#define Y_kappa		34
#define Y_length	37
// Y[0->24] = L(j,i) 1<=i,j<=5
// Stored as Lt (L transpose) so we work with one column at a time.
// Y[25->33] = C(j,i) 1<=i,j<=3
/* Stored as Ct (C transpose) because this transforms the ode
       dC/dt = - C.WplG
   to
       dCt/dt = - WplGt.Ct
   and this allows Jacobian matrix in JAC to keep its banded structure.
*/
// Y[34->36] = kappa(i,1) 1<=i<=3

class ode {
  friend void advance_ode(ode &o, double t_end, double tol);
  friend Matrix MM(ode &o);
  public:
    ode () {RPAR[RPAR_no_L]=0;};
    void get_C(Matrix& C);
    void set_C(Matrix C);
    void set_lambda_U(double l, Matrix U);
    void set_kappa(double theta, double phi);
    void get_kappa(Matrix& kappa);
    void set_beta(double beta);
    void initialize();
    void get_L(Matrix& L);
    void set_no_L() {RPAR[RPAR_no_L]=1;};
  private:
    double RPAR[RPAR_length];

    double Y[Y_length];
    double t;
    double H;
    int no_L;
};

