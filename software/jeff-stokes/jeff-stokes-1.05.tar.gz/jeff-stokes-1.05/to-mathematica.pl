while (defined($_=<>) && !/phi\_step/) {
  print;
}

for ($i=0;$i<5;$i++) {
  $_ = <>;
  chomp;
  $l[$i] = "{" . join(",",split(/ /,$_)) . "}";
}

print "{" , join(",",@l) , "};\n";
