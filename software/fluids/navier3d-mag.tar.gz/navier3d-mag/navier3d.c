/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier3d.h"

void ode_initialise();
void ode_finish();
void ode_solve(vector_fourier_array mag, vector_fourier_array diffmag, double h);
void ode_checkpoint(int iterate, double t, vector_fourier_array vel);
int ode_recover_checkpoint(int *iterate, double *t, vector_fourier_array vel);

extern double norm_mag, norm_vel, norm_vort,
              max_mag,  max_vel,  max_vort;

extern vector_data_array vort_data;
#define mag_data vort_data

double calc_h(double max_vel, double max_vort) {
  double h = 1;
  double h1 = 0.1/P/max_vel;
/* double h2 = 0.5/max_vort; */
/* double h3 = 0.01/viscosity/N/N; to avoid stiffness problems */
/* if (h2<h1) h1 = h2; */
/* if (h3<h1) h1 = h3; */
  while(h>h1) h/=10;
  while(h<h1/10) h*=10;
  if(h<h1/5) h*=5;
  else if(h<h1/2) h*=2;
  return(h);
}

int main () {
  vector_fourier_array mag, diffmag;

  int iter;

  double last_norm_vel;
  double h,t;
  int dataout;
  int showinterval = 500;
  int recovered;
  sigset_t sigs;

  sigemptyset(&sigs);
  sigaddset(&sigs,SIGINT);
  sigaddset(&sigs,SIGHUP);
  sigaddset(&sigs,SIGTERM);

  ode_initialise();
  recovered = ode_recover_checkpoint(&iter,&t,mag);
  prepare_output(&dataout,!recovered);

  create_plans();

  if (!recovered) {

    init_data(mag_data);
    calc_fourier(mag[0],mag_data[0]);
    calc_fourier(mag[1],mag_data[1]);
    calc_fourier(mag[2],mag_data[2]);
/*
    init_fourier(mag);
    leray(mag);
*/
  }

  calc_non_lin(diffmag,mag,1);
  printf("iter = %d\n",iter);
  printf("norm_mag = %g\n",norm_mag);
  printf("norm_vel = %g\n",norm_vel);
  printf("norm_vort = %g\n",norm_vort);
  printf("max_mag = %g\n",max_mag);
  printf("max_vel = %g\n",max_vel);
  printf("max_vort = %g\n",max_vort);
  last_norm_vel = norm_vel;
  fflush(stdout);

  h = calc_h(max_vel,max_vort);
  printf("h = %g\n",h);

  if (!recovered) {
    sigprocmask(SIG_BLOCK,&sigs,NULL);
    ode_output(dataout,iter,t,&mag[0][0][0][0]);
    sigprocmask(SIG_UNBLOCK,&sigs,NULL);
  }

  iter++;

  for (;iter<=2000000;iter++) {
    ode_solve(mag,diffmag,h);
    t += h;

    calc_non_lin(diffmag,mag,1);
    printf("iter = %d\n",iter);
    printf("norm_mag = %g\n",norm_mag);
    printf("norm_vel = %g\n",norm_vel);
    printf("norm_vort = %g\n",norm_vort);
    printf("max_mag = %g\n",max_mag);
    printf("max_vel = %g\n",max_vel);
    printf("max_vort = %g\n",max_vort);
    printf("actual energy change = %g\n",norm_vel*norm_vel-last_norm_vel*last_norm_vel);
    printf("projected energy change = %g\n",-2*viscosity*h*norm_vort*norm_vort);
    last_norm_vel = norm_vel;
    fflush(stdout);

    h = calc_h(max_vel,max_vort);
    printf("h = %g\n",h);

    if (iter%showinterval == 0) {
      sigprocmask(SIG_BLOCK,&sigs,NULL);
      ode_output(dataout,iter,t,&mag[0][0][0][0]);
      ode_checkpoint(iter,t,mag);
      sigprocmask(SIG_UNBLOCK,&sigs,NULL);
    }
  }
  return(0);
}
