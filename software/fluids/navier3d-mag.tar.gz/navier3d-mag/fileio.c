/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier3d.h"

/* returns 1 if data.out already exists */
int if_output_exists(int *fd) {
  int i;

  *fd=open("data.out",O_RDWR);
  if (*fd == -1) {
    if (errno != ENOENT) {
      fprintf(stderr,"Error checking output file\n");
      exit(1);
    }
    return 0;
  }
  else {
    if (read(*fd,&i,sizeof(int)) == -1) {
      fprintf(stderr,"Unable to read input file\n");
      exit(1);
    }
    if (i != length) {
      fprintf(stderr,"Wrong length\n");
      exit(1);
    }
    return 1;
  }
}

void prepare_output(int *fd,int new)
{
  int i;

  if (new) *fd=open("data.out",O_WRONLY|O_CREAT|O_TRUNC);
  else     *fd=open("data.out",O_WRONLY|O_CREAT|O_APPEND);
  if (*fd == -1)
  {
    fprintf(stderr,"Unable to open output file\n");
    exit(1);
  }
  if (new) {
    if(chmod("data.out",0644)==-1) {
      fprintf(stderr,"Unable to chmod output file\n");
      exit(1);
    }
    i=length;
    if(write(*fd,&i,sizeof(int)) == -1)
    {
      fprintf(stderr,"Unable to write to output file\n");
      exit(1);
    }
  }
}

void prepare_socket_output(int *connfd)
{
  int i;
  int listenfd;
  struct sockaddr_in servaddr;
  socklen_t slen;
  pid_t pid;

  listenfd=socket(AF_INET,SOCK_STREAM,0);
  bzero(&servaddr,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
  servaddr.sin_port=htons(3000);
  if (bind(listenfd,(struct sockaddr*)&servaddr,sizeof(servaddr)) < 0)
  {
    fprintf(stderr,"Could not bind\n");
    exit(1);
  }
  listen(listenfd,6);
  slen=sizeof(servaddr);

  while (1)
  {
    *connfd=accept(listenfd,(struct sockaddr*)&servaddr,&slen);
    pid = fork();
    if (pid == 0) break; /* child */
    close(*connfd);
  }

  /* now we are the child */
  close(listenfd);
  i=length;
  if(write(*connfd,&i,sizeof(int)) == -1)
  {
    fprintf(stderr,"Unable to write to socket\n");
    exit(1);
  }
}

void writeout(int fd, void *buffer, ssize_t total_size) {
  ssize_t size,sized;

  size = 0;
  while(size < total_size)
  {
    sized = write(fd,buffer+size,total_size-size);
    if (sized==-1)
    {
      fprintf(stderr,"Unable to write to file or socket.\n");
      exit(1);
    }
    size += sized;
  }
}

void ode_output(int fd, int i, double t, void *x)
{
  writeout(fd,&i,sizeof(int));
  writeout(fd,&t,sizeof(double));
  writeout(fd,x,length*sizeof(double));
}


void ode_output_double(int fd, double t)
{
  writeout(fd,&t,sizeof(double));
}

void ode_output_int(int fd, int i)
{
  writeout(fd,&i,sizeof(int));
}

off_t total_data_in;

void prepare_input(int *fd)
{
  int i;
  FILE *datain;

  datain=fopen("data.out","r");
  if (datain == NULL)
  {
    fprintf(stderr,"Unable to open input file\n");
    exit(1);
  }
  *fd = fileno(datain);
  if (read(*fd,&i,sizeof(int)) == -1)
  {
    fprintf(stderr,"Unable to read input file\n");
    exit(1);
  }
  if (i != length)
  {
    fprintf(stderr,"Wrong length\n");
    fflush(stderr);
    exit(1);
  }
  total_data_in = 4;
}

void prepare_socket_input(int *sockfd, int argc, char **argv)
{
  int i;
  struct sockaddr_in servaddr;
  struct hostent *hptr;
  char str[INET_ADDRSTRLEN];

  if (argc != 2)
  {
    fprintf(stderr,"Need a host address\n");
    exit(1);
  }

  hptr=gethostbyname(argv[1]);
  if (hptr==NULL)
  {
    fprintf(stderr,"Host not known\n");
    exit(1);
  }
  if (hptr->h_addrtype != AF_INET)
  {
    fprintf(stderr,"Unknown address type\n");
    exit(1);
  }


  *sockfd=socket(AF_INET,SOCK_STREAM,0);
  if (*sockfd < 0)
  {
    fprintf(stderr,"Unable to open socket\n");
    exit(1);
  }

  bzero(&servaddr,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  servaddr.sin_port=htons(3000);
/*
  if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0)
  {
    fprintf(stderr,"Unusable IP address\n");
    exit(1);
  }
*/
  printf("IP adddress of %s is %s\n",
    hptr->h_name,
    inet_ntop(hptr->h_addrtype,*(hptr->h_addr_list),str,sizeof(str)));

  memcpy(&servaddr.sin_addr,*(hptr->h_addr_list),sizeof(struct in_addr));

  if (connect(*sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr)) < 0)
  {
    fprintf(stderr,"Unable to connect\n");
    exit(1);
  }
  if (read(*sockfd,&i,sizeof(int)) == -1)
  {
    fprintf(stderr,"Unable to read socket\n");
    exit(1);
  }
  if (i != length)
  {
    fprintf(stderr,"Wrong length\n");
    fflush(stderr);
    exit(1);
  }
  total_data_in = 4;
}

void readin(int fd, void *buffer, ssize_t total_size) {
  ssize_t size,sized;
  struct timespec time;

  size = 0;
  while(size < total_size)
  {
    sized = read(fd,buffer+size,total_size-size);
    if (sized==-1)
    {
      fprintf(stderr,"Unable to read input file\n");
      exit(1);
    }
    if (!sized)
    {
      time.tv_sec=1;
      time.tv_nsec=0;
      nanosleep(&time,&time);
    }
    size += sized;
    printf("read %d bytes%c",size,(char)13);
    fflush(stdout);
  }
  printf("\n");
  fflush(stdout);
  total_data_in += total_size;
}


void ode_input(int fd, int *i, double *t, void *x) {
  readin(fd,i,sizeof(int));
  readin(fd,t,sizeof(double));
  readin(fd,x,length*sizeof(double));
}

void ode_input_double(int fd, double *t)
{
  readin(fd,t,sizeof(double));
}

void ode_input_int(int fd, int *i)
{
  readin(fd,i,sizeof(int));
}

/* returns 1 if data completely filled */
int readin_no_block(int fd, void *buffer, ssize_t total_size, ssize_t *filled) {
  fd_set readfds;
  struct timeval timeout;
  ssize_t sized;

  FD_ZERO(&readfds);
  FD_SET(fd,&readfds);
  timeout.tv_sec = 0;
  timeout.tv_usec = 10000;

  select(fd+1,&readfds,NULL,NULL,&timeout);

  if (FD_ISSET(fd,&readfds)) {
    sized = read(fd,buffer+*filled,total_size-*filled);
    if (sized==-1)
    {
      fprintf(stderr,"Unable to read input file\n");
      exit(1);
    }
    *filled += sized;
  }
  total_data_in += *filled;
  return(*filled == total_size);
}


int i_filled=0, t_filled=0, x_filled=0;
int buff_i;
double buff_t;

/* returns 1 if data changed - x will be filled with partial results */
int ode_input_no_block(int fd, int *i, double *t, void *x) {
  if (i_filled != sizeof(int))
    if (! readin_no_block(fd,&buff_i,sizeof(int),&i_filled)) return 0;
  if (t_filled != sizeof(double))
    if (! readin_no_block(fd,&buff_t,sizeof(double),&t_filled)) return 0;
  if (x_filled != length*sizeof(double))
    if (! readin_no_block(fd,x,length*sizeof(double),&x_filled)) return 0;

  memmove(i,&buff_i,sizeof(int));
  memmove(t,&buff_t,sizeof(double));

  i_filled=0, t_filled=0, x_filled=0;

  return 1;
}

#define one_record_size (sizeof(int)+sizeof(double)*(length+1))

void ode_input_go_back(int fd, int iter) {
  iter++;
  total_data_in -= i_filled+t_filled+x_filled;
  i_filled=0, t_filled=0, x_filled=0;
  if (total_data_in < iter*one_record_size)
    iter = total_data_in/one_record_size;
  total_data_in -= iter*one_record_size;
  if (lseek(fd,total_data_in,SEEK_SET) == -1) {
    fprintf(stderr,"unable to reposition in data file\n");
    exit(1);
  }
}


void ode_input_go_forward(int fd, int iter) {
  struct stat sb;

  iter--;
  stat("data.out",&sb);
  total_data_in -= i_filled+t_filled+x_filled;
  i_filled=0, t_filled=0, x_filled=0;
  if (sb.st_size<=total_data_in+iter*one_record_size)
    iter = (sb.st_size-total_data_in)/one_record_size-1;
  if (iter == -1) return;
  total_data_in += iter*one_record_size;
  if (lseek(fd,total_data_in,SEEK_SET) == -1) {
    fprintf(stderr,"unable to reposition in data file\n");
    exit(1);
  }
}
