/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier3d.h"

#define fivedeg 5*PI/180

GLfloat distance,clipat,clipwidth;
double model[4][4];
int show_vel = 0, show_mag = 0, show_vort = 0;
int show_color = 0;
int set_threshold = 0, threshold = 50, temp_threshold;
int go = 0;

extern int fd;
extern vector_small_data_array mag_data;
extern vector_small_data_array vel_data;
extern vector_small_data_array vort_data;
extern int iterates;
extern double max_mag, max_vel, max_vort;
extern double t;
extern int showinterval, showafter;


void matmult(double a[4][4],double b[4][4],double c[4][4])
{
  double d[4][4];
  int i,j,k;
  for (i=0;i<4;i++) for (j=0;j<4;j++)
  {
    d[i][j]=0;
    for (k=0;k<4;k++)
      d[i][j] += a[i][k]*b[k][j];
  }
  for (i=0;i<4;i++) for (j=0;j<4;j++)
    c[i][j] = d[i][j];
}

void mattoGLmat(double a[4][4],GLfloat m[])
{
  int i,j;
  for (i=0;i<4;i++) for (j=0;j<4;j++)
    m[i+j*4] = a[i][j];
}

void init_view() {
  int i,j;
  for(i=0;i<4;i++) for (j=0;j<4;j++)
    model[i][j] = i==j?1.0:0.0;
  model[2][3] = 1.5;
  clipat=1.5 - sqrt(3)/2;
  clipwidth=sqrt(3);
}

void init()
{
  GLfloat fog_color[4] = {0.5,0.5,0.5,1.0};

  glEnable(GL_DEPTH_TEST);

  glEnable(GL_FOG);
  glFogi(GL_FOG_MODE,GL_LINEAR);
  glFogfv(GL_FOG_COLOR,fog_color);
  glFogf(GL_FOG_DENSITY,1.0);

  glClearColor (0.5,0.5,0.5,1.0);

  init_view();
}

void getdataGL() {
  if (getdata()) {
    if (!go)
      glutIdleFunc(NULL);
    glutPostRedisplay();
  }
}

void reshape(int w, int h)
{
  glViewport (0, 0, (GLsizei) w, (GLsizei) h);
}

#define CODE_MAG 0
#define CODE_VEL 1
#define CODE_VORT 2

double color_vals[3][3] = {{1,1,0},{0,1,1},{1,0,1}};
char *color_name[3] = {"yellow","cyan","magenta"};
int code2color[3] = {-1,-1,-1};

void grab_color(int code) {
  int j,k;
  if (code2color[code] == -1)
    for (j=0;j<3;j++) {
      for (k=0;k<3;k++)
        if (code2color[k] == j) break;
      if (k == 3) {
        code2color[code] = j;
        return;
      }
    }
}

void release_color(int code) {
  code2color[code] = -1;
}

void display_vector_field(int code, vector_small_data_array data, double max_data) {
  int i,j,k;
  double x,y,z,u1,u2,u3,w1,w2,w3,c1,c2,c3,m;

  glColor3f (color_vals[code2color[code]][0],color_vals[code2color[code]][1],color_vals[code2color[code]][2]);
  glBegin(GL_LINES);
  for (i=0;i<D;i++) for (j=0;j<D;j++) for (k=0;k<D;k++) 
  {
    x=(i-1.0)/D-0.5;
    y=(j-1.0)/D-0.5;
    z=(k-1.0)/D-0.5;
    w1=data[0][i][j][k];
    w2=data[1][i][j][k];
    w3=data[2][i][j][k];
    if (show_color) {
      m = fabs(w1);
      m = (fabs(w2)>m)?fabs(w2):m;
      m = (fabs(w3)>m)?fabs(w3):m;
      c1 = w1/m/2.0+0.5;
      c2 = w2/m/2.0+0.5;
      c3 = w3/m/2.0+0.5;
      glColor3f (c1, c2, c3);
    }
    if (w1*w1+w2*w2+w3*w3 > threshold*threshold*max_data*max_data/10000.0)
    {
      u1=w1/max_data/D;
      u2=w2/max_data/D;
      u3=w3/max_data/D;
      glVertex3d(x+0.1*u2,y-0.1*u1,z);
      glVertex3d(x+u1,y+u2,z+u3);
      glVertex3d(x-0.1*u2,y+0.1*u1,z);
      glVertex3d(x+u1,y+u2,z+u3);
    }
  }
  glEnd();
}

void display()
{
  GLfloat m[16];

  glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glMatrixMode(GL_MODELVIEW);
  mattoGLmat(model,m); 
  glLoadMatrixf(m);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(60,1,clipat,clipat+clipwidth);
/*
  gluPerspective(60,1,0.01,1000);
*/
  gluLookAt(0,0,0,0,0,1000,0,1,0);

  glFogf(GL_FOG_START,clipat);
  glFogf(GL_FOG_END,clipat+2*clipwidth);

  if (show_vel)
    display_vector_field(CODE_VEL,vel_data,max_vel);

  if (show_mag)
    display_vector_field(CODE_MAG,mag_data,max_mag);

  if (show_vort)
    display_vector_field(CODE_VORT,vort_data,max_vort);

  glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
  double a[4][4];
  int i,j;

  if (set_threshold)
  {
    if (key>='0' && key<='9')
    {
      temp_threshold = temp_threshold*10 + key-'0';
      return;
    }
    else
    {
      threshold = temp_threshold;
      printf("Threshold = %d%%\n",threshold);
      set_threshold = 0;
    }
  }

  for(i=0;i<4;i++) for (j=0;j<4;j++)
    a[i][j] = (i==j)?1.0:0.0;

  printf("key = %c\n",key);

  switch(key)
  {
    case 't':
      set_threshold = 1;
      temp_threshold = 0;
      break;
    case 'r':
      if (threshold<100) threshold++;
      printf("Threshold = %d%%\n",threshold);
      break;
    case 'R':
      if (threshold>0) threshold--;
      printf("Threshold = %d%%\n",threshold);
      break;
    case '+':
      clipat += 0.5/D;
      break;
    case '-':
      if (clipat > 1.5/D)
        clipat -= 0.5/D;
      break;
    case 'w':
      clipwidth += 0.5/D;
      break;
    case 'W':
      if (clipwidth > 0.5/D)
        clipwidth -= 0.5/D;
      break;
    case 'n':
      glutIdleFunc(getdataGL);
      break;
#ifndef SOCKET_VERSION
    case 'N':
      ode_input_go_forward(fd,10);
      glutIdleFunc(getdataGL);
      break;
    case 'p':
      if (iterates != 0) {
        ode_input_go_back(fd,1);
        glutIdleFunc(getdataGL);
      }
      break;
    case 'P':
      if (iterates != 0) {
        ode_input_go_back(fd,10);
        glutIdleFunc(getdataGL);
      }
      break;
#endif
    case 's':
      go ^= 1;
      if (go) {
        printf("reading data continuously\n");
        glutIdleFunc(getdataGL);
      } else {
        printf("not reading data continuously\n");
        glutIdleFunc(NULL);
      }
      break;
    case 'u':
      show_vel ^=1;
      if (show_vel) {
        grab_color(CODE_VEL);
        printf("vel is colored %s\n",color_name[code2color[CODE_VEL]]);
      } else
        release_color(CODE_VEL);
      break;
    case 'm':
      show_mag ^=1;
      if (show_mag) {
        grab_color(CODE_MAG);
        printf("mag is colored %s\n",color_name[code2color[CODE_MAG]]);
      } else
        release_color(CODE_MAG);
      break;
    case 'v':
      show_vort ^=1;
      if (show_vort) {
        grab_color(CODE_VORT);
        printf("vort is colored %s\n",color_name[code2color[CODE_VORT]]);
      } else
        release_color(CODE_VORT);
      break;
    case 'c':
      show_color ^=1;
      break;
    case 'h':
      init_view();
      break;
    case 'q':
      exit(0);
   }
  fflush(stdout);
  glutPostRedisplay();
}

void specialkey(int key, int x, int y)
{
  double a[4][4],t[4][4];
  int i,j,mod;

  mod = glutGetModifiers();

  for(i=0;i<4;i++) for (j=0;j<4;j++)
  {
    t[i][j] = a[i][j] = (i==j)?1.0:0.0;
  }

  switch(key)
  {
    case GLUT_KEY_LEFT: 
      a[0][0] = cos(fivedeg);
      a[0][2] = -sin(fivedeg);
      a[2][0] = sin(fivedeg);
      a[2][2] = cos(fivedeg);
      break;
    case GLUT_KEY_RIGHT: 
      a[0][0] = cos(fivedeg);
      a[0][2] = sin(fivedeg);
      a[2][0] = -sin(fivedeg);
      a[2][2] = cos(fivedeg);
      break;
    case GLUT_KEY_UP: 
      a[1][1] = cos(fivedeg);
      a[1][2] = -sin(fivedeg);
      a[2][1] = sin(fivedeg);
      a[2][2] = cos(fivedeg);
      break;
    case GLUT_KEY_DOWN: 
      a[1][1] = cos(fivedeg);
      a[1][2] = sin(fivedeg);
      a[2][1] = -sin(fivedeg);
      a[2][2] = cos(fivedeg);
      break;
    case GLUT_KEY_PAGE_UP:
      if (clipat > 0.1+1.0/D)
      {
        a[2][3] = -0.1;
        clipat  += -0.1;
      }
      break;
    case GLUT_KEY_PAGE_DOWN:
      a[2][3] = 0.1;
      clipat  += 0.1;
      break;
  }
  if (!(mod & GLUT_ACTIVE_SHIFT))
  {
    t[2][3] = -clipat-clipwidth/2;
    matmult(a,t,a);
    t[2][3] = clipat+clipwidth/2;
    matmult(t,a,a);
  }
  matmult(a,model,model);
  glutPostRedisplay();
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize (800, 800); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("3D Navier-Stokes");
   initialise(argc,argv);
   init ();
   glutDisplayFunc(display); 
   glutReshapeFunc(reshape);
   glutSpecialFunc(specialkey);
   glutKeyboardFunc(keyboard);
   glutIdleFunc(getdataGL);
   glutMainLoop();
   return 0;   /* ANSI C requires main to return int. */
}
