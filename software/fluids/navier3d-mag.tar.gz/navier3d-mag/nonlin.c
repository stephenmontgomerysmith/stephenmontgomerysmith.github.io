/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier3d.h"

fftwnd_plan plan_forward, plan_backward;

scalar_large_fourier_array temp_fourier;

double dot_prod_data(vector_data_array u, vector_data_array v) {
  int i,j,k,l;
  double sum = 0.0;
  for (l=0;l<3;l++) for (i=0;i<P;i++) for (j=0;j<P;j++) for (k=0;k<P;k++)
    sum += u[l][i][j][k]*v[l][i][j][k];
  return(sum/P/P/P);
}

double norm_data(vector_data_array v) {
  int i,j,k,l;
  double sum = 0.0;
  for (l=0;l<3;l++) for (i=0;i<P;i++) for (j=0;j<P;j++) for (k=0;k<P;k++)
    sum += v[l][i][j][k]*v[l][i][j][k];
  return(sqrt(sum/P/P/P));
}

double infty_norm_data(vector_data_array v) {
  int i,j,k;
  double mag, max = 0.0;
  for (i=0;i<P;i++) for (j=0;j<P;j++) for (k=0;k<P;k++) {
    mag = v[0][i][j][k]*v[0][i][j][k] + v[1][i][j][k]*v[1][i][j][k]
          + v[2][i][j][k]*v[2][i][j][k];
    if (mag>max) max = mag;
  }
  return(sqrt(max));
}

void create_plans() {
  plan_forward = rfftw3d_create_plan(P,P,P,FFTW_REAL_TO_COMPLEX,FFTW_MEASURE);
  plan_backward = rfftw3d_create_plan(P,P,P,FFTW_COMPLEX_TO_REAL,FFTW_MEASURE);
/*
  plan_forward = rfftw3d_create_plan(P,P,P,FFTW_REAL_TO_COMPLEX,FFTW_ESTIMATE);
  plan_backward = rfftw3d_create_plan(P,P,P,FFTW_COMPLEX_TO_REAL,FFTW_ESTIMATE);
*/
}

void destroy_plans(){
  rfftwnd_destroy_plan(plan_forward);
  rfftwnd_destroy_plan(plan_backward);
}

void calc_fourier(scalar_fourier_array fourier, scalar_data_array data) {
  int i,j,k;
  rfftwnd_one_real_to_complex(plan_forward,&data[0][0][0],&temp_fourier[0][0][0]);
  memset(fourier,0,sizeof(scalar_fourier_array));
  for (i=-N;i<=N;i++) for (j=-N;j<=N;j++) for (k=0;k<=N;k++) {
    fourier[ntod(i)][ntod(j)][k].re = temp_fourier[ntop(i)][ntop(j)][k].re/P/P/P;
    fourier[ntod(i)][ntod(j)][k].im = temp_fourier[ntop(i)][ntop(j)][k].im/P/P/P;
  }
}

void calc_data(scalar_data_array data, scalar_fourier_array fourier) {
  int i,j,k;
  memset(temp_fourier,0,sizeof(scalar_large_fourier_array));
  for (i=-N;i<=N;i++) for (j=-N;j<=N;j++) for (k=0;k<=N;k++) {
    temp_fourier[ntop(i)][ntop(j)][k].re = fourier[ntod(i)][ntod(j)][k].re;
    temp_fourier[ntop(i)][ntop(j)][k].im = fourier[ntod(i)][ntod(j)][k].im;
  }
  rfftwnd_one_complex_to_real(plan_backward,&temp_fourier[0][0][0],&data[0][0][0]);
}

double norm_mag, norm_vel, norm_vort,
       max_mag,  max_vel,  max_vort;

vector_data_array vel_data, vort_data;
vector_fourier_array vort, vel;
#define vel_cross_vort_data vort_data
#define mag_data vort_data
#define vel_dot_mag_data vort_data[0]
#define vel_dot_mag vort[0]

/* non_lin = vel cross vort - grad(vel . mag)
   where vel = leray(mag), vort = curl mag.
*/
void calc_non_lin(vector_fourier_array non_lin, vector_fourier_array mag,
                  int set_norm_max) {
  int i,j,k;
  double v0, v1, v2;

  memcpy(vel,mag,sizeof(vector_fourier_array));
  leray(vel);
  calc_data(vel_data[0],vel[0]);
  calc_data(vel_data[1],vel[1]);
  calc_data(vel_data[2],vel[2]);

  if (set_norm_max) {
    norm_vel = norm_fourier(vel);
    max_vel = infty_norm_data(vel_data);
  }

  calc_curl(vort,mag);
  calc_data(vort_data[0],vort[0]);
  calc_data(vort_data[1],vort[1]);
  calc_data(vort_data[2],vort[2]);

  if (set_norm_max) {
    norm_vort = norm_fourier(vort);
    max_vort = infty_norm_data(vort_data);
  }

  for (i=0;i<P;i++) for (j=0;j<P;j++) for (k=0;k<P;k++) {
    v0 =
      vel_data[1][i][j][k] * vort_data[2][i][j][k]
      -vel_data[2][i][j][k] * vort_data[1][i][j][k];
    v1 =
      vel_data[2][i][j][k] * vort_data[0][i][j][k]
      -vel_data[0][i][j][k] * vort_data[2][i][j][k];
    v2 =
      vel_data[0][i][j][k] * vort_data[1][i][j][k]
      -vel_data[1][i][j][k] * vort_data[0][i][j][k];
    vel_cross_vort_data[0][i][j][k] = v0;
    vel_cross_vort_data[1][i][j][k] = v1;
    vel_cross_vort_data[2][i][j][k] = v2;
  }

  calc_fourier(non_lin[0],vel_cross_vort_data[0]);
  calc_fourier(non_lin[1],vel_cross_vort_data[1]);
  calc_fourier(non_lin[2],vel_cross_vort_data[2]);

  calc_data(mag_data[0],mag[0]);
  calc_data(mag_data[1],mag[1]);
  calc_data(mag_data[2],mag[2]);

  if (set_norm_max) {
    norm_mag = norm_fourier(mag);
    max_mag = infty_norm_data(mag_data);
  }

  for (i=0;i<P;i++) for (j=0;j<P;j++) for (k=0;k<P;k++) {
    vel_dot_mag_data[i][j][k] =
      vel_data[0][i][j][k] * mag_data[0][i][j][k]
      + vel_data[1][i][j][k] * mag_data[1][i][j][k]
      + vel_data[2][i][j][k] * mag_data[2][i][j][k];
  }

  calc_fourier(vel_dot_mag,vel_dot_mag_data);

  for (i=-N;i<=N;i++) for (j=-N;j<=N;j++) for (k=0;k<=N;k++) {
    non_lin[0][ntod(i)][ntod(j)][k].re += i*vel_dot_mag[ntod(i)][ntod(j)][k].im;
    non_lin[0][ntod(i)][ntod(j)][k].im -= i*vel_dot_mag[ntod(i)][ntod(j)][k].re;
    non_lin[1][ntod(i)][ntod(j)][k].re += j*vel_dot_mag[ntod(i)][ntod(j)][k].im;
    non_lin[1][ntod(i)][ntod(j)][k].im -= j*vel_dot_mag[ntod(i)][ntod(j)][k].re;
    non_lin[2][ntod(i)][ntod(j)][k].re += k*vel_dot_mag[ntod(i)][ntod(j)][k].im;
    non_lin[2][ntod(i)][ntod(j)][k].im -= k*vel_dot_mag[ntod(i)][ntod(j)][k].re;
  }
}
 
void apply_laplacian(vector_fourier_array dest, vector_fourier_array src, double t) {
  int i,j,k,l;
  for(l=0;l<3;l++) for(i=-N;i<=N;i++) for(j=-N;j<=N;j++) for(k=0;k<=N;k++) {
    dest[l][ntod(i)][ntod(j)][k].re = 
      src[l][ntod(i)][ntod(j)][k].re * exp(-t*(i*i+j*j+k*k));
    dest[l][ntod(i)][ntod(j)][k].im = 
      src[l][ntod(i)][ntod(j)][k].im * exp(-t*(i*i+j*j+k*k));
  }
}


