#if !defined( lint ) && !defined( SABER )
/* #ident	"@(#)version.h	5.00 2000/10/20 xlockmore" */

#endif

#define VERSION "xlockmore-5.00"
