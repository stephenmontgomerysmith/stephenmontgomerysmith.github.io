void init(int width, int height);
void idle();
void display();
