/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier2d.h"

void derivs(double *vel, double *diff_vel);
void add_lap(double *vel, double *diff_vel, double h);

double midx[length], adddiffx[length], diffx[length];
extern double vort[length];
#define olddiffx midx

int iter;
double current_h;

void ode_initialise() {
  iter = 0;
  current_h = 0;
}

void ode_finish() {
}


/* The scheme is:

   (x[n+1]-x[n])/h = visc lap(x[n]+x[n+1])/2 + adddiffx

   where in the first step adddiffx is given by the midpoint method:
   derivs(x[n]+0.5 h derivs(x[n]))
   and after that is given by the Adams Bashforth Method:
   1.5 derivs(x[n]) - 0.5 derivs(x[n-1])
*/

void ode_solve(double *x, double h) {
  int i;

  if (h!=current_h) {
    iter = 0;
    current_h = h;
  }

  if (iter < 1) {
/* midpoint method */
    derivs(x,diffx);
    for (i=0;i<length;i++)
      midx[i] = x[i] + 0.5*h*diffx[i];
    derivs(midx,adddiffx);
  } else {
/* adams bashforth method */
    derivs(x,diffx);
    for (i=0;i<length;i++)
      adddiffx[i] = 1.5*diffx[i]-0.5*olddiffx[i];
  }

  add_lap(x,adddiffx,h);
  memmove(olddiffx,diffx,sizeof(double)*length);
  iter++;
}
