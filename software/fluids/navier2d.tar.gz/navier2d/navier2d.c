/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier2d.h"

void ode_initialise();
void ode_finish();
void ode_solve(vector_fourier_array vel, double h);

extern scalar_data_array vort_data;
extern scalar_fourier_array vort;
extern vector_fourier_array vel;
extern vector_data_array vel_data;

double calc_h(double max_vel, double max_vort) {
  double h = 1;
  double h1 = 0.5/P/max_vel;
/* double h2 = 0.5/max_vort; */
/* double h3 = 0.01/viscosity/N/N; to avoid stiffness problems */
/* if (h2<h1) h1 = h2; */
/* if (h3<h1) h1 = h3; */
  while(h>h1) h/=10;
  while(h<h1/10) h*=10;
  if(h<h1/5) h*=5;
  else if(h<h1/2) h*=2;
  return(h);
}

int main () {
  vector_fourier_array vel;

  int iter;

  double max_vel, max_vort;
  double h,t;
  int dataout;
  int showinterval = 100;

  prepare_output(&dataout);
  create_plans();
  ode_initialise();

  init_data(vel_data);

  calc_fourier(vel[0],vel_data[0]);
  calc_fourier(vel[1],vel_data[1]);

  leray(vel);

  t = 0.0;

  calc_vel_vort_data(vel);
  max_vel = infty_norm_vector_data(vel_data);
  max_vort = infty_norm_scalar_data(vort_data);

  h = calc_h(max_vel,max_vort);

  ode_output(dataout,0,t,&vel[0][0][0]);

  for (iter=1;iter<=2000000;iter++) {
    ode_solve(vel,h);
    t += h;

    calc_vel_vort_data(vel);
    max_vel = infty_norm_vector_data(vel_data);
    max_vort = infty_norm_scalar_data(vort_data);

    h = calc_h(max_vel,max_vort);

    if (iter%showinterval == 0) {
      ode_output(dataout,iter,t,&vel[0][0][0]);
    }
  }
  return(0);
}
