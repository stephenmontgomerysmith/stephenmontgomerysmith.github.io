/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier2d.h"

fftwnd_plan plan_display_forward, plan_display_backward;

scalar_fourier_array temp_fourier;

void create_small_plans() {
  plan_display_forward = rfftw2d_create_plan(D,D,FFTW_REAL_TO_COMPLEX,FFTW_ESTIMATE);
  plan_display_backward = rfftw2d_create_plan(D,D,FFTW_COMPLEX_TO_REAL,FFTW_ESTIMATE);
}

void destroy_small_plans(){
  rfftwnd_destroy_plan(plan_display_forward);
  rfftwnd_destroy_plan(plan_display_backward);
}

double infty_norm_vector_small_data(vector_small_data_array v) {
  int i,j;
  double mag, max = 0.0;
  for (i=0;i<D;i++) for (j=0;j<D;j++) {
    mag = v[0][i][j]*v[0][i][j] + v[1][i][j]*v[1][i][j];
    if (mag>max) max = mag;
  }
  return(sqrt(max));
}

double infty_norm_scalar_small_data(scalar_small_data_array v) {
  int i,j;
  double mag, max = 0.0;
  for (i=0;i<D;i++) for (j=0;j<D;j++) {
    mag = fabs(v[i][j]);
    if (mag>max) max = mag;
  }
  return(max);
}

void calc_small_data(scalar_small_data_array data, 
                       scalar_fourier_array fourier) {
  memmove(temp_fourier,fourier,sizeof(scalar_fourier_array));
  rfftwnd_one_complex_to_real(plan_display_backward,&temp_fourier[0][0],&data[0][0]);
}

int fd;
vector_fourier_array vel;
scalar_fourier_array vort;
vector_small_data_array vel_data;
scalar_small_data_array vort_data;
double max_vel, max_vort;
int iterates;
double t;
int showinterval, showafter;

int getdata() {
  int ret_val = 0;
  if (ode_input_no_block(fd,&iterates,&t,&vel[0][0][0])) {
    printf("[%d] t = %g\n",iterates,t);
    if (iterates%showinterval == 0 && iterates >= showafter) {
      calc_small_data(vel_data[0],vel[0]);
      calc_small_data(vel_data[1],vel[1]);
      calc_curl(vort,vel);
      calc_small_data(vort_data,vort);
      max_vel = infty_norm_vector_small_data(vel_data);
      max_vort = infty_norm_scalar_small_data(vort_data);
      printf("max_vel = %g\n",max_vel);
      printf("max_vort = %g\n",max_vort);
      ret_val = 1;
    }
  }
  fflush(stdout);
  return ret_val;
}

void gettime() {
  ode_input(fd,&iterates,&t,&vel[0][0][0]);
  printf("[%d] t = %g\n",iterates,t); fflush(stdout);
  fflush(stdout);
}

void initialise(int argc, char **argv) {
  create_small_plans();

#if defined(SOCKET_VERSION)
  prepare_socket_input(&fd,argc,argv);
#else
  prepare_input(&fd);
#endif
  showinterval = 1;
  showafter = 0;
}

