/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier2d.h"

fftwnd_plan plan_forward, plan_backward;

int data_already_set = 0;
scalar_data_array vort_data;
scalar_fourier_array vort;
vector_data_array vel_data; /* also is vel_cross_vort_data */
#define vel_cross_vort_data vel_data
scalar_large_fourier_array temp_fourier;


double infty_norm_vector_data(vector_data_array v) {
  int i,j;
  double mag, max = 0.0;
  for (i=0;i<P;i++) for (j=0;j<P;j++) {
    mag = v[0][i][j]*v[0][i][j] + v[1][i][j]*v[1][i][j];
    if (mag>max) max = mag;
  }
  return(sqrt(max));
}

double infty_norm_scalar_data(scalar_data_array v) {
  int i,j;
  double mag, max = 0.0;
  for (i=0;i<P;i++) for (j=0;j<P;j++) {
    mag = fabs(v[i][j]);
    if (mag>max) max = mag;
  }
  return(max);
}

void create_plans() {
  plan_forward = rfftw2d_create_plan(P,P,FFTW_REAL_TO_COMPLEX,FFTW_ESTIMATE);
  plan_backward = rfftw2d_create_plan(P,P,FFTW_COMPLEX_TO_REAL,FFTW_ESTIMATE);
}

void destroy_plans(){
  rfftwnd_destroy_plan(plan_forward);
  rfftwnd_destroy_plan(plan_backward);
}

void calc_fourier(scalar_fourier_array fourier, scalar_data_array data) {
  int i,j;
  rfftwnd_one_real_to_complex(plan_forward,&data[0][0],&temp_fourier[0][0]);
  memset(fourier,0,sizeof(scalar_fourier_array));
  for (i=-N;i<=N;i++) for (j=0;j<=N;j++) {
    fourier[ntod(i)][j].re = temp_fourier[ntop(i)][j].re/P/P;
    fourier[ntod(i)][j].im = temp_fourier[ntop(i)][j].im/P/P;
  }
}

void calc_data(scalar_data_array data, scalar_fourier_array fourier) {
  int i,j;
  memset(temp_fourier,0,sizeof(scalar_large_fourier_array));
  for (i=-N;i<=N;i++) for (j=0;j<=N;j++) {
    temp_fourier[ntop(i)][j].re = fourier[ntod(i)][j].re;
    temp_fourier[ntop(i)][j].im = fourier[ntod(i)][j].im;
  }
  rfftwnd_one_complex_to_real(plan_backward,&temp_fourier[0][0],&data[0][0]);
}

void leray(vector_fourier_array v) {
  int i,j;
  double dot_prod;
  for (i=-N;i<=N;i++) for (j=0;j<=N;j++)
  if (i!=0 || j!=0) {
    dot_prod = (i*v[0][ntod(i)][j].re 
                + j*v[1][ntod(i)][j].re)/
               (i*i+j*j);
    v[0][ntod(i)][j].re -= i*dot_prod;
    v[1][ntod(i)][j].re -= j*dot_prod;
    dot_prod = (i*v[0][ntod(i)][j].im 
                + j*v[1][ntod(i)][j].im)/
               (i*i+j*j);
    v[0][ntod(i)][j].im -= i*dot_prod;
    v[1][ntod(i)][j].im -= j*dot_prod;
  } else {
    v[0][ntod(i)][j].re = 0;
    v[1][ntod(i)][j].re = 0;
    v[0][ntod(i)][j].im = 0;
    v[1][ntod(i)][j].im = 0;
  }
}

void calc_vel_vort_data(vector_fourier_array v) {
  calc_data(vel_data[0],v[0]);
  calc_data(vel_data[1],v[1]);

  calc_curl(vort,v);

  calc_data(vort_data,vort);

  data_already_set = 1;
}

void calc_leray_ugradu(vector_fourier_array leray_ugradu, vector_fourier_array v) {
  int i,j;
  double v0,v1;

  if (!data_already_set)
    calc_vel_vort_data(v);
  data_already_set = 0;

  for (i=0;i<P;i++) for (j=0;j<P;j++) {
    v0 =
      vel_data[1][i][j] * vort_data[i][j];
    v1 =
      -vel_data[0][i][j] * vort_data[i][j];
    vel_cross_vort_data[0][i][j] = v0;
    vel_cross_vort_data[1][i][j] = v1;
  }

  calc_fourier(leray_ugradu[0],vel_cross_vort_data[0]);
  calc_fourier(leray_ugradu[1],vel_cross_vort_data[1]);
  leray(leray_ugradu);
}
 
void apply_laplacian(vector_fourier_array dest, vector_fourier_array src, double t) {
  int i,j,l;
  for(l=0;l<2;l++) for(i=-N;i<=N;i++) for(j=0;j<=N;j++) {
    dest[l][ntod(i)][j].re = 
      src[l][ntod(i)][j].re * exp(-t*(i*i+j*j));
    dest[l][ntod(i)][j].im = 
      src[l][ntod(i)][j].im * exp(-t*(i*i+j*j));
  }
}


