/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier2d.h"

extern vector_fourier_array vel;
extern vector_small_data_array vel_data;
extern scalar_fourier_array vort;
extern scalar_small_data_array vort_data;
extern int iterates;
extern double max_vel, max_vort;
extern double t;
extern int showinterval, showafter;

int go;

void init() {
  glClearColor (1.0, 1.0, 1.0, 0.0);
  glShadeModel (GL_FLAT);
  gluOrtho2D(0.0,1.0,0.0,1.0);
}

void getdataGL() {
  if (getdata()) {
    if (!go)
      glutIdleFunc(NULL);
    glutPostRedisplay();
  }
}


void reshape(int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-50.0, 50.0, -50.0, 50.0, -1.0, 1.0);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

void display()
{
  int i,j;
  double x,y,xvec,yvec,scolor;

  glClear (GL_COLOR_BUFFER_BIT);

  for (i=0;i<D;i++)
  {
    for (j=0;j<D;j++)
    {
      scolor = vort_data[i][D-1-j]/max_vort;
      if (scolor > 0.0)
        glColor3f(1.0,1.0-scolor,1.0-scolor);
      else
        glColor3f(1.0+scolor,1.0+scolor,1.0);
      glRectf((i-0.5)/(double)D,(j-0.5)/(double)D,
              (i+0.5)/(double)D,(j+0.5)/(double)D);
    }
  }

  glColor3f (0.0, 0.0, 0.0);

  glBegin(GL_LINES);
  for (i=0;i<D;i++)
  {
    for (j=0;j<D;j++)
    {
      x = (double)i/(double)D;
      y = (double)j/(double)D;
      xvec = +vel_data[0][i][D-1-j]/max_vel/D/2.0;
      yvec = -vel_data[1][i][D-1-j]/max_vel/D/2.0;
      glVertex2f(x+yvec/2-xvec,y-xvec/2-yvec);
      glVertex2f(x+xvec,y+yvec);
      glVertex2f(x-yvec/2-xvec,y+xvec/2-yvec);
      glVertex2f(x+xvec,y+yvec);
    }
  }
  glEnd();

  glutSwapBuffers();
}



void keyboard(unsigned char key, int x, int y)
{
  printf("key = %c\n",key);

  switch(key)
  {
    case 'n':
      glutIdleFunc(getdataGL);
      break;
    case 'p':
/*
*/
      break;
    case 's':
      go ^= 1;
      if (go) {
        printf("reading data continuously\n");
        glutIdleFunc(getdataGL);
      } else {
        printf("not reading data continuously\n");
        glutIdleFunc(NULL);
      }
      break;
    case 'q':
      exit(0);
   }
  fflush(stdout);
  glutPostRedisplay();
}


int main(int argc, char** argv)
{

   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
   glutInitWindowSize (800, 800); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow ("3D Navier-Stokes");
   initialise(argc,argv);
   init ();
   glutDisplayFunc(display); 
/*   glutReshapeFunc(reshape); */
   glutKeyboardFunc(keyboard);
   glutIdleFunc(getdataGL);
   glutMainLoop();
   return 0;   /* ANSI C requires main to return int. */
}
