/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier3d.h"

void calc_curl(vector_fourier_array w, vector_fourier_array v) {
  int i,j,k;
  double w0r,w0i,w1r,w1i,w2r,w2i;

  if (w != v) memset(w,0,sizeof(vector_fourier_array));
  for (i=-N;i<=N;i++) for (j=-N;j<=N;j++) for (k=0;k<=N;k++) {
    w0r = 
      -j*v[2][ntod(i)][ntod(j)][k].im
      +k*v[1][ntod(i)][ntod(j)][k].im;
    w0i = 
      +j*v[2][ntod(i)][ntod(j)][k].re
      -k*v[1][ntod(i)][ntod(j)][k].re;
    w1r = 
      -k*v[0][ntod(i)][ntod(j)][k].im
      +i*v[2][ntod(i)][ntod(j)][k].im;
    w1i = 
      +k*v[0][ntod(i)][ntod(j)][k].re
      -i*v[2][ntod(i)][ntod(j)][k].re;
    w2r = 
      -i*v[1][ntod(i)][ntod(j)][k].im
      +j*v[0][ntod(i)][ntod(j)][k].im;
    w2i = 
      +i*v[1][ntod(i)][ntod(j)][k].re
      -j*v[0][ntod(i)][ntod(j)][k].re;

    w[0][ntod(i)][ntod(j)][k].re = w0r;
    w[0][ntod(i)][ntod(j)][k].im = w0i;
    w[1][ntod(i)][ntod(j)][k].re = w1r;
    w[1][ntod(i)][ntod(j)][k].im = w1i;
    w[2][ntod(i)][ntod(j)][k].re = w2r;
    w[2][ntod(i)][ntod(j)][k].im = w2i;
  }
}

double norm_fourier(vector_fourier_array v) {
  int i,j,k,l;
  double sum = 0.0;
  for (l=0;l<3;l++) for (i=0;i<D;i++) for (j=0;j<D;j++) {
    sum += v[l][i][j][0].re*v[l][i][j][0].re + v[l][i][j][0].im*v[l][i][j][0].im;
    for (k=1;k<D/2+1;k++)
      sum += 2*(v[l][i][j][k].re*v[l][i][j][k].re + v[l][i][j][k].im*v[l][i][j][k].im);
  }
  return(sqrt(sum));
}

double dot_prod_fourier(vector_fourier_array u, vector_fourier_array v) {
  int i,j,k,l;
  double sum = 0.0;
  for (l=0;l<3;l++) for (i=0;i<D;i++) for (j=0;j<D;j++) {
    sum += u[l][i][j][0].re*v[l][i][j][0].re + u[l][i][j][0].im*v[l][i][j][0].im;
    for (k=1;k<D/2+1;k++)
      sum += 2*(u[l][i][j][k].re*v[l][i][j][k].re + u[l][i][j][k].im*v[l][i][j][k].im);
  }
  return sum;
}

