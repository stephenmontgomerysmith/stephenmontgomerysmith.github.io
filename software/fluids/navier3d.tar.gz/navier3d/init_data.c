/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier3d.h"

void add_ball(vector_data_array vel, 
         double c1, double c2, double c3,
         double d1, double d2, double d3,
         double r) {
  int i,j,k;

  for(i=floor(P*(c1-r));i<=ceil(P*(c1+r));i++)
    for(j=floor(P*(c2-r));j<=ceil(P*(c2+r));j++)
      for(k=floor(P*(c3-r));k<=ceil(P*(c3+r));k++)
        if ((i-P*c1)*(i-P*c1)+(j-P*c2)*(j-P*c2)+(k-P*c3)*(k-P*c3) <= r*r*P*P) {
    vel[0][i][j][k] += d1;
    vel[1][i][j][k] += d2;
    vel[2][i][j][k] += d3;
  }
}

void init_data(vector_data_array vel) {

  memset(vel,0,sizeof(vector_data_array));

  add_ball(vel, 0.25,0.5,0.5, 0.8,0.6,0, 0.20);
  add_ball(vel, 0.75,0.5,0.5, -1,0,0, 0.20);

}

void init_fourier(vector_fourier_array vel) {
  int i,j,k,l;

  memset(vel,0,sizeof(vector_fourier_array));

  for (l=0;l<3;l++) for (i=-N;i<=N;i++) for (j=-N;j<=N;j++) for (k=0;k<=N;k++) 
    if (i!=0 || j!=0 || k!=0) {
    vel[l][ntod(i)][ntod(j)][k].re =
      ((double)random()/LONG_MAX - 0.5)/pow(i*i+j*j+k*k,(5.0/3.0+2.0)/2.0);
    vel[l][ntod(i)][ntod(j)][k].im =
      ((double)random()/LONG_MAX - 0.5)/pow(i*i+j*j+k*k,(5.0/3.0+2.0)/2.0);
  }
}
