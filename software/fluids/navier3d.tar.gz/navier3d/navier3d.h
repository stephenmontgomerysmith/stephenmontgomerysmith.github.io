/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include <sys/types.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <math.h>
#include <strings.h>
#include <GL/glut.h>
#include <rfftw.h>
#include <limits.h>
#include <fcntl.h>

#define PI 3.14159265356
#define fivedeg 5*PI/180

#define viscosity 0.001

#define N 31 /* Fourier coefficents from -N to N */
#define D 64 /* D is size of display data array - must be power of two > (2N+1) */
#define P 128 /* P is size of data array - must be power of two > 2(2N+1) */
#define length 6*D*D*(D/2+1)

#define ntop(n) ((n)<0?(n)+P:(n))
#define ntod(n) ((n)<0?(n)+D:(n))

#define debug 1

#define printfouriernorm(v) if (debug) printf("norm(%s) = %g\n",#v,norm_fourier(v))
#define printdatanorm(v) if (debug) printf("norm(%s) = %g\n",#v,norm_data(v))
#define here(i) printf("Here %d\n",(i)); fflush(stdout)

typedef fftw_complex scalar_large_fourier_array[P][P][P/2+1];
typedef fftw_real scalar_data_array[P][P][P],
                  vector_data_array[3][P][P][P];
typedef fftw_complex scalar_fourier_array[D][D][D/2+1],
                     vector_fourier_array[3][D][D][D/2+1];
typedef fftw_real scalar_small_data_array[D][D][D],
                  vector_small_data_array[3][D][D][D];

double norm_fourier(vector_fourier_array v);
double dot_prod_fourier(vector_fourier_array u, vector_fourier_array v);
double norm_data(vector_data_array v);
double infty_norm_data(vector_data_array v);

void create_plans();
void create_non_optimized_plans();
void destroy_plans();
void calc_fourier(scalar_fourier_array fourier, scalar_data_array data);
void calc_data(scalar_data_array data, scalar_fourier_array fourier);
void leray(vector_fourier_array v);
void calc_vel_vort_data(vector_fourier_array v);
void calc_leray_ugradu(vector_fourier_array leray_ugradu, vector_fourier_array vel);
void apply_laplacian(vector_fourier_array dest, vector_fourier_array src, double t);

void calc_curl(vector_fourier_array w, vector_fourier_array v);

int if_output_exists(int *fd);
void prepare_output(int *fd,int new);
void prepare_socket_output(int *connfd);
void ode_output(int fd, int i, double t, void *x);
void ode_output_double(int fd, double t);
void ode_output_int(int fd, int i);
void prepare_input(int *fd);
void prepare_socket_input(int *sockfd, int argc, char **argv);
void ode_input(int fd, int *i, double *t, void *x);
void ode_input_double(int fd, double *t);
void ode_input_int(int fd, int *i);
int ode_input_no_block(int fd, int *i, double *t, void *x);
void ode_input_go_back(int fd,int iter);

double norm_small_data(scalar_small_data_array v);
double infty_norm_small_data(vector_small_data_array v);
void create_small_plans();
void destroy_small_plans();
int getdata();
void gettime();
void initialise(int argc, char **argv);

void init_data(vector_data_array vel);
void init_fourier(vector_fourier_array vel);


