/*
Copyright (c) 2000 Stephen Montgomery-Smith
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of Stephen Montgomery-Smith nor the names of his 
   contributors may be used to endorse or promote products derived from 
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE STEPHEN MONTGOMERY-SMITH AND CONTRIBUTORS 
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN MONTGOMERY-SMITH OR 
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
POSSIBILITY OF SUCH DAMAGE.
*/

#include "navier3d.h"

fftwnd_plan  plan_small_backward;

scalar_fourier_array temp_fourier;

double infty_norm_small_data(vector_small_data_array v) {
  int i,j,k;
  double mag, max = 0.0;
  for (i=0;i<D;i++) for (j=0;j<D;j++) for (k=0;k<D;k++) {
    mag = v[0][i][j][k]*v[0][i][j][k] + v[1][i][j][k]*v[1][i][j][k]
          + v[2][i][j][k]*v[2][i][j][k];
    if (mag>max) max = mag;
  }
  return(sqrt(max));
}

void create_small_plans() {
  plan_small_backward = rfftw3d_create_plan(D,D,D,FFTW_COMPLEX_TO_REAL,FFTW_ESTIMATE);
}

void destroy_small_plans(){
  rfftwnd_destroy_plan(plan_small_backward);
}

void calc_small_data(scalar_small_data_array data, 
                       scalar_fourier_array fourier) {
  memmove(temp_fourier,fourier,sizeof(scalar_fourier_array));
  rfftwnd_one_complex_to_real(plan_small_backward,&temp_fourier[0][0][0],&data[0][0][0]);
}

int fd;
vector_fourier_array vel; /* also is vort */
#define vort vel
vector_small_data_array vel_data;
vector_small_data_array vort_data;
int iterates;
double max_vel, max_vort, norm_vel, last_norm_vel = 0.0, norm_vort;
double t, last_t=0;
int showinterval, showafter;

int getdata() {
  int ret_val = 0;
  if (ode_input_no_block(fd,&iterates,&t,&vel[0][0][0][0])) {
    printf("[%d] t = %g\n",iterates,t);
    if (iterates%showinterval == 0 && iterates >= showafter) {
      norm_vel = norm_fourier(vel);
      calc_small_data(vel_data[0],vel[0]);
      calc_small_data(vel_data[1],vel[1]);
      calc_small_data(vel_data[2],vel[2]);
      calc_curl(vort,vel);
      norm_vort = norm_fourier(vort);
      calc_small_data(vort_data[0],vort[0]);
      calc_small_data(vort_data[1],vort[1]);
      calc_small_data(vort_data[2],vort[2]);
      max_vel = infty_norm_small_data(vel_data);
      max_vort = infty_norm_small_data(vort_data);
      printf("norm_vel = %g\n",norm_vel);
      printf("norm_vort = %g\n",norm_vort);
      if (t!=0) {
        printf("actual energy change = %g\n",
          norm_vel*norm_vel-last_norm_vel*last_norm_vel);
        printf("projected energy change = %g\n",
          -2*viscosity*norm_vort*norm_vort*(t-last_t));
      }
      printf("max_vel = %g\n",max_vel);
      printf("max_vort = %g\n",max_vort);
      last_t = t;
      last_norm_vel = norm_vel;
      ret_val = 1;
    }
  }
  fflush(stdout);
  return ret_val;
}

void gettime() {
  ode_input(fd,&iterates,&t,&vel[0][0][0][0]);
  printf("[%d] t = %g\n",iterates,t); fflush(stdout);
  fflush(stdout);
}

void initialise(int argc, char **argv) {
  create_small_plans();

#if defined(SOCKET_VERSION)
  prepare_socket_input(&fd,argc,argv);
  ode_output_int(fd,-1);
#else
  prepare_input(&fd);
#endif
  showinterval = 1;
  showafter = 0;
}

