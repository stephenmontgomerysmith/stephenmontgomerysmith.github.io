#if !defined( lint ) && !defined( SABER )
/* #ident	"@(#)version.h	5.01 2001/04/13 xlockmore" */

#endif

#define VERSION "xlockmore-5.01.2"
