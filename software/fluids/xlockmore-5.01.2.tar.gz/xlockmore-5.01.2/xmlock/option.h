/* number of buttons, toggles, and string options */

#define  PUSHBUTTONS  3
#define  TOGGLES  23
#define  OPTIONS  6

#define XLOCK "xlock"
#define WINDOW_WIDTH 160
#define WINDOW_HEIGHT 100
#define WINDOW_GEOMETRY "160x100"

