/*
 * Copyright (c) 2001 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>

/* Returns a stream that reads and writes to the stdout and stdin from the
   program program_name.  Returns NULL if there is any error.  Sets up
   interupts so that if either the calling program, or program_name, quit,
   then both quit.

   It uses the /dev/pty?? and /dev/tty?? to communicate with program_name.
   This is so that stdout in program_name is line buffered.
*/

FILE *open_program_pty(char *program_name);

/* Returns a stream that reads and writes to the stdout and stdin from the
   program program_name.  Returns NULL if there is any error.  Sets up
   interupts so that if either the calling program, or program_name, quit,
   then both quit.
*/

FILE *open_program(char *program_name);

char term_message[] = "Terminated\n";
char cannot_open_message[] = "Cannot open program\n";
char finished_message[] = "Program Finished\n";

static void sig_chld(int signo) {
  pid_t pid;
  int stat;
  int die = 0;

  while ((pid=waitpid(-1,&stat,WNOHANG))>0)
    if (!WIFSTOPPED(stat)) {
      if (WIFEXITED(stat)) {
        if (WEXITSTATUS(stat)==127)
          write(STDERR_FILENO,cannot_open_message,sizeof(cannot_open_message)-1);
        else
          write(STDERR_FILENO,finished_message,sizeof(finished_message)-1);
        term_message[0]='\0';
      }
      die = 1;
    }
  if (die) exit(1);
}

static void sig_exit(int signo) {
  write(STDERR_FILENO,term_message,strlen(term_message));
  term_message[0]='\0';
  exit(1);
}

static void kill_everyone() {
  kill(0, SIGTERM);
}

int first_time_for_pipe = 1;

FILE *open_program_pty(char *program_name) {
  int nullfd;
  pid_t pid;
  char name[] = "/dev/ptyXX";
  char *cp1, *cp2;
  int master = -1, slave = -1;
  FILE *stream_to_prog;

  stream_to_prog = NULL;

  if (getpgrp()!=getpid())
    if (setpgid(getpid(),getpid())<0) goto error;

  for (cp1 = "pqrsPQRS"; *cp1; cp1++) {
    name[8] = *cp1;
    for (cp2 = "0123456789abcdefghijklmnopqrstuv"; *cp2; cp2++) {
      name[5] = 'p';
      name[9] = *cp2;
      if ((master = open(name, O_RDWR, 0))==-1) {
        if (errno==ENOENT) goto error; /* out of ptys */
      } else {
        name[5] = 't';
        if ((slave = open(name,O_RDWR,0))!=-1) goto done;
        close(master);
      }
    }
  }
done:

  if (first_time_for_pipe) {
    atexit(kill_everyone);
    first_time_for_pipe = 0;
  }

  signal(SIGCHLD, sig_chld);
  signal(SIGHUP, sig_exit);
  signal(SIGINT, sig_exit);
  signal(SIGQUIT, sig_exit);
  signal(SIGILL, sig_exit);
  signal(SIGTRAP, sig_exit);
  signal(SIGABRT, sig_exit);
  signal(SIGFPE, sig_exit);
  signal(SIGBUS, sig_exit);
  signal(SIGSEGV, sig_exit);
  signal(SIGSYS, sig_exit);
  signal(SIGPIPE, SIG_IGN);
  signal(SIGALRM, sig_exit);
  signal(SIGTERM, sig_exit);
  signal(SIGXCPU, sig_exit);
  signal(SIGXFSZ, sig_exit);
  signal(SIGVTALRM, sig_exit);
  signal(SIGPROF, sig_exit);
  signal(SIGUSR1, sig_exit);
  signal(SIGUSR2, sig_exit);

  if ((pid=fork())<0) goto error;
  else if (pid==0) {
    close(master);
    if ((nullfd = open("/dev/null",O_RDWR))>=0 &&
        setpgid(0,getppid())>=0 &&
        dup2(slave,STDOUT_FILENO)>=0 &&
        dup2(nullfd,STDERR_FILENO)>=0 &&
        dup2(slave,STDIN_FILENO)>=0);
      execlp("/bin/sh","sh","-c",program_name,NULL);
    _exit(127);
  }

  close(slave);
  if (setpgid(pid,getpid())<0) goto error;
  stream_to_prog = fdopen(master,"r+");
  if (stream_to_prog==NULL) goto error;
  setlinebuf(stream_to_prog);
  return stream_to_prog;

error:
  if (stream_to_prog!=NULL)
    fclose(stream_to_prog);
  else
    if (master>=0) close(master);
  if (slave>=0) close(slave);
  return NULL;
}

FILE *open_program(char *program_name) {
  int nullfd;
  pid_t pid;
  int fd[2] = {-1,-1};
  FILE *stream_to_prog;

  stream_to_prog = NULL;

  if (getpgrp()!=getpid())
    if (setpgid(getpid(),getpid())<0) goto error;

  if(socketpair(AF_UNIX,SOCK_STREAM,0,fd)<0) goto error;

  if (first_time_for_pipe) {
    atexit(kill_everyone);
    first_time_for_pipe = 0;
  }

  signal(SIGCHLD, sig_chld);
  signal(SIGHUP, sig_exit);
  signal(SIGINT, sig_exit);
  signal(SIGQUIT, sig_exit);
  signal(SIGILL, sig_exit);
  signal(SIGTRAP, sig_exit);
  signal(SIGABRT, sig_exit);
  signal(SIGFPE, sig_exit);
  signal(SIGBUS, sig_exit);
  signal(SIGSEGV, sig_exit);
  signal(SIGSYS, sig_exit);
  signal(SIGPIPE, SIG_IGN);
  signal(SIGALRM, sig_exit);
  signal(SIGTERM, sig_exit);
  signal(SIGXCPU, sig_exit);
  signal(SIGXFSZ, sig_exit);
  signal(SIGVTALRM, sig_exit);
  signal(SIGPROF, sig_exit);
  signal(SIGUSR1, sig_exit);
  signal(SIGUSR2, sig_exit);

  if ((pid=fork())<0) goto error;
  else if (pid==0) {
    close(fd[0]);
    if ((nullfd = open("/dev/null",O_RDWR))>=0 &&
        setpgid(0,getppid())>=0 &&
        dup2(fd[1],STDOUT_FILENO)>=0 &&
        dup2(nullfd,STDERR_FILENO)>=0 &&
        dup2(fd[1],STDIN_FILENO)>=0);
      execlp("/bin/sh","sh","-c",program_name,NULL);
    _exit(127);
  }

  close(fd[1]);
  if (setpgid(pid,getpid())<0) goto error;
  stream_to_prog = fdopen(fd[0],"r+");
  if (stream_to_prog==NULL) goto error;
  setlinebuf(stream_to_prog);
  return stream_to_prog;

error:
  if (stream_to_prog!=NULL)
    fclose(stream_to_prog);
  else
    if (fd[0]>=0) close(fd[0]);
  if (fd[1]>=0) close(fd[1]);
  return NULL;
}
