/*
 * Copyright (c) 2001 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <sys/types.h>

typedef struct {
  int in_fd, out_fd;
  char *in_buffer;
  size_t in_begin;
  size_t in_end;
  size_t in_allocated;
  char *out_buffer;
  size_t out_begin;
  size_t out_end;
  size_t out_allocated;
  int error, in_eof;
} MY_FILE;

MY_FILE *my_fdopen(int in_fd, int out_fd);
int my_fflush(MY_FILE *f);
char *my_fgetsalloc_blockq(char **s, MY_FILE *f, int block);
#define my_fgetsalloc(s,f) my_fgetsalloc_blockq(s, f, 1)
#define my_fgetsalloc_no_block(s,f) my_fgetsalloc_blockq(s, f, 0)
int my_fin_eof(MY_FILE *f);
int my_ferror(MY_FILE *f);
int my_fputs(char *s, MY_FILE *f);
int my_fout_close(MY_FILE *f);
int my_fclose(MY_FILE *f);

MY_FILE *open_program(char *program_name);
MY_FILE *open_program_pty(char *program_name);
