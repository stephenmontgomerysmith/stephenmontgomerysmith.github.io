#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/time.h>

#define IN_BUF_DELTA (1<<16)
#define OUT_BUF_DELTA (1<<16)

typedef struct {
  int in_fd, out_fd;
  char *in_buffer;
  size_t in_begin;
  size_t in_end;
  size_t in_allocated;
  char *out_buffer;
  size_t out_begin;
  size_t out_end;
  size_t out_allocated;
  int error, in_eof;
} MY_FILE;

MY_FILE *my_fdopen(int in_fd, int out_fd) {
  MY_FILE *f;

  f = malloc(sizeof(MY_FILE));
  f->in_fd = in_fd;
  f->out_fd = out_fd;
  f->in_buffer = NULL;
  f->in_begin = 0;
  f->in_end = 0;
  f->in_allocated = 0;
  f->out_buffer = NULL;
  f->out_begin = 0;
  f->out_end = 0;
  f->out_allocated = 0;
  f->error = 0;
  return f;
}

int my_fread_write(MY_FILE *f, int block) {
  fd_set readfds,writefds;
  int nfds = f->in_fd>f->out_fd?f->in_fd+1:f->out_fd+1;
  struct timeval t = {0,0};
  ssize_t r;

  if (f->error) return -1;
  if (f->in_fd<0 && (f->out_fd<0||f->out_end==f->out_begin)) return 0;
  FD_ZERO(&readfds);
  FD_ZERO(&writefds);
  if (f->in_fd>=0) FD_SET(f->in_fd,&readfds);
  if (f->out_fd>=0 && f->out_end>f->out_begin) FD_SET(f->out_fd,&writefds);
  select(nfds, &readfds, &writefds, NULL, block?NULL:&t);

  if (f->in_fd>=0 && FD_ISSET(f->in_fd,&readfds)) {
    if (f->in_allocated-f->in_end<IN_BUF_DELTA) {
      f->in_allocated+=IN_BUF_DELTA;
      f->in_buffer=realloc(f->in_buffer,f->in_allocated);
    }
    r = read(f->in_fd,f->in_buffer+f->in_end,f->in_allocated-f->in_end);
    if (r<0) {
      f->error = 1;
      return -1;
    }
    else if (r==0) {
      close(f->in_fd);
      f->in_fd = -1;
    }
    else f->in_end+=r;
  }
  if (f->out_fd>=0 && FD_ISSET(f->out_fd,&writefds)) {
    r = write(f->out_fd,f->out_buffer+f->out_begin,
              (f->out_end-f->out_begin)>1024?1024:(f->out_end-f->out_begin));
    if (r<0) {
      f->error = 1;
      return -1;
    }
    else {
      f->out_begin+=r;
      if (f->out_begin>=OUT_BUF_DELTA) {
        memmove(f->out_buffer,f->out_buffer+f->out_begin,
                f->out_end-f->out_begin);
        f->out_end -= f->out_begin;
        f->out_begin = 0;
        f->out_allocated = f->out_end + OUT_BUF_DELTA;
        f->out_buffer = realloc(f->out_buffer,f->out_allocated);
      }
    }
  }
  return 0;
}

int my_fflush(MY_FILE *f) {
  if (f->error) return -1;
  while (f->out_end>f->out_begin)
    if (my_fread_write(f,1)<0) return -1;
  return 0;
}

char *my_fgetsalloc_blockq(char **s, MY_FILE *f, int block) {
  char *eol;
  int go_again;
  int len;

  if (f->error) return NULL;
  if (f->in_fd<0 && f->in_end==f->in_begin)  {
    if (*s!=NULL) {
      free(*s);
      *s = NULL;;
    }
    return NULL;
  }
  eol = memchr(f->in_buffer+f->in_begin,'\n',f->in_end-f->in_begin);
  do {
    go_again = 0;
    if (eol==NULL) {
      if (my_fread_write(f,block)<0) {
        if (*s!=NULL) {
          free(*s);
          *s = NULL;
        }
      }
    }
    eol = memchr(f->in_buffer+f->in_begin,'\n',f->in_end-f->in_begin);
    if (eol==NULL) {
      if (f->in_fd<0) {
        if (f->in_end==f->in_begin) {
          if (*s!=NULL) {
            free(*s);
            *s = NULL;
          }
        }
        else {
          *s = realloc(*s,f->in_end-f->in_begin+1);
          memmove(*s,f->in_buffer+f->in_begin,f->in_end-f->in_begin);
          (*s)[f->in_end-f->in_begin] = '\0';
          f->in_begin = f->in_end;
        }
        if (f->in_buffer!=NULL) {
          free(f->in_buffer);
          f->in_buffer = NULL;
          f->in_allocated = 0;
        }
      }
      else {
        if (block) go_again = 1;
        else {
          *s = realloc(*s,1);
          strcpy(*s,"");
        }
      }
    }
    else {
      len = eol-(f->in_buffer+f->in_begin)+1;
      *s = realloc(*s,len+1);
      memmove(*s,f->in_buffer+f->in_begin,len);
      (*s)[len] = '\0';
      f->in_begin += len;
      if (f->in_begin>=OUT_BUF_DELTA) {
        memmove(f->in_buffer,f->in_buffer+f->in_begin,
                f->in_end-f->in_begin);
        f->in_end -= f->in_begin;
        f->in_begin = 0;
        f->in_allocated = f->in_end + OUT_BUF_DELTA;
        f->in_buffer = realloc(f->in_buffer,f->in_allocated);
      }
    }
  } while(go_again);
  return *s;
}

#define my_fgetsalloc(s,f) my_fgetstring_blockq(s, f, 1)

#define my_fgetsalloc_no_block(s,f) my_fgetstring_blockq(s, f, 0)

int my_fin_eof(MY_FILE *f) {
  return(!f->error && f->in_fd<0);
}

int my_ferror(MY_FILE *f) {
  return f->error;
}

int my_fputs(char *s, MY_FILE *f) {
  int len = strlen(s);

  if (f->error) return -1;
  if (f->out_end+len>f->out_allocated) {
    f->out_allocated = f->out_end+len+OUT_BUF_DELTA;
    f->out_buffer = realloc(f->out_buffer,f->out_allocated);
  }
  memmove(f->out_buffer+f->out_end,s,len);
  f->out_end += len;
  while (f->out_end-f->out_begin>=OUT_BUF_DELTA)
    if (my_fread_write(f,1)<0) return -1;
  return 0;
}

int my_fout_close(MY_FILE *f) {
  int r = 0, s = 0;

  r = my_fflush(f);
  if (f->out_fd>=0) {
    s = close(f->out_fd)<0;
    f->out_fd = -1;
  }
  if (f->out_buffer!=NULL) {
    free(f->out_buffer);
    f->out_buffer = NULL;
  }
  return r<0||s<0?-1:0;
}

int my_fclose(MY_FILE *f) {
  int r = 0, s = 0;

  r = my_fout_close(f);
  if (f->in_fd>=0)
    s = close(f->in_fd);
  if (f->in_buffer!=NULL) {
    free(f->in_buffer);
    f->in_buffer = NULL;
  }
  free(f);
  return r<0||s<0?-1:0;
}
