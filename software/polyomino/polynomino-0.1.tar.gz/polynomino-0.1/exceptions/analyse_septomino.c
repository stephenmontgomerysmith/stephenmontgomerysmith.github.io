/*
 * Copyright (c) 2000 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <stdio.h>

#define width 26
#define height 21

int array[width][height], refl_x[width][height], refl_y[width][height],
    rot180[width][height];
FILE *in_file;

int read_array() {
  int x,y;

  for (y=0;y<height;y++) for (x=0;x<width;x++) {
    if (fscanf(in_file,"%d",&array[x][y])!=1) return 0;
    refl_x[x][height-1-y] = array[x][y];
    refl_y[width-1-x][y] = array[x][y];
    rot180[width-1-x][height-1-y] = array[x][y];
  }
  return 1;
}

int compare(int a1[width][height], int a2[width][height]) {
  int map[width*height];
  int m,x,y;

  for (m=0;m<width*height;m++) map[m] = -1;
  for (x=0;x<width;x++) for (y=0;y<height;y++)
    if (map[a1[x][y]]==-1)
      map[a1[x][y]] = a2[x][y];
    else
      if (map[a1[x][y]]!=a2[x][y])
        return 0;
  return 1;
}

int main() {
  int count = 1;

  in_file = fopen("septomino.out","r");
  while (read_array()) {
    printf("Number %d\n",count);
    if (compare(array,refl_x))
      printf("Number %d has symmetry about x-axis.\n",count);
    if (compare(array,refl_y))
      printf("Number %d has symmetry about y-axis.\n",count);
    if (compare(array,rot180))
      printf("Number %d has 180 degree rotational symmetry.\n",count);
    count++;
  }
  exit(0);
}
