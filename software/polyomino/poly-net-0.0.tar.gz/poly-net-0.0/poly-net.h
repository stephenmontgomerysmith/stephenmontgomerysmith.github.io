#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <math.h>

#define hostname "cauchy.math.missouri.edu"

#define BUF_SIZE 1024

typedef struct {
  int fd;
  char buf[BUF_SIZE];
  int buf_index, buf_size;
} read_file_type;

int prepare_socket_client(int *sockfd)
{
  struct sockaddr_in servaddr;
  struct hostent *hptr;
  char str[INET_ADDRSTRLEN];

  hptr=gethostbyname(hostname);
  if (hptr==NULL)
  {
    fprintf(stderr,"Host not known\n");
    return -1;
  }
  if (hptr->h_addrtype != AF_INET)
  {
    fprintf(stderr,"Unknown address type\n");
    return -1;
  }


  *sockfd=socket(AF_INET,SOCK_STREAM,0);
  if (*sockfd < 0)
  {
    fprintf(stderr,"Unable to open socket\n");
    return -1;
  }

  bzero(&servaddr,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  servaddr.sin_port=htons(3000);
/*
  if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0)
  {
    fprintf(stderr,"Unusable IP address\n");
    return -1;
  }
*/
  printf("IP adddress of %s is %s\n",
    hptr->h_name,
    inet_ntop(hptr->h_addrtype,*(hptr->h_addr_list),str,sizeof(str)));

  memcpy(&servaddr.sin_addr,*(hptr->h_addr_list),sizeof(struct in_addr));

  if (connect(*sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr)) < 0)
  {
    fprintf(stderr,"Unable to connect\n");
    return -1;
  }

  return 0;
}

int next_char(read_file_type *file) {
  if (file->buf_index<file->buf_size) {
    file->buf_index++;
    return file->buf[file->buf_index-1];
  }
  else {
    file->buf_size = read(file->fd,file->buf,BUF_SIZE);
    if (file->buf_size==0) return -1;
    file->buf_index = 1;
    return file->buf[0];
  }
}

char *read_string(read_file_type *file, char s[], int len) {
  int l=0, c;

  while ((c=next_char(file)) != -1 && l<len) {
    s[l] = c;
    l++;
    if (c=='\n') break;
  }
  if (l==0 || l==len) return NULL;
  s[l]='\0';
  return s;
}


int send_string(int fd, char s[]) {
  int send_at = 0;
  int send_len = strlen(s);
  int sent;

  while (send_len>0) {
    sent = write(fd,s+send_at,send_len);
    if (sent == -1) return -1;
    send_len -= sent;
    send_at += sent;
  }
  return 0;
}

