/*
 * Copyright (c) 2000 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

char colors[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

void ugly_print_array() {
  int x,y;

  printf("\n");
  for(y=0;y<height;y++) {
    for(x=0;x<width;x++)
       printf("%c",ARRAY(x,y)==-2 ? ' ' : ARRAY(x,y)==-1 ? '.' : colors[(int)ARRAY(x,y)]);
   printf("\n");
  }
  printf("\n");
}

void pretty_print_array() {
  int x,y;

  printf("\n");
  for(y=0;y<=height;y++) {
    for(x=0;x<=width;x++) {
/* print corner */
      if (ARRAY(x,y) == ARRAY(x,y-1) && ARRAY(x,y) == ARRAY(x-1,y) && ARRAY(x,y) == ARRAY(x-1,y-1))
        printf(" ");
      else if (ARRAY(x,y) == ARRAY(x,y-1) && ARRAY(x,y) == ARRAY(x-1,y))
        printf("+");
      else if (ARRAY(x-1,y) == ARRAY(x-1,y-1) && ARRAY(x-1,y) == ARRAY(x,y))
        printf("+");
      else if (ARRAY(x,y-1) == ARRAY(x-1,y-1) && ARRAY(x,y-1) == ARRAY(x,y))
        printf("+");
      else if (ARRAY(x-1,y-1) == ARRAY(x-1,y) && ARRAY(x-1,y-1) == ARRAY(x,y-1))
        printf("+");
      else if (ARRAY(x,y-1) == ARRAY(x-1,y-1) || ARRAY(x,y) == ARRAY(x-1,y))
        printf("-");
      else if (ARRAY(x-1,y) == ARRAY(x-1,y-1) || ARRAY(x,y) == ARRAY(x,y-1))
        printf("|");
      else
        printf("+");

/* print horizontal edge */
      if (x<width) {
        if (ARRAY(x,y) != ARRAY(x,y-1))
          printf("--");
        else
          printf("  ");
      }
    }
    printf("\n");

    if (y<height) {
      for(x=0;x<=width;x++) {
/* print vertical edge */
        if (ARRAY(x,y) != ARRAY(x-1,y)) 
          printf("|");
        else
          printf(" ");
/* print middle of squares */
        if (x<width)
          printf("  ");
      }
      printf("\n");
    }
  }
  printf("\n");
}

void rotate_pretty_print_array() {
  int x,y;

  printf("\n");
  for(x=0;x<=width;x++) {
    for(y=0;y<=height;y++) {
/* print corner */
      if (ARRAY(x,y) == ARRAY(x-1,y) && ARRAY(x,y) == ARRAY(x,y-1) && ARRAY(x,y) == ARRAY(x-1,y-1))
        printf(" ");
      else if (ARRAY(x,y) == ARRAY(x-1,y) && ARRAY(x,y) == ARRAY(x,y-1))
        printf("+");
      else if (ARRAY(x,y-1) == ARRAY(x-1,y-1) && ARRAY(x,y-1) == ARRAY(x,y))
        printf("+");
      else if (ARRAY(x-1,y) == ARRAY(x-1,y-1) && ARRAY(x-1,y) == ARRAY(x,y))
        printf("+");
      else if (ARRAY(x-1,y-1) == ARRAY(x,y-1) && ARRAY(x-1,y-1) == ARRAY(x-1,y))
        printf("+");
      else if (ARRAY(x-1,y) == ARRAY(x-1,y-1) || ARRAY(x,y) == ARRAY(x,y-1))
        printf("-");
      else if (ARRAY(x,y-1) == ARRAY(x-1,y-1) || ARRAY(x,y) == ARRAY(x-1,y))
        printf("|");
      else
        printf("+");

/* print horizontal edge */
      if (y<height) {
        if (ARRAY(x,y) != ARRAY(x-1,y))
          printf("--");
        else
          printf("  ");
      }
    }
    printf("\n");

    if (x<width) {
      for(y=0;y<=height;y++) {
/* print vertical edge */
        if (ARRAY(x,y) != ARRAY(x,y-1)) 
          printf("|");
        else
          printf(" ");
/* print middle of squares */
        if (y<height)
          printf("  ");
      }
      printf("\n");
    }
  }
  printf("\n");
}


#ifdef CHECK_PROGRESS
void print_estimate() {
  double all=0, done=0;
  int this_all, this_done;
  int i,j;
  time_t time_done;
  double time_remaining;

#ifdef CREATE_STARTS
  for (i=0;i<search_depth;i++) {
#elif defined(CLIENT)
  for (i=search_depth;i<nr_polynominoes;i++) {
#else
  for (i=0;i<nr_polynominoes;i++) {
#endif
    this_all = 0;
#ifdef CREATE_STARTS
    for (j=i;j<search_depth;j++)
#else
    for (j=i;j<nr_polynominoes;j++)
#endif
      this_all += orig_transform_len[list[j].poly_no];
    this_done = 0;
#ifdef CREATE_STARTS
    for (j=i;j<search_depth;j++) if (list[j].poly_no<list[i].poly_no)
#else
    for (j=i;j<nr_polynominoes;j++) if (list[j].poly_no<list[i].poly_no)
#endif
      this_done += orig_transform_len[list[j].poly_no];
    done *= this_all;
    all *= this_all;
    done += this_done;
    all += this_all-1;
  }

  printf("Estimated total number %.3g\n",floor(all/done*nr_found));
  printf("Estimate percentage done %.3g\n",done/all*100);

  time_done = time(NULL)-time_started;
  printf("Time ellapsed ");
  if (time_done/(3600*24)>0)
    printf("%ld days ",time_done/(3600*24));
  if (time_done/3600>0)
    printf("%ld hours ",(time_done%(3600*24)/3600));
  if (time_done/60>0)
    printf("%ld minutes ",(time_done%(3600)/60));
  printf("%ld seconds\n",time_done%60);

  if (done>0 && done<all) {
    time_remaining = time_done*(all/done-1);
    printf("Estimated time remaining ");
    if (time_remaining/(3600*24*365.25)>=1)
      printf("%g years\n",rint(time_remaining/(360*24*365.25))/10);
    else if (time_remaining/(3600*24*30)>=1)
      printf("%g months\n",rint(time_remaining/(360*24*30))/10);
    else if (time_remaining/(3600*24)>=1)
      printf("%g days\n",rint(time_remaining/(360*24))/10);
    else if (time_remaining/3600>=1)
      printf("%g hours\n",rint(time_remaining/360)/10);
    else if (time_remaining/60>=1)
      printf("%g minutes\n",rint(time_remaining/6)/10);
    else
      printf("%g seconds\n",rint(time_remaining));
  }
}
#endif

void print_solution() {

#ifdef CREATE_STARTS
  int i;
  fprintf(out_file,"1 ");
  for (i=0;i<search_depth;i++)
    fprintf(out_file,"%d %d ",list[i].poly_no, list[i].index);
  fprintf(out_file,"\n");
  fflush(out_file);
#endif

#ifdef CHECK_PROGRESS
#ifdef CREATE_STARTS
  if (floor(nr_found/100000)*100000 == nr_found) {
#else
  if (floor(nr_found/1000)*1000 == nr_found) {
#endif
    printf("Number %.15g\n",nr_found);
    print_estimate();
    fflush(stdout);
  }
#endif
}

