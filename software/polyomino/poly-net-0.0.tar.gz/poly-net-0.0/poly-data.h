/*
 * Copyright (c) 2000 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

typedef struct {int x,y;} point_type;

static struct {int len; point_type point[polynomino_len];
               int transform_len, transform_list[8], max_white;} 
  polynomino[nr_polynominoes];

#include "poly-list.h"

#define ARRAY_INDEX_DISP(x,y) ((x)*(height+2*(polynomino_len-1))+(y))
#define ARRAY(x,y) (array[ARRAY_INDEX_DISP(x+polynomino_len-1,y+polynomino_len-1)])
int len[nr_polynominoes];

char array[(max_width+2*(polynomino_len-1))*(max_height+2*(polynomino_len-1))];
int attached[nr_polynominoes];
double nr_found = 0;

struct {int poly_no, index;} list[nr_polynominoes];
#ifdef CHECK_PROGRESS
int orig_transform_len[nr_polynominoes];
time_t time_started;
#endif

/* A preprocessed list in which all the possible transforms have
   already been done to the pentominoes, and then all the points
   are converted to displacements via ARRAY_INDEX_DISP.
*/

int displ_lu[nr_polynominoes][8][polynomino_len];
int transform_len_lu[nr_polynominoes];

#define LEFT       1<<0
#define RIGHT      1<<1
#define UP         1<<2
#define DOWN       1<<3
#define LEFT_UP    1<<4
#define LEFT_DOWN  1<<5
#define RIGHT_UP   1<<6
#define RIGHT_DOWN 1<<7
int displ_ws[256][nr_polynominoes][8*polynomino_len][polynomino_len];
int transform_len_ws[256][nr_polynominoes];

#ifdef CREATE_STARTS
FILE *out_file;
#endif
