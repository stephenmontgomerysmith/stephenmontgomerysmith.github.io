/*
 * Copyright (c) 2000 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

static struct {int len; point_type point[4];
               int transform_len, transform_list[8], max_white;} tetromino[5] =
{
/*
xxxx 
*/
  {4, {{0,0}, {1,0}, {2,0}, {3,0}},
   2, {0, 1, -1, -1, -1, -1, -1, -1}, 2},
/*
xxx  
  x  
*/
  {4, {{0,0}, {1,0}, {2,0}, {2,1}},
   8, {0, 1, 2, 3, 4, 5, 6, 7}, 2},
/*
xxx  
 x   
*/
  {4, {{0,0}, {1,0}, {1,1}, {2,0}},
   4, {0, 1, 2, 3, -1, -1, -1, -1}, 3},
/*
xx   
 xx  
*/
  {4, {{0,0}, {1,0}, {1,1}, {2,1}},
   4, {0, 1, 4, 5, -1, -1, -1, -1}, 2},
/*
xx   
xx   
*/
  {4, {{0,0}, {0,1}, {1,0}, {1,1}},
   1, {0, -1, -1, -1, -1, -1, -1, -1}, 2}};

static struct {int len; point_type point[5];
               int transform_len, transform_list[8], max_white;} 
  one_sided_pentomino[18], pentomino[12] =
{
/*
xxxxx 
*/
  {5, {{0,0}, {1,0}, {2,0}, {3,0}, {4,0}},
   2, {0, 1, -1, -1, -1, -1, -1, -1}, 3},
/*
xxxx  
   x  
*/
  {5, {{0,0}, {1,0}, {2,0}, {3,0}, {3,1}},
   8, {0, 1, 2, 3, 4, 5, 6, 7}, 3},
/*
xxxx  
  x   
*/
  {5, {{0,0}, {1,0}, {2,0}, {2,1}, {3,0}},
   8, {0, 1, 2, 3, 4, 5, 6, 7}, 3},
/*
  x   
xxx   
  x   
*/
  {5, {{0,0}, {1,0}, {2,-1}, {2,0}, {2,1}},
   4, {0, 1, 2, 3, -1, -1, -1, -1}, 3},
/*
xxx   
  xx  
*/
  {5, {{0,0}, {1,0}, {2,0}, {2,1}, {3,1}},
   8, {0, 1, 2, 3, 4, 5, 6, 7}, 3},
/*
xxx   
 xx   
*/
  {5, {{0,0}, {1,0}, {1,1}, {2,0}, {2,1}},
   8, {0, 1, 2, 3, 4, 5, 6, 7}, 3},
/*
xxx   
  x   
  x   
*/
  {5, {{0,0}, {1,0}, {2,0}, {2,1}, {2,2}},
   4, {0, 1, 2, 3, -1, -1, -1, -1}, 3},
/*
 x    
xxx   
  x   
*/
  {5, {{0,0}, {1,-1}, {1,0}, {2,0}, {2,1}},
   8, {0, 1, 2, 3, 4, 5, 6, 7}, 3},
/*
xxx   
x x   
*/
  {5, {{0,0}, {0,1}, {1,0}, {2,0}, {2,1}},
   4, {0, 1, 2, 3, -1, -1, -1, -1}, 3},
/*
  x   
xxx   
x     
*/
  {5, {{0,0}, {0,1}, {1,0}, {2,-1}, {2,0}},
   4, {0, 1, 4, 5, -1, -1, -1, -1}, 3},
/*
 x    
xxx   
 x    
*/
  {5, {{0,0}, {1,-1}, {1,0}, {1,1}, {2,0}},
   1, {0, -1, -1, -1, -1, -1, -1, -1}, 4},
/*
xx    
 xx   
  x   
*/
  {5, {{0,0}, {1,0}, {1,1}, {2,1}, {2,2}},
   4, {0, 1, 2, 3, -1, -1, -1, -1}, 3}};


int compare(const void *p1, const void *p2);
void transform(int x, int y, int transform_no, int *out_x, int *out_y);


/* Stop unused variable errors */
void dummy() {
  void *junk;

  junk = tetromino;
  junk = pentomino;
}

void limit_rotations() {
  int i;

  for (i=0;i<nr_polynominoes;i++) {
    if (polynomino[i].transform_len == 8) {
      polynomino[i].transform_len = 2;
      polynomino[i].transform_list[0] = 0;
      polynomino[i].transform_list[1] = 1;
      break;
    }
  }
}

int test_symmetry(point_type *point, int len, int transform_no) {
  point_type point1[polynomino_len], point2[polynomino_len];
  int i,x_min,y_min;

  memcpy(point1,point,len*sizeof(point_type));
  x_min = 1000000;
  for (i=0;i<len;i++)
    if (point1[i].x < x_min) x_min = point1[i].x;
  y_min = 1000000;
  for (i=0;i<len;i++)
    if (point1[i].y < y_min) y_min = point1[i].y;
  for (i=0;i<len;i++) {
    point1[i].x -= x_min;
    point1[i].y -= y_min;
  }
  qsort(point1,len,sizeof(point_type),compare);

  for (i=0;i<len;i++)
    transform(point[i].x,point[i].y,transform_no,
              &point2[i].x,&point2[i].y);
  x_min = 1000000;
  for (i=0;i<len;i++)
    if (point2[i].x < x_min) x_min = point2[i].x;
  y_min = 1000000;
  for (i=0;i<len;i++)
    if (point2[i].y < y_min) y_min = point2[i].y;
  for (i=0;i<len;i++) {
    point2[i].x -= x_min;
    point2[i].y -= y_min;
  }
  qsort(point2,len,sizeof(point_type),compare);

  for (i=0;i<len;i++)
    if (point1[i].x!=point2[i].x || point1[i].y!=point2[i].y)
      return 0;
  return 1;
}

void limit_one_sided_rotations() {
  int i;

  for (i=0;i<nr_polynominoes;i++) {
    if ((test_symmetry(polynomino[i].point,polynomino[i].len,5)
         || test_symmetry(polynomino[i].point,polynomino[i].len,7))
         && !test_symmetry(polynomino[i].point,polynomino[i].len,1)
         && !test_symmetry(polynomino[i].point,polynomino[i].len,2)
         && !test_symmetry(polynomino[i].point,polynomino[i].len,3)) {
      polynomino[i].transform_len = 1;
      polynomino[i].transform_list[0] = 0;
      break;
    }
  }
}

void make_one_sided_pentomino() {
  int i,j,t,u;

  j=0;
  for (i=0;i<12;i++) {
    one_sided_pentomino[j] = pentomino[i];
    for (t=0;t<8;t++)
      if (one_sided_pentomino[j].transform_list[t]>=4) {
        one_sided_pentomino[j].transform_len = t;
        j++;
        one_sided_pentomino[j] = pentomino[i];
        for (u=t;u<8;u++)
          one_sided_pentomino[j].transform_list[u-t] = 
            one_sided_pentomino[j].transform_list[u];
        one_sided_pentomino[j].transform_len -= t;
        break;
      }
    j++;
  }
}

#define copy_polynomino(dst,src)					\
  (dst).len = (src).len;						\
  memcpy((dst).point,(src).point,sizeof(point_type)*(src).len);		\
  (dst).transform_len = (src).transform_len;				\
  memcpy((dst).transform_list,(src).transform_list,sizeof(int)*8);	\
  (dst).max_white = (src).max_white

#define load_set(poly_set,size)						\
  for (i=0;i<size;i++) {						\
    copy_polynomino(polynomino[k],poly_set[i]);				\
    k++;								\
  }

#define load_tetromino							\
  load_set(tetromino,5)

#define load_pentomino							\
  load_set(pentomino,12)

#define load_one_sided_pentomino						\
  make_one_sided_pentomino();						\
  load_set(one_sided_pentomino,18)

