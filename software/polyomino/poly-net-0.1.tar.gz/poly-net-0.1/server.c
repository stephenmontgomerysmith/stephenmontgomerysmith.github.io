#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <pthread.h>
#include "poly-net.h"

#define search_depth 4

pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t rand_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t starts_mutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
  int connfd;
  struct in_addr addr;
  u_short port;
}
arg_pass_type;

#define MAX 150000
int count;
char start[MAX][search_depth*2];
int seq_number[MAX];

FILE *save_file;

void set_starts() {
  FILE *starts;
  int sn = 0;
  int use,temp,i;

  pthread_mutex_lock(&starts_mutex);
  count = 0;
  starts = fopen("start.out","r");
  while(fscanf(starts,"%d",&use)==1) {
    for (i=0;i<search_depth*2;i++) {
      fscanf(starts,"%d",&temp);
      start[count][i] = temp;
    }
    seq_number[count] = sn;
    if (use) count++;
    sn++;
  }
  pthread_mutex_lock(&print_mutex);
  printf("Number of starts = %d\n",count);
  fprintf(save_file,"Number of starts = %d\n",count);
  if (count == 0) {
    printf("Finished\n");
    fprintf(save_file,"Finished\n");
    exit(0);
  }
  fflush(stdout);
  fflush(save_file);
  pthread_mutex_unlock(&print_mutex);
  pthread_mutex_unlock(&starts_mutex);
}

char *get_start(int n, char s[]) {
  int i;

  pthread_mutex_lock(&starts_mutex);
  sprintf(s,"%d ",seq_number[n]);
  for (i=0;i<search_depth*2;i++)
    sprintf(s+strlen(s),"%d ",start[n][i]);
  sprintf(s+strlen(s),"\n");
  pthread_mutex_unlock(&starts_mutex);
  return s;
}

void *process_client(void *arg) {
  char s[1000];
  int r;
  read_file_type conn_file;
  int connfd = ((arg_pass_type*)arg)->connfd;
  struct in_addr addr = ((arg_pass_type*)arg)->addr;
  u_short port = ((arg_pass_type*)arg)->port;

  free(arg);

  pthread_detach(pthread_self());
  conn_file.fd = connfd;
  conn_file.buf_index = conn_file.buf_size = 0;

  if (read_string(&conn_file,s,1000)==NULL) goto end;

  if (strcmp(s,"request data\n")==0) {
    pthread_mutex_lock(&rand_mutex);
    r = (double)rand()/(double)RAND_MAX*(double)count;
    pthread_mutex_unlock(&rand_mutex);
    if (send_string(conn_file.fd,get_start(r,s))==-1) goto end;
  }
  else if (strcmp(s,"sending data\n")==0) {
    if (read_string(&conn_file,s,1000)==NULL) goto end;
    if (strlen(s)>0 && s[strlen(s)-1]=='\n')
      s[strlen(s)-1]='\0';
    pthread_mutex_lock(&print_mutex);
    printf("%s %s %d\n",s,inet_ntoa(addr),ntohs(port));
    fflush(stdout);
    fprintf(save_file,"%s %s %d\n",s,inet_ntoa(addr),ntohs(port));
    fflush(save_file);
    pthread_mutex_unlock(&print_mutex);
  }
  else if (strcmp(s,"recalc starts\r\n")==0 && addr.s_addr==htonl(0x7f000001))
    set_starts();
  end:
  close(connfd);
  return NULL;
}

int main () {
  int listenfd;
  struct sockaddr_in servaddr;
  socklen_t slen;
  pthread_t tid;
  arg_pass_type *arg;

  srand(time(NULL));
  save_file = fopen("save-results","a");

  set_starts();

  listenfd=socket(AF_INET,SOCK_STREAM,0);
  bzero(&servaddr,sizeof(servaddr));
  servaddr.sin_family=AF_INET;
  servaddr.sin_addr.s_addr=htonl(INADDR_ANY);
  servaddr.sin_port=htons(server_port_nr);
  if (bind(listenfd,(struct sockaddr*)&servaddr,sizeof(servaddr)) < 0)
  {
    fprintf(stderr,"Could not bind\n");
    exit(1);
  }
  listen(listenfd,6);

  while (1)
  {
    slen=sizeof(servaddr);
    arg = malloc(sizeof(arg_pass_type));
    arg->connfd = accept(listenfd,(struct sockaddr*)&servaddr,&slen);
    arg->addr = servaddr.sin_addr;
    arg->port = servaddr.sin_port;
    pthread_create(&tid,NULL,process_client,(void*) arg);
  }
  exit(0);
}
