/*
 * Copyright (c) 2000 by Stephen Montgomery-Smith <stephen@math.missouri.edu>
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <unistd.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/stat.h>


#include "poly-data.h"
#include "poly-net.h"
#include "poly-io.h"

void transform(int x, int y, int transform_no, int *out_x, int *out_y) {
  switch (transform_no) {
    case 0: *out_x=x;
            *out_y=y;
            break;
    case 1: *out_x=-y;
            *out_y=x;
            break;
    case 2: *out_x=-x;
            *out_y=-y;
            break;
    case 3: *out_x=y;
            *out_y=-x;
            break;
    case 4: *out_x=-x;
            *out_y=y;
            break;
    case 5: *out_x=y;
            *out_y=x;
            break;
    case 6: *out_x=x;
            *out_y=-y;
            break;
    case 7: *out_x=-y;
            *out_y=-x;
            break;
  }
}

int compare(const void *p1, const void *p2) {
  if (((point_type*)p1)->x<((point_type*)p2)->x) return -1;
  if (((point_type*)p1)->x>((point_type*)p2)->x) return 1;
  if (((point_type*)p1)->x==((point_type*)p2)->x) {
    if (((point_type*)p1)->y<((point_type*)p2)->y) return -1;
    if (((point_type*)p1)->y>((point_type*)p2)->y) return 1;
  }
  return 0;
}

void compute_displ_lu() {
  int poly_no, index, x_offset, y_offset, i;
  point_type poly[polyomino_len];

  for (poly_no=0;poly_no<nr_polyominoes;poly_no++) {
    len[poly_no] = polyomino[poly_no].len;
#ifdef CHECK_PROGRESS
    orig_transform_len[poly_no] = polyomino[poly_no].transform_len;
#endif
    transform_len_lu[poly_no] = polyomino[poly_no].transform_len;
    for (index=0;index<polyomino[poly_no].transform_len;index++) {
      for (i=0;i<polyomino[poly_no].len;i++) {
        transform(polyomino[poly_no].point[i].x, polyomino[poly_no].point[i].y,
                  polyomino[poly_no].transform_list[index],
                  &poly[i].x, &poly[i].y);
      }
      x_offset = 1000;
      for (i=0;i<polyomino[poly_no].len;i++)
        if (poly[i].x<x_offset) x_offset=poly[i].x;
      y_offset = 1000;
      for (i=0;i<polyomino[poly_no].len;i++) if (poly[i].x == x_offset)
        if (poly[i].y<y_offset) y_offset=poly[i].y;
      for (i=0;i<polyomino[poly_no].len;i++) {
        poly[i].x -= x_offset;
        poly[i].y -= y_offset;
      }
      qsort(poly,polyomino[poly_no].len,sizeof(point_type),compare);
      for (i=0;i<polyomino[poly_no].len;i++) {
        displ_lu[poly_no][index][i] = 
          ARRAY_INDEX_DISP(poly[i].x,poly[i].y);
      }
    }
  }
}

void compute_displ_ws() {
  int poly_no, index, i, j, b;
  point_type poly[polyomino_len];

  for (poly_no=0;poly_no<nr_polyominoes;poly_no++) {
    len[poly_no] = polyomino[poly_no].len;
#ifdef CHECK_PROGRESS
    orig_transform_len[poly_no] = polyomino[poly_no].transform_len;
#endif
    for (b=0;b<256;b++)
      transform_len_ws[b][poly_no] = 0;
    for (index=0;index<polyomino[poly_no].transform_len;index++) {
      for (i=0;i<polyomino[poly_no].len;i++) {
        transform(polyomino[poly_no].point[i].x, polyomino[poly_no].point[i].y,
                  polyomino[poly_no].transform_list[index],
                  &poly[i].x, &poly[i].y);
      }

      qsort(poly,polyomino[poly_no].len,sizeof(point_type),compare);
      for (b=0;b<256;b++) for (j=0;j<polyomino[poly_no].len;j++) {
        for (i=0;i<polyomino[poly_no].len;i++) {
          if (b&LEFT && poly[i].x-poly[j].x==-1 && poly[i].y-poly[j].y==0)
            goto label;
          if (b&RIGHT && poly[i].x-poly[j].x==1 && poly[i].y-poly[j].y==0)
            goto label;
          if (b&UP && poly[i].x-poly[j].x==0 && poly[i].y-poly[j].y==-1)
            goto label;
          if (b&DOWN && poly[i].x-poly[j].x==0 && poly[i].y-poly[j].y==1)
            goto label;
          if (b&LEFT_UP && poly[i].x-poly[j].x==-1 && poly[i].y-poly[j].y==-1)
            goto label;
          if (b&LEFT_DOWN && poly[i].x-poly[j].x==-1 && poly[i].y-poly[j].y==1)
            goto label;
          if (b&RIGHT_UP && poly[i].x-poly[j].x==1 && poly[i].y-poly[j].y==-1)
            goto label;
          if (b&RIGHT_DOWN && poly[i].x-poly[j].x==1 && poly[i].y-poly[j].y==1)
            goto label;
        }
        for (i=0;i<polyomino[poly_no].len;i++) {
          displ_ws[b][poly_no][transform_len_ws[b][poly_no]][i] = 
            ARRAY_INDEX_DISP(poly[i].x-poly[j].x,poly[i].y-poly[j].y);
        }
        transform_len_ws[b][poly_no]++;
        label:;
      }
    }
  }
}

int count_adjacent_blanks(signed char *p, signed char blank) {
  int count = 1;

  *p = blank;
  if (p[ARRAY_INDEX_DISP(-1,0)]==-1)
    count += count_adjacent_blanks(p+ARRAY_INDEX_DISP(-1,0),blank);
  if (p[ARRAY_INDEX_DISP( 1,0)]==-1)
    count += count_adjacent_blanks(p+ARRAY_INDEX_DISP( 1,0),blank);
  if (p[ARRAY_INDEX_DISP(0,-1)]==-1)
    count += count_adjacent_blanks(p+ARRAY_INDEX_DISP(0,-1),blank);
  if (p[ARRAY_INDEX_DISP(0, 1)]==-1)
    count += count_adjacent_blanks(p+ARRAY_INDEX_DISP(0, 1),blank);
  return count;
}

/* This recursive procedure actually does all the work.  It first looks
   for the first available point to attach a polyomino.  Then
   it tries to attach all the polyominoes in all possible ways to
   that that point.  If it succeeds then it recursively calls itself
   to add more polyominoes.  When all polyominoes have been attached
   it sends the solution to the printing procedure.
*/

void recursive_search_lu(signed char *place_to_attach, int nr_attached) {
  int poly_no,index,i;
  int *current_displ;

  if (nr_attached == nr_polyominoes) {
    nr_found++;
#ifdef CHECK_PROGRESS
    print_solution();
#endif
    return;
  }

  for(;*place_to_attach!=-1;place_to_attach++);

  for (poly_no=0;poly_no<nr_polyominoes;poly_no++) if (!attached[poly_no]) {
    for (index=0;index<transform_len_lu[poly_no];index++) {
      current_displ = displ_lu[poly_no][index];
      for (i=0;i<len[poly_no];i++) {
        if (place_to_attach[current_displ[i]] != -1)
          goto label;
      }

      for (i=0;i<len[poly_no];i++)
        place_to_attach[current_displ[i]] = poly_no;
      attached[poly_no] = 1;
      list[nr_attached].poly_no=poly_no;
      list[nr_attached].index=index;
      recursive_search_lu(place_to_attach,nr_attached+1);
      for (i=0;i<len[poly_no];i++)
        place_to_attach[current_displ[i]] = -1;
      attached[poly_no] = 0;

      label:;
    }
  }
}

void recursive_search_ws(int nr_attached) {
  int poly_no,index,i,score,worst_score,b,bitmap = 0;
  int *current_displ;
  signed char *p, *place_to_attach=NULL;
  int count, c, smallest_count;
  signed char blank, smallest_blank = -1;

#ifdef CLIENT
  if (nr_attached>=search_depth) {
    recursive_search_lu(&ARRAY(0,0),nr_attached);
    return;
  }
#endif

  if (check_size_of_blank_regions) {
    smallest_count = 1000000000;
    blank = -10;
    for (p=&ARRAY(0,0);p<=&ARRAY(width,height);p++) if (*p==-1) {
      c = count = count_adjacent_blanks(p,blank);
      BLANK_REGION_TEST {
        for(p=&ARRAY(0,0);p<=&ARRAY(width,height);p++) 
          if (*p<=-10) *p=-1;
        return;
      }
      if (count<smallest_count) {
        smallest_count = count;
        smallest_blank = blank;
      }
      blank--;
    }
  }

#ifdef CREATE_STARTS
  if (nr_attached == search_depth) {
    nr_found++;
    print_solution();
    if (check_size_of_blank_regions)
      for(p=&ARRAY(0,0);p<=&ARRAY(width,height);p++) 
        if (*p<=-10) *p=-1;
    return;
  }
#endif

  worst_score=1000000000;
  for(p=&ARRAY(0,0);p<=&ARRAY(width,height);p++) if (*p==smallest_blank) {
    b = 0;
    if (p[ARRAY_INDEX_DISP(-1, 0)] != smallest_blank) b|=LEFT;
    if (p[ARRAY_INDEX_DISP( 1, 0)] != smallest_blank) b|=RIGHT;
    if (p[ARRAY_INDEX_DISP( 0,-1)] != smallest_blank) b|=UP;
    if (p[ARRAY_INDEX_DISP( 0, 1)] != smallest_blank) b|=DOWN;
    if (p[ARRAY_INDEX_DISP(-1,-1)] != smallest_blank) b|=LEFT_UP;
    if (p[ARRAY_INDEX_DISP(-1, 1)] != smallest_blank) b|=LEFT_DOWN;
    if (p[ARRAY_INDEX_DISP( 1,-1)] != smallest_blank) b|=RIGHT_UP;
    if (p[ARRAY_INDEX_DISP( 1, 1)] != smallest_blank) b|=RIGHT_DOWN;
    if (b!=0) {
      score=0;

      for (poly_no=0;poly_no<nr_polyominoes;poly_no++) if (!attached[poly_no]) {
        for (index=0;index<transform_len_ws[b][poly_no];index++) {
          current_displ = displ_ws[b][poly_no][index];
          for (i=0;i<LEN(poly_no);i++) {
            if (p[current_displ[i]] != smallest_blank)
              goto label2;
          }
          score++;
          if (score>=worst_score) goto label3;
          label2:;
        }
      }
      if (score == 0) {
        if (check_size_of_blank_regions)
          for(p=&ARRAY(0,0);p<=&ARRAY(width,height);p++) 
            if (*p<=-10) *p=-1;
      }
      if (score<worst_score) {
        worst_score = score;
        place_to_attach = p;
        bitmap = b;
      }
    }
    label3:;
  }

  if (check_size_of_blank_regions)
    for(p=&ARRAY(0,0);p<=&ARRAY(width,height);p++) 
      if (*p<=-10) *p=-1;

#ifdef CLIENT
  current_displ = displ_ws[bitmap][list[nr_attached].poly_no][list[nr_attached].index];
  for (i=0;i<len[list[nr_attached].poly_no];i++)
    place_to_attach[current_displ[i]] = list[nr_attached].poly_no;
  attached[list[nr_attached].poly_no] = 1;
  recursive_search_ws(nr_attached+1);
  for (i=0;i<len[list[nr_attached].poly_no];i++)
    place_to_attach[current_displ[i]] = -1;
  attached[list[nr_attached].poly_no] = 0;
#endif

#ifdef CREATE_STARTS
  for (poly_no=0;poly_no<nr_polyominoes;poly_no++) if (!attached[poly_no]) {
    for (index=0;index<transform_len_ws[bitmap][poly_no];index++) {
      current_displ = displ_ws[bitmap][poly_no][index];
      for (i=0;i<LEN(poly_no);i++) {
        if (place_to_attach[current_displ[i]] != -1)
          goto label;
      }

      for (i=0;i<LEN(poly_no);i++)
        place_to_attach[current_displ[i]] = poly_no;
      attached[poly_no] = 1;
      list[nr_attached].poly_no=poly_no;
      list[nr_attached].index=index;
      recursive_search_ws(nr_attached+1);
      for (i=0;i<LEN(poly_no);i++)
        place_to_attach[current_displ[i]] = -1;
      attached[poly_no] = 0;

      label:;
    }
  }
#endif
}

#ifdef CLIENT

void get_client_data(int *r) {
  read_file_type in_file;
  int i, j;
  char s[1000];
  int retry_count=0, success;

  retry:
/* retry every minute up to 2 days. */
  if (retry_count>2*24*60) exit(0);
  if (retry_count>0) sleep(60);
  if (prepare_socket_client(&(in_file.fd))==-1) {
    retry_count++;
    success = 0;
    goto retry;
  }
  in_file.buf_index = in_file.buf_size = 0;
  if (send_string(in_file.fd,"request data\n")==-1) {
    close(in_file.fd);
    retry_count++;
    success = 0;
    goto retry;
  }
  if (read_string(&in_file,s,1000)==NULL) {
    close(in_file.fd);
    retry_count++;
    success = 0;
    goto retry;
  }
  *r = atoi(s);
  j = 0;
  for (i=0;i<search_depth;i++) {
    while (s[j] != ' ') j++;
    while (s[j] == ' ') j++;
    if (s[j] == '\0') {
      close(in_file.fd);
      retry_count++;
      success = 0;
      goto retry;
    }
    list[i].poly_no = atoi(s+j);
    while (s[j] != ' ') j++;
    while (s[j] == ' ') j++;
    if (s[j] == '\0') {
      close(in_file.fd);
      retry_count++;
      success = 0;
      goto retry;
    }
    list[i].index = atoi(s+j);
  }
  close(in_file.fd);

}

void send_client_data(int r, double nr_found) {
  int out_fd;
  char s[1000];
  int retry_count=0, success;

  retry:
/* retry every minute up to 2 days. */
  if (retry_count>2*24*60) exit(0);
  if (retry_count>0) sleep(60);
  if (prepare_socket_client(&out_fd)==-1) {
    retry_count++;
    success = 0;
    goto retry;
  }
  if (send_string(out_fd,"sending data\n")==-1) {
    close(out_fd);
    retry_count++;
    success = 0;
    goto retry;
  }
  sprintf(s,"%d %.15g\n",r,nr_found);
  if (send_string(out_fd, s)==-1) {
    close(out_fd);
    retry_count++;
    success = 0;
    goto retry;
  }
  close(out_fd);
}

#endif

void make_polyomino();
void carve_out_shape();

int main(int argc, char **argv) {
  int x,y,i;
#ifdef CLIENT
  int r;

  setpriority(PRIO_PROCESS,0,20);
#ifndef CHECK_PROGRESS
  daemon(1,0);
#endif
#endif

  make_polyomino();
  compute_displ_ws();
  compute_displ_lu();
/* set the border values to -2 */
  for (i=0;i<sizeof(array)/sizeof(signed char);i++) array[i] = -2;
/* and initialise the blank spaces to -1 */
  for (x=0;x<width;x++) for (y=0;y<height;y++) ARRAY(x,y) = -1;
  carve_out_shape();
  memset(attached,0,sizeof(attached));
#ifdef CHECK_PROGRESS
  time_started = time(NULL);
#endif

#ifdef CREATE_STARTS
  out_file = fopen("start.out","w");
#endif
#ifdef CLIENT
  while (1) {
    get_client_data(&r);
#ifdef CHECK_PROGRESS
    printf("\n%d ",r);
    for (i=0;i<search_depth;i++)
      printf("%d %d ", list[i].poly_no, list[i].index);
    printf("\n");
    fflush(stdout);
#endif
    nr_found = 0;
#ifdef CHECK_PROGRESS
    time_started = time(NULL);
#endif
#endif
    recursive_search_ws(0);
#ifdef CHECK_PROGRESS
    printf("Total number %.15g\n",nr_found);
    printf("Time taken %ld\n",time(NULL)-time_started);
    fflush(stdout);
#endif
#ifdef CLIENT
    send_client_data(r,nr_found);
  }
#endif
  exit(0);
}
