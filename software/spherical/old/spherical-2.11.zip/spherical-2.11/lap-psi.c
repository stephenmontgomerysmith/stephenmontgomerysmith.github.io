/*
 * Created from lap-psi.conf by expand-iterate.pl.
 */

#include "spherical.h"

extern int max_order;
static int first = 1;

/* The multiplication constants. */
static COMPLEX *mult_constant;
#define mc_count 1
static void initialize_mc();

/* Converted into a threaded program by expand-thread.pl. */
#include <pthread.h>
static pthread_mutex_t job_m = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t job_c = PTHREAD_COND_INITIALIZER;
static struct {
  COMPLEX* lap_psi;
  COMPLEX* psi;
} compute_lap_psi_pass_args;
static void *compute_lap_psi_thread(void *arg);
static struct job_info_s {int control, lstart, lend;} *job_info;
static int first_thread = 1;
extern int nr_threads;

void compute_lap_psi(COMPLEX* lap_psi, COMPLEX* psi) {
  if (first) initialize_mc();
  pthread_t pid;
  int i;
  /* Start threads the first time around. */
  if (first_thread) {
    first_thread = 0;
    job_info = malloc(nr_threads*sizeof(struct job_info_s));
    for (i=0;i<nr_threads;i++) {
      job_info[i].control = 0;
      job_info[i].lstart = 0;
      job_info[i].lend = 0;
      pthread_create(&pid, NULL, compute_lap_psi_thread, job_info+i);
      pthread_detach(pid);
    }
  }
  /* Copy data to threads. */
  memcpy(&(compute_lap_psi_pass_args.lap_psi),&(lap_psi),sizeof(lap_psi));
  memcpy(&(compute_lap_psi_pass_args.psi),&(psi),sizeof(psi));
  pthread_mutex_lock(&job_m);
  /* The ranges for l are assigned to each thread.  Note that the work
     required to calculate for l between lstart and lend is proportional to
     lend^2 - lstart^2. */
  for (i=0;i<nr_threads;i++) {
    if (i==0) job_info[i].lstart = 0;
    else      job_info[i].lstart = job_info[i-1].lend;
    if (i==nr_threads-1) job_info[i].lend=max_order+1;
    else job_info[i].lend = (double)(max_order+1)*sqrt((i+1.)/(double)nr_threads);
    job_info[i].lend += (job_info[i].lend)%2; /* round up to next even number. */
  }
  /* Start each thread, and then wait for each thread to finish. */
  for (i=0;i<nr_threads;i++) {
    job_info[i].control = 1;
  }
  pthread_mutex_unlock(&job_m);
  pthread_cond_broadcast(&job_c);
  for (i=0;i<nr_threads;i++) {
    pthread_mutex_lock(&job_m);
    while (job_info[i].control != 0) {
      pthread_cond_wait(&job_c, &job_m);
    }
    pthread_mutex_unlock(&job_m);
  }
}

static void initialize_mc() {
  int l,m;
  double ll,mm;
  COMPLEX *mc;

  first = 0;
  allocate_many(&mult_constant,mc_count);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant + mc_count*ind(l,m);
    if (abs(m)<=l)
      mc[0] = (-(ll*(1+ll)))+(0)*I;
    else
      mc[0] = 0;
  }
}

static void * compute_lap_psi_thread(void *arg) {
  struct job_info_s* job_info = arg;
  while (1) {
    int lstart, lend;
    /* Wait until thread is told to start. */
    pthread_mutex_lock(&job_m);
    while (job_info->control != 1) {
      pthread_cond_wait(&job_c, &job_m);
    }
    lstart = job_info->lstart;
    lend = job_info->lend;
    pthread_mutex_unlock(&job_m);
    COMPLEX* lap_psi;
    COMPLEX* psi;
    /* Copy data to thread. */
    memcpy(&(lap_psi),&(compute_lap_psi_pass_args.lap_psi),sizeof(lap_psi));
    memcpy(&(psi),&(compute_lap_psi_pass_args.psi),sizeof(psi));
    int l,m;
    COMPLEX *mc;
    for (l=lstart;l<lend;l+=2) for (m=0;m<=l;m++) {
      mc = mult_constant + mc_count*ind(l,m);
      lap_psi[ind(l,m)] = (mc[0]*index(psi,l,m));
    }
    /* Broadcast that thread is finished. */
    pthread_mutex_lock(&job_m);
    job_info->control = 0;
    pthread_mutex_unlock(&job_m);
    pthread_cond_broadcast(&job_c);
  }
  return(NULL);
}
