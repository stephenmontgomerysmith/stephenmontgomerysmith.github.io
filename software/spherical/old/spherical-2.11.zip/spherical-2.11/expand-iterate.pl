#/usr/bin/perl -w

use strict;

use Expect::Simple;

sub plus {
  return $_[0] if $_[1]==0;
  return "$_[0]+$_[1]" if $_[1]>0;
  return "$_[0]$_[1]" if $_[1]<0;
}

my $filename = $ARGV[0];
open(IN,$filename);

my $main_program;
my $init_proc_assign;

my $mc_count = 0;

my %attr = (Cmd => "env TENSOR=0 perl expand-method.pl",
  Prompt => '> ',
  DisconnectCmd => "q"
);

my $methodcmd = Expect::Simple->new(\%attr);

while(my $line = <IN>) {
  my $text;
  if ($line=~/\@spherical_iterate\s*\{/) {
    while ($line = <IN>) {
      if ($line =~ /\}/) {
        last;
      } else {
        $text .= $line;
      }
    }
    $text =~s/^[\s^\n]*\n//;
    $text =~s/\s*$//;

    $main_program .= "  if (first) initialize_mc();\n";
    $main_program .= "  /* Start-Threading */\n";
    $main_program .= "  int lstart=0, lend=max_order+2;\n";
    $main_program .= "  int l,m;\n";
    $main_program .= "  COMPLEX *mc;\n";
    $main_program .= "  for (l=lstart;l<lend;l+=2) for (m=0;m<=l;m++) {\n";
    $main_program .= "    mc = mult_constant + mc_count*ind(l,m);\n";

    foreach $line (split "\n",$text) {
      $line =~ s/\@index/ind(l,m)/g;
      $line = "$line";
      while ($line =~ s/(.*?)\@method\((.*?)\,(.*?)\)//) {
        my $line_start = "$1(";
        my $var = $2;
        $methodcmd->send($3);
        my $response = $methodcmd->before;
        $response =~ s/\r//g;
        $response =~ s/.*?\n//;
        my @line_part;
        foreach my $comp(split "\n",$response) {
          my ($l,$m,$c) = split ';',$comp;
          $c =~ s/([lm])/\1\1/g;
          $init_proc_assign .= "    if (abs(".plus("m",$m).")<=".plus("l",$l).")\n".
                               "      mc[${mc_count}] = $c;\n".
                               "    else\n".
                               "      mc[${mc_count}] = 0;\n";
          push @line_part, "mc[${mc_count}]*index($var,".plus("l",$l).",".plus("m",$m).")";
          $mc_count++;
        }
        if ($#line_part >= 0) {
          $main_program .= $line_start.join("+",@line_part).")";
        } else {
          $main_program .= "${line_start}0)";
        }
      }
      $main_program .= "$line\n";
    }
    $main_program .= "  }\n";
    $main_program .= "  /* Stop-Threading */\n";
  } else {
    $main_program .= $line;
  }
}

chomp $init_proc_assign;

print <<EOM;
/*
 * Created from $filename by $0.
 */

\#include "spherical.h"

extern int max_order;
static int first = 1;

/* The multiplication constants. */
static COMPLEX *mult_constant;
#define mc_count $mc_count
static void initialize_mc();

$main_program
static void initialize_mc() {
  int l,m;
  double ll,mm;
  COMPLEX *mc;

  first = 0;
  allocate_many(&mult_constant,mc_count);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant + mc_count*ind(l,m);
$init_proc_assign
  }
}
EOM
