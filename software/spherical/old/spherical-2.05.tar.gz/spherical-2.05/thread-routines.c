#include <stdlib.h>
#include <pthread.h>

static pthread_mutex_t job_m = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t job_c = PTHREAD_COND_INITIALIZER;

void set_job_to(int *job, int val) {
  pthread_mutex_lock(&job_m);
  *job = val;
  pthread_mutex_unlock(&job_m);
  pthread_cond_broadcast(&job_c);
}

void wait_job_until(int *job, int val) {
  pthread_mutex_lock(&job_m);
  while (*job != val) {
    pthread_cond_wait(&job_c, &job_m);
  }
  pthread_mutex_unlock(&job_m);
}

void start_background_job(void*(*job)(void*), int job_nr) {
  pthread_t pid;
  int *pass_job_nr = malloc(sizeof(int));
  *pass_job_nr = job_nr;
  pthread_create(&pid, NULL, job, pass_job_nr);
  pthread_detach(pid);
}
