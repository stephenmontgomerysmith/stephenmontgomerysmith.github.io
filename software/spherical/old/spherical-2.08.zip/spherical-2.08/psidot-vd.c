/*
 * Created from psidot-vd.conf by expand-iterate.pl.
 */

#include "spherical.h"

/* Used to pass arguments to the threads. */
static struct {COMPLEX* psidot; COMPLEX* psi;} data_arg;

/* Used to switch the threads on and off, and to set the range of l for each thread.*/
static int nr_jobs, *job_control, *lstart, *lend;

static int first = 1;
extern int max_order;

/* The multiplication constants. */
static COMPLEX *mult_constant;
#define mc_count 1

/*
 * This is the function that does all the work.  It is run several times
 * by different threads.
 */
extern double gamm[3][3];
extern double normgamma;
extern double C1;
extern int max_order;
extern int do_vd;

static double Dr2;

static void common_psidot_vd(COMPLEX* psi) {
  int i1,i2,i3,i4;
  double a2[3][3];
  double a4[3][3][3][3];  double s;

  s = 0;
  if (do_vd == 1) {
    tensor2(psi,a2);
    for (i1=0;i1<3;i1++) for (i2=0;i2<3;i2++)
      s += a2[i1][i2]*gamm[i1][i2];
    s = fabs(s);
  } else if (do_vd ==2) {
    tensor4(psi,a4);
    for (i1=0;i1<3;i1++) for (i2=0;i2<3;i2++) for (i3=0;i3<3;i3++) for (i4=0;i4<3;i4++)
      s += a4[i1][i2][i3][i4]*gamm[i1][i2]*gamm[i3][i4];
    s = sqrt(s);
  }
  Dr2 = C1*s;
}

static void *compute_psidot_vd_thread(void *arg) {
  int job_nr = *(int*)arg;
  free(arg);
  int l,m,local_lstart,local_lend;
  COMPLEX *mc;
  COMPLEX* psidot; COMPLEX* psi;
  while (1) {
    wait_job_until(job_control+job_nr,1);
    psidot = data_arg.psidot;
    psi = data_arg.psi;
    local_lstart = lstart[job_nr];
    local_lend = lend[job_nr];
    for (l=local_lstart;l<local_lend;l+=2) for (m=0;m<=l;m++) {
      mc = mult_constant + mc_count*ind(l,m);
      psidot[ind(l,m)] += Dr2*(mc[0]*index(psi,l,m));
    }
    set_job_to(job_control+job_nr,0);
  }
  return NULL;
}

/*
 * This function initializes compute_psidot_vd in the following ways:
 * 1. allocate space and calculate the multiplication constants;
 * 2. if called the first time, allocate the thread control variables
 *    job_control[] and start the threads;
 * 3. tell each thread which range to calculate via the lstart[] and lend[]
 *    variables.
 */
void compute_psidot_vd_initialize(int nr_threads) {
  int l,m;
  int i;
  double ll,mm;
  COMPLEX *mc;

  allocate_many(&mult_constant,mc_count);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant + mc_count*ind(l,m);
    if (abs(m)<=l)
      mc[0] = (-(ll*(1+ll)))+(0)*I;
    else
      mc[0] = 0;
  }

/* The first time the function is called, start the background threads. */
  if (first) {
    nr_jobs = nr_threads;
    job_control = malloc(nr_jobs*sizeof(int));
    lstart = malloc(nr_jobs*sizeof(int));
    lend = malloc(nr_jobs*sizeof(int));
    memset(job_control,0,nr_jobs*sizeof(int));
    for (i=0;i<nr_jobs;i++) {
      start_background_job(compute_psidot_vd_thread,i);
    }
    first = 0;
  }
/* The ranges for l are assigned to each thread.  Note that the work
   required to calculate for l between lstart and lend is proportional to
   lend^2 - lstart^2. */
  for (i=0;i<nr_jobs;i++) {
    if (i==0) lstart[i] = 0;
    else      lstart[i] = lend[i-1];
    if (i==nr_jobs-1) lend[i]=max_order+1;
    else lend[i] = (double)(max_order+1)*sqrt((i+1.)/(double)nr_jobs);
    lend[i] += lend[i]%2; /* round up to next even number. */
  }
}

/*
 * The main function.  After passing the arguments, it starts each
 * thread, and then waits for each thread to finish.
 */
void compute_psidot_vd(COMPLEX* psidot, COMPLEX* psi) {
  int i;
  data_arg.psidot = psidot;
  data_arg.psi = psi;
  common_psidot_vd(psi);
  for (i=0;i<nr_jobs;i++) set_job_to(job_control+i,1);
  for (i=0;i<nr_jobs;i++) wait_job_until(job_control+i,0);
}
