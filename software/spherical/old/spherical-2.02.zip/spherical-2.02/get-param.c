#include "spherical.h"

static char s[1024];
static char zero[] = "0";
static char *filename = "parameters.txt";
static int verbose=0;

void set_param_filename(char *f) {
  filename = f;
}

void set_param_verbose_level(int v) {
  verbose = v;
}

static char * get_line(char *p, int die_if_none) {
  FILE *par_file;
  par_file = fopen(filename,"r");
  if (par_file==NULL) {
    perror("Error opening parameter file");
    exit(1);
  }
  while (fgets(s,sizeof(s)-1,par_file)!=NULL)
    if (strncmp(p,s,strlen(p))==0 && s[strlen(p)]=='=') {
      fclose(par_file);
      return s+strlen(p)+1;
    }
  if (die_if_none) {
    fprintf(stderr,"Parameter file is missing %s\n",p);
    exit(1);
  } else
    return zero;
}

double param_bool(char *p) {
  int r;
  r = strtol(get_line(p,0),NULL,10);
  if (verbose) printf("%s=%d\n",p,r);
  return r;
}

double param_int(char *p) {
  int r;
  r = strtol(get_line(p,1),NULL,10);
  if (verbose) printf("%s=%d\n",p,r);
  return r;
}

double param_double(char *p) {
  double r;
  r = strtod(get_line(p,1),NULL);
  if (verbose) printf("%s=%g\n",p,r);
  return r;
}

int param_choice(char *p, ...) {
  va_list args;
  char *s,*t;
  int r;
  s = get_line(p,0);
  while (strlen(s)>0 && isspace(s[strlen(s)-1])) s[strlen(s)-1] = '\0';
  va_start(args,p);
  while (strcmp(t=va_arg(args,char*),"")!=0) {
    r = va_arg(args,int);
    if (strcmp(s,t)==0) {
      va_end(args);
      if (verbose) printf("%s=%s\n",p,s);
      return r;
    }
  }
  fprintf(stderr,"Parameter %s not set to acceptable value.\n",p);
  exit(1);
}

void print_parameters(FILE *sout) {
  FILE *par_file;
  par_file = fopen("parameters.txt","r");
  if (par_file==NULL) {
    perror("Error opening parameter file");
    exit(1);
  }
  while (fgets(s,sizeof(s)-1,par_file)!=NULL)
    fputs(s,sout);
  fclose(par_file);
}
