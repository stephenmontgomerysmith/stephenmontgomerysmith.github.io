#!/bin/sh

make clean

perl -i -p -e 's/\r*\n/\r\n/g' parameters*.txt

for t in *.tex; do \
  pdflatex $t
  pdflatex $t
done

make clean

PWD=`pwd`
DIR=`basename $PWD`

cd ..
tar cvfz $DIR.tar.gz $DIR
rm -f $DIR.zip
zip -r $DIR.zip $DIR
