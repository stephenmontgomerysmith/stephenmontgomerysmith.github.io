#include "spherical.h"

int param_filename_set = 0;

void get_parameters(int argc, const char **argv, piecewise_fun_t **pf) {
  int i;

  for (i=1;i<argc; i++) {
    if (strcmp(argv[i],"-p")==0 && i+1<argc) {
      i++;
      set_param_filename(argv[i]);
      param_filename_set = 1;
    }
    else {
      param_filename_set = 0;
      break;
    }
  }
  if (!param_filename_set) {
    printf("Usage: %s -p <parameters-file> [-o <output-file>] [-v [<number>]]\n"
           "  if -o is not set, <output-file> defaults to \"s.out\".\n"
           "  -v gives verbose output.\n"
           "  <number> is how often to print output to terminal.\n", argv[0]);
    exit(0);
  }

  *pf = param_piecewise_fun("pf");
  done_with_param();
}


main(int argc, const char **argv) {
  piecewise_fun_t *pf;
  REAL x;

  get_parameters(argc, argv, &pf);

  for (x=-4;x<=4.001;x+=0.1) {
    printf("%g %g\n",x,evaluate_piecewise_fun(pf,x));
  }
}
