/*
 * Created from psidot-dd-3.conf by expand-iterate.pl.
 */

#include "spherical.h"

/* Used to pass arguments to the threads. */
static struct {COMPLEX* psidot; COMPLEX* psi;} data_arg;

/* Used to switch the threads on and off, and to set the range of l for each thread.*/
static int nr_jobs, *job_control, *lstart, *lend;

static int first = 1;
extern int max_order;

/* The multiplication constants. */
static COMPLEX *mult_constant;
#define mc_count 1

/*
 * This is the function that does all the work.  It is run several times
 * by different threads.
 */
extern double gamm[3][3];
extern double normgamma;
extern double C1, C2;
extern COMPLEX *lap_psi;
static double Dr2;

static void common_psidot_dd_3(COMPLEX* psi) {
  int i,j;
  double a2[3][3];
  double s;
  tensor2(psi,a2);
  s = 0;
  for (i=0;i<3;i++) for (j=0;j<3;j++) s += a2[i][j]*gamm[i][j];
  Dr2 = s*s/normgamma;
}

static void *compute_psidot_dd_3_thread(void *arg) {
  int job_nr = *(int*)arg;
  free(arg);
  int l,m,local_lstart,local_lend;
  COMPLEX *mc;
  COMPLEX* psidot; COMPLEX* psi;
  while (1) {
    wait_job_until(job_control+job_nr,1);
    psidot = data_arg.psidot;
    psi = data_arg.psi;
    local_lstart = lstart[job_nr];
    local_lend = lend[job_nr];
    for (l=local_lstart;l<local_lend;l+=2) for (m=0;m<=l;m++) {
      mc = mult_constant + mc_count*ind(l,m);
      psidot[ind(l,m)] += (C1*Dr2 + C2*normgamma)*(mc[0]*index(psi,l,m));
    }
    set_job_to(job_control+job_nr,0);
  }
  return NULL;
}

/*
 * This function initializes compute_psidot_dd_3 in the following ways:
 * 1. allocate space and calculate the multiplication constants;
 * 2. if called the first time, allocate the thread control variables
 *    job_control[] and start the threads;
 * 3. tell each thread which range to calculate via the lstart[] and lend[]
 *    variables.
 */
void compute_psidot_dd_3_initialize(int nr_threads) {
  int l,m;
  int i;
  double ll,mm;
  COMPLEX *mc;

  allocate_many(&mult_constant,mc_count);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant + mc_count*ind(l,m);
    if (abs(m)<=l)
      mc[0] = (-(ll*(1+ll)))+(0)*I;
    else
      mc[0] = 0;
  }

/* The first time the function is called, start the background threads. */
  if (first) {
    nr_jobs = nr_threads;
    job_control = malloc(nr_jobs*sizeof(int));
    lstart = malloc(nr_jobs*sizeof(int));
    lend = malloc(nr_jobs*sizeof(int));
    memset(job_control,0,nr_jobs*sizeof(int));
    for (i=0;i<nr_jobs;i++) {
      start_background_job(compute_psidot_dd_3_thread,i);
    }
    first = 0;
  }
/* The ranges for l are assigned to each thread.  Note that the work
   required to calculate for l between lstart and lend is proportional to
   lend^2 - lstart^2. */
  for (i=0;i<nr_jobs;i++) {
    if (i==0) lstart[i] = 0;
    else      lstart[i] = lend[i-1];
    if (i==nr_jobs-1) lend[i]=max_order+1;
    else lend[i] = (double)(max_order+1)*sqrt((i+1.)/(double)nr_jobs);
    lend[i] += lend[i]%2; /* round up to next even number. */
  }
}

/*
 * The main function.  After passing the arguments, it starts each
 * thread, and then waits for each thread to finish.
 */
void compute_psidot_dd_3(COMPLEX* psidot, COMPLEX* psi) {
  int i;
  data_arg.psidot = psidot;
  data_arg.psi = psi;
  common_psidot_dd_3(psi);
  for (i=0;i<nr_jobs;i++) set_job_to(job_control+i,1);
  for (i=0;i<nr_jobs;i++) wait_job_until(job_control+i,0);
}
