/*
 * Created from psidot-koch.conf by expand-iterate.pl.
 */

#include "spherical.h"

extern int max_order;
static int first = 1;

/* The multiplication constants. */
static COMPLEX *mult_constant;
#define mc_count 40
static void initialize_mc();

extern double gamm[3][3];
extern double normgamma;
extern double C1, C2;

/* Converted into a threaded program by expand-thread.pl. */
#include <pthread.h>
static pthread_mutex_t job_m = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t job_c = PTHREAD_COND_INITIALIZER;
static struct {
  COMPLEX* psidot;
  COMPLEX* psi;
  double Dr[3][3];
} compute_psidot_koch_pass_args;
static void *compute_psidot_koch_thread(void *arg);
static struct job_info_s {int control, lstart, lend;} *job_info;
static int first_thread = 1;
extern int nr_threads;

void compute_psidot_koch(COMPLEX* psidot, COMPLEX* psi) {
  double a4[3][3][3][3], a6[3][3][3][3][3][3], diag;
  int i1,i2,i3,i4,i5,i6;
  double Dr[3][3];

  tensor4(psi,a4);
  tensor6(psi,a6);
  diag = 0;
  for (i1=0;i1<3;i1++) for (i2=0;i2<3;i2++) {
    Dr[i1][i2] = 0;
    for (i3=0;i3<3;i3++) for (i4=0;i4<3;i4++) {
      diag += a4[i1][i2][i3][i4]*gamm[i1][i2]*gamm[i3][i4]/normgamma;
      for (i5=0;i5<3;i5++) for (i6=0;i6<3;i6++)
        Dr[i1][i2] += C2*a6[i1][i2][i3][i4][i5][i6]*gamm[i3][i4]*gamm[i5][i6]/normgamma;
    }
  }
  for (i1=0;i1<3;i1++) Dr[i1][i1] += C1*diag;

  if (first) initialize_mc();
  pthread_t pid;
  int i;
  /* Start threads the first time around. */
  if (first_thread) {
    first_thread = 0;
    job_info = malloc(nr_threads*sizeof(struct job_info_s));
    for (i=0;i<nr_threads;i++) {
      job_info[i].control = 0;
      job_info[i].lstart = 0;
      job_info[i].lend = 0;
      pthread_create(&pid, NULL, compute_psidot_koch_thread, job_info+i);
      pthread_detach(pid);
    }
  }
  /* Copy data to threads. */
  memcpy(&(compute_psidot_koch_pass_args.psidot),&(psidot),sizeof(psidot));
  memcpy(&(compute_psidot_koch_pass_args.psi),&(psi),sizeof(psi));
  memcpy(&(compute_psidot_koch_pass_args.Dr),&(Dr),sizeof(Dr));
  pthread_mutex_lock(&job_m);
  /* The ranges for l are assigned to each thread.  Note that the work
     required to calculate for l between lstart and lend is proportional to
     lend^2 - lstart^2. */
  for (i=0;i<nr_threads;i++) {
    if (i==0) job_info[i].lstart = 0;
    else      job_info[i].lstart = job_info[i-1].lend;
    if (i==nr_threads-1) job_info[i].lend=max_order+1;
    else job_info[i].lend = (double)(max_order+1)*sqrt((i+1.)/(double)nr_threads);
    job_info[i].lend += (job_info[i].lend)%2; /* round up to next even number. */
  }
  /* Start each thread, and then wait for each thread to finish. */
  for (i=0;i<nr_threads;i++) {
    job_info[i].control = 1;
  }
  pthread_mutex_unlock(&job_m);
  pthread_cond_broadcast(&job_c);
  for (i=0;i<nr_threads;i++) {
    pthread_mutex_lock(&job_m);
    while (job_info[i].control != 0) {
      pthread_cond_wait(&job_c, &job_m);
    }
    pthread_mutex_unlock(&job_m);
  }
}

static void initialize_mc() {
  int l,m;
  double ll,mm;
  COMPLEX *mc;

  first = 0;
  allocate_many(&mult_constant,mc_count);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant + mc_count*ind(l,m);
    if (abs(m-2)<=l-2)
      mc[0] = ((ll*(1+ll)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[0] = 0;
    if (abs(m)<=l-2)
      mc[1] = (-(ll*(1+ll)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[1] = 0;
    if (abs(m+2)<=l-2)
      mc[2] = ((ll*(1+ll)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[2] = 0;
    if (abs(m-2)<=l)
      mc[3] = (((-3+2*ll+2*pow(ll,2))*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[3] = 0;
    if (abs(m)<=l)
      mc[4] = ((4*pow(ll,3)+2*pow(ll,4)-3*pow(mm,2)+ll*(-1+2*pow(mm,2))+pow(ll,2)*(1+2*pow(mm,2)))/(6-8*ll-8*pow(ll,2)))+(0)*I;
    else
      mc[4] = 0;
    if (abs(m+2)<=l)
      mc[5] = (((-3+2*ll+2*pow(ll,2))*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[5] = 0;
    if (abs(m-2)<=l+2)
      mc[6] = ((ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm))/(4.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[6] = 0;
    if (abs(m)<=l+2)
      mc[7] = (-(ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(2.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[7] = 0;
    if (abs(m+2)<=l+2)
      mc[8] = ((ll*(1+ll)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(4.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[8] = 0;
    if (abs(m-2)<=l-2)
      mc[9] = (0)+(-(ll*(1+ll)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[9] = 0;
    if (abs(m+2)<=l-2)
      mc[10] = (0)+((ll*(1+ll)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[10] = 0;
    if (abs(m-2)<=l)
      mc[11] = (0)+(-((-3+2*ll+2*pow(ll,2))*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[11] = 0;
    if (abs(m)<=l)
      mc[12] = (0)+(-mm/2.)*I;
    else
      mc[12] = 0;
    if (abs(m+2)<=l)
      mc[13] = (0)+(((-3+2*ll+2*pow(ll,2))*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[13] = 0;
    if (abs(m-2)<=l+2)
      mc[14] = (0)+(-(ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm))/(4.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))*I;
    else
      mc[14] = 0;
    if (abs(m+2)<=l+2)
      mc[15] = (0)+((ll*(1+ll)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(4.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))*I;
    else
      mc[15] = 0;
    if (abs(m-1)<=l-2)
      mc[16] = ((ll*(1+ll)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[16] = 0;
    if (abs(m+1)<=l-2)
      mc[17] = (-(ll*(1+ll)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[17] = 0;
    if (abs(m-1)<=l)
      mc[18] = ((sqrt(1+ll-mm)*sqrt(ll+mm)*(ll-3*mm+2*ll*mm+pow(ll,2)*(1+2*mm)))/(6-8*ll-8*pow(ll,2)))+(0)*I;
    else
      mc[18] = 0;
    if (abs(m+1)<=l)
      mc[19] = ((sqrt(ll-mm)*sqrt(1+ll+mm)*(ll+pow(ll,2)*(1-2*mm)+3*mm-2*ll*mm))/(-6+8*ll+8*pow(ll,2)))+(0)*I;
    else
      mc[19] = 0;
    if (abs(m-1)<=l+2)
      mc[20] = (-(ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm))/(2.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[20] = 0;
    if (abs(m+1)<=l+2)
      mc[21] = ((ll*(1+ll)*sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(2.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[21] = 0;
    if (abs(m-2)<=l-2)
      mc[22] = (-(ll*(1+ll)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[22] = 0;
    if (abs(m)<=l-2)
      mc[23] = (-(ll*(1+ll)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[23] = 0;
    if (abs(m+2)<=l-2)
      mc[24] = (-(ll*(1+ll)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[24] = 0;
    if (abs(m-2)<=l)
      mc[25] = (-((-3+2*ll+2*pow(ll,2))*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[25] = 0;
    if (abs(m)<=l)
      mc[26] = ((4*pow(ll,3)+2*pow(ll,4)-3*pow(mm,2)+ll*(-1+2*pow(mm,2))+pow(ll,2)*(1+2*pow(mm,2)))/(6-8*ll-8*pow(ll,2)))+(0)*I;
    else
      mc[26] = 0;
    if (abs(m+2)<=l)
      mc[27] = (-((-3+2*ll+2*pow(ll,2))*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[27] = 0;
    if (abs(m-2)<=l+2)
      mc[28] = (-(ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm))/(4.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[28] = 0;
    if (abs(m)<=l+2)
      mc[29] = (-(ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(2.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[29] = 0;
    if (abs(m+2)<=l+2)
      mc[30] = (-(ll*(1+ll)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(4.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[30] = 0;
    if (abs(m-1)<=l-2)
      mc[31] = (0)+(-(ll*(1+ll)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[31] = 0;
    if (abs(m+1)<=l-2)
      mc[32] = (0)+(-(ll*(1+ll)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[32] = 0;
    if (abs(m-1)<=l)
      mc[33] = (0)+((sqrt(1+ll-mm)*sqrt(ll+mm)*(ll-3*mm+2*ll*mm+pow(ll,2)*(1+2*mm)))/(-6+8*ll+8*pow(ll,2)))*I;
    else
      mc[33] = 0;
    if (abs(m+1)<=l)
      mc[34] = (0)+((sqrt(ll-mm)*sqrt(1+ll+mm)*(ll+pow(ll,2)*(1-2*mm)+3*mm-2*ll*mm))/(-6+8*ll+8*pow(ll,2)))*I;
    else
      mc[34] = 0;
    if (abs(m-1)<=l+2)
      mc[35] = (0)+((ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm))/(2.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))*I;
    else
      mc[35] = 0;
    if (abs(m+1)<=l+2)
      mc[36] = (0)+((ll*(1+ll)*sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(2.*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))*I;
    else
      mc[36] = 0;
    if (abs(m)<=l-2)
      mc[37] = ((ll*(1+ll)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[37] = 0;
    if (abs(m)<=l)
      mc[38] = ((-4*pow(ll,3)-2*pow(ll,4)-3*pow(mm,2)+2*pow(ll,2)*pow(mm,2)+2*ll*(1+pow(mm,2)))/(-3+4*ll+4*pow(ll,2)))+(0)*I;
    else
      mc[38] = 0;
    if (abs(m)<=l+2)
      mc[39] = ((ll*(1+ll)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)))+(0)*I;
    else
      mc[39] = 0;
  }
}

static void * compute_psidot_koch_thread(void *arg) {
  struct job_info_s* job_info = arg;
  while (1) {
    int lstart, lend;
    /* Wait until thread is told to start. */
    pthread_mutex_lock(&job_m);
    while (job_info->control != 1) {
      pthread_cond_wait(&job_c, &job_m);
    }
    lstart = job_info->lstart;
    lend = job_info->lend;
    pthread_mutex_unlock(&job_m);
    COMPLEX* psidot;
    COMPLEX* psi;
    double Dr[3][3];
    /* Copy data to thread. */
    memcpy(&(psidot),&(compute_psidot_koch_pass_args.psidot),sizeof(psidot));
    memcpy(&(psi),&(compute_psidot_koch_pass_args.psi),sizeof(psi));
    memcpy(&(Dr),&(compute_psidot_koch_pass_args.Dr),sizeof(Dr));
    int l,m;
    COMPLEX *mc;
    for (l=lstart;l<lend;l+=2) for (m=0;m<=l;m++) {
      mc = mult_constant + mc_count*ind(l,m);
      psidot[ind(l,m)] += Dr[0][0]*(mc[0]*index(psi,l-2,m-2)+mc[1]*index(psi,l-2,m)+mc[2]*index(psi,l-2,m+2)+mc[3]*index(psi,l,m-2)+mc[4]*index(psi,l,m)+mc[5]*index(psi,l,m+2)+mc[6]*index(psi,l+2,m-2)+mc[7]*index(psi,l+2,m)+mc[8]*index(psi,l+2,m+2))
                        + 2*Dr[0][1]*(mc[9]*index(psi,l-2,m-2)+mc[10]*index(psi,l-2,m+2)+mc[11]*index(psi,l,m-2)+mc[12]*index(psi,l,m)+mc[13]*index(psi,l,m+2)+mc[14]*index(psi,l+2,m-2)+mc[15]*index(psi,l+2,m+2))
                        + 2*Dr[0][2]*(mc[16]*index(psi,l-2,m-1)+mc[17]*index(psi,l-2,m+1)+mc[18]*index(psi,l,m-1)+mc[19]*index(psi,l,m+1)+mc[20]*index(psi,l+2,m-1)+mc[21]*index(psi,l+2,m+1))
                        + Dr[1][1]*(mc[22]*index(psi,l-2,m-2)+mc[23]*index(psi,l-2,m)+mc[24]*index(psi,l-2,m+2)+mc[25]*index(psi,l,m-2)+mc[26]*index(psi,l,m)+mc[27]*index(psi,l,m+2)+mc[28]*index(psi,l+2,m-2)+mc[29]*index(psi,l+2,m)+mc[30]*index(psi,l+2,m+2))
                        + 2*Dr[1][2]*(mc[31]*index(psi,l-2,m-1)+mc[32]*index(psi,l-2,m+1)+mc[33]*index(psi,l,m-1)+mc[34]*index(psi,l,m+1)+mc[35]*index(psi,l+2,m-1)+mc[36]*index(psi,l+2,m+1))
                        + Dr[2][2]*(mc[37]*index(psi,l-2,m)+mc[38]*index(psi,l,m)+mc[39]*index(psi,l+2,m));
    }
    /* Broadcast that thread is finished. */
    pthread_mutex_lock(&job_m);
    job_info->control = 0;
    pthread_mutex_unlock(&job_m);
    pthread_cond_broadcast(&job_c);
  }
  return(NULL);
}
