/*
 * Created from lap-psi.conf by expand-iterate.pl.
 */

#include "spherical.h"

extern int max_order;
static int first = 1;

/* The multiplication constants. */
static COMPLEX *mult_constant;
#define mc_count 1
static void initialize_mc();

void compute_lap_psi(COMPLEX* lap_psi, COMPLEX* psi) {
  if (first) initialize_mc();
  /* Start-Threading */
  int lstart=0, lend=max_order+2;
  int l,m;
  COMPLEX *mc;
  for (l=lstart;l<lend;l+=2) for (m=0;m<=l;m++) {
    mc = mult_constant + mc_count*ind(l,m);
    lap_psi[ind(l,m)] = (mc[0]*index(psi,l,m));
  }
  /* Stop-Threading */
}

static void initialize_mc() {
  int l,m;
  double ll,mm;
  COMPLEX *mc;

  first = 0;
  allocate_many(&mult_constant,mc_count);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant + mc_count*ind(l,m);
    if (abs(m)<=l)
      mc[0] = (-(ll*(1+ll)))+(0)*I;
    else
      mc[0] = 0;
  }
}
