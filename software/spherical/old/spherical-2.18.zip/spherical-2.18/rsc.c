#include "spherical.h"

extern double kappa;
static int first_time=1;

void compute_psidot_rsc(COMPLEX* psidot, COMPLEX* psi) {
  double a2[3][3];
  double da2[3][3];
  double collapsed_da2[3][3];
  int i,j;

  if (first_time) {
    first_time = 0;
    if (getenv("MAY_USE_PATENT_7266469")==NULL) {
      char answer[10];
      printf("Do you understand that this program uses intellectual property protected by U.S. Patent No. 7,266,469? ");
      fgets(answer,10,stdin);
      if (strcmp(answer,"yes\n")!=0) {
        printf("This program will not run if given an answer other than \"yes\" (written in full).\n");
        exit(0);
      }
    }
  }

  tensor2(psi,a2);
  tensor2(psidot,da2);
  collapse(3,da2,collapsed_da2,a2);
  for (i=0;i<3;i++) for (j=0;j<3;j++)
    collapsed_da2[i][j] *= -(1-kappa);
  reverse_tensor2(collapsed_da2,psidot);
}
