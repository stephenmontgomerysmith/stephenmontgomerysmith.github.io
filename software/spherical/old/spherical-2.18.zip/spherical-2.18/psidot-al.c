/*
 * Created from psidot-al.conf by expand-iterate.pl.
 */

#include "spherical.h"

extern int max_order;
static int first_mc_0 = 1;
static COMPLEX *mult_constant_0;
#define mc_count_0 250
static void initialize_mc_0();

static int first_mc_1 = 1;
static COMPLEX *mult_constant_1;
#define mc_count_1 45
static void initialize_mc_1();

/* Converted into a threaded program by expand-thread.pl. */
#include <pthread.h>
extern int nr_threads;
static pthread_mutex_t job_m = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t job_c = PTHREAD_COND_INITIALIZER;
struct job_info_s {int control, lstart, lend;};
static struct {
  COMPLEX* psi;
} thread_pass_args_0;
static void *thread_function_0(void *arg);
static int first_thread_0 = 1;
static struct job_info_s *job_info_0;
static struct {
  COMPLEX* psidot;
  COMPLEX* psi;
} thread_pass_args_1;
static void *thread_function_1(void *arg);
static int first_thread_1 = 1;
static struct job_info_s *job_info_1;


extern double w[3];
extern double gamm[3][3];
extern double lambda;
extern double Dr;
extern double kappa;

static COMPLEX *psi1=NULL;

void compute_psidot_al(COMPLEX* psidot, COMPLEX* psi) {

  if (psi1==NULL) allocate(&psi1);
  {
    if (first_mc_0) initialize_mc_0();
    pthread_t pid;
    int i;
    /* Start threads the first time around. */
    if (first_thread_0) {
      first_thread_0 = 0;
      job_info_0 = malloc(nr_threads*sizeof(struct job_info_s));
      for (i=0;i<nr_threads;i++) {
        job_info_0[i].control = 0;
        job_info_0[i].lstart = 0;
        job_info_0[i].lend = 0;
        pthread_create(&pid, NULL, thread_function_0, job_info_0+i);
        pthread_detach(pid);
      }
    }
    /* Copy data to threads. */
    memcpy(&(thread_pass_args_0.psi),&(psi),sizeof(psi));
    pthread_mutex_lock(&job_m);
    /* The ranges for l are assigned to each thread.  Note that the work
       required to calculate for l between lstart and lend is proportional to
       lend^2 - lstart^2. */
    for (i=0;i<nr_threads;i++) {
      if (i==0) job_info_0[i].lstart = 0;
      else      job_info_0[i].lstart = job_info_0[i-1].lend;
      if (i==nr_threads-1) job_info_0[i].lend=max_order+1;
      else job_info_0[i].lend = (double)(max_order+1)*sqrt((i+1.)/(double)nr_threads);
      job_info_0[i].lend += (job_info_0[i].lend)%2; /* round up to next even number. */
    }
    /* Start each thread, and then wait for each thread to finish. */
    for (i=0;i<nr_threads;i++) {
      job_info_0[i].control = 1;
    }
    pthread_mutex_unlock(&job_m);
    pthread_cond_broadcast(&job_c);
    for (i=0;i<nr_threads;i++) {
      pthread_mutex_lock(&job_m);
      while (job_info_0[i].control != 0) {
        pthread_cond_wait(&job_c, &job_m);
      }
      pthread_mutex_unlock(&job_m);
    }
  }

  {
    if (first_mc_1) initialize_mc_1();
    pthread_t pid;
    int i;
    /* Start threads the first time around. */
    if (first_thread_1) {
      first_thread_1 = 0;
      job_info_1 = malloc(nr_threads*sizeof(struct job_info_s));
      for (i=0;i<nr_threads;i++) {
        job_info_1[i].control = 0;
        job_info_1[i].lstart = 0;
        job_info_1[i].lend = 0;
        pthread_create(&pid, NULL, thread_function_1, job_info_1+i);
        pthread_detach(pid);
      }
    }
    /* Copy data to threads. */
    memcpy(&(thread_pass_args_1.psidot),&(psidot),sizeof(psidot));
    memcpy(&(thread_pass_args_1.psi),&(psi),sizeof(psi));
    pthread_mutex_lock(&job_m);
    /* The ranges for l are assigned to each thread.  Note that the work
       required to calculate for l between lstart and lend is proportional to
       lend^2 - lstart^2. */
    for (i=0;i<nr_threads;i++) {
      if (i==0) job_info_1[i].lstart = 0;
      else      job_info_1[i].lstart = job_info_1[i-1].lend;
      if (i==nr_threads-1) job_info_1[i].lend=max_order+1;
      else job_info_1[i].lend = (double)(max_order+1)*sqrt((i+1.)/(double)nr_threads);
      job_info_1[i].lend += (job_info_1[i].lend)%2; /* round up to next even number. */
    }
    /* Start each thread, and then wait for each thread to finish. */
    for (i=0;i<nr_threads;i++) {
      job_info_1[i].control = 1;
    }
    pthread_mutex_unlock(&job_m);
    pthread_cond_broadcast(&job_c);
    for (i=0;i<nr_threads;i++) {
      pthread_mutex_lock(&job_m);
      while (job_info_1[i].control != 0) {
        pthread_cond_wait(&job_c, &job_m);
      }
      pthread_mutex_unlock(&job_m);
    }
  }
}

static void initialize_mc_0() {
  int l,m;
  double ll,mm;
  COMPLEX *mc;

  first_mc_0 = 0;
  allocate_many(&mult_constant_0,mc_count_0);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant_0 + mc_count_0*ind(l,m);
    if (abs(m-2)<=l-2)
      mc[0] = ((sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-5+2*pow(ll,2)-3*mm-2*ll*mm+2*pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[0] = 0;
    if (abs(m-4)<=l-2)
      mc[1] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*sqrt(1+2*ll)*(15-26*ll-12*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[1] = 0;
    if (abs(m)<=l-2)
      mc[2] = ((-3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-4-ll+pow(ll,2)+pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[2] = 0;
    if (abs(m+2)<=l-2)
      mc[3] = ((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*(-5+2*pow(ll,2)+3*mm+2*ll*mm+2*pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[3] = 0;
    if (abs(m+4)<=l-2)
      mc[4] = (-(sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(4.*sqrt(-3+2*ll)*sqrt(1+2*ll)*(15-26*ll-12*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[4] = 0;
    if (abs(m-2)<=l-4)
      mc[5] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*sqrt(1+2*ll)*(15-46*ll+36*pow(ll,2)-8*pow(ll,3))))+(0)*I;
    else
      mc[5] = 0;
    if (abs(m-4)<=l-4)
      mc[6] = ((sqrt(-7+ll+mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(16.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[6] = 0;
    if (abs(m)<=l-4)
      mc[7] = ((3*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[7] = 0;
    if (abs(m+2)<=l-4)
      mc[8] = ((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*sqrt(1+2*ll)*(15-46*ll+36*pow(ll,2)-8*pow(ll,3))))+(0)*I;
    else
      mc[8] = 0;
    if (abs(m+4)<=l-4)
      mc[9] = ((sqrt(-7+ll-mm)*sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(16.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[9] = 0;
    if (abs(m-2)<=l)
      mc[10] = ((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-3+ll+pow(ll,2)-2*mm+pow(mm,2)))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[10] = 0;
    if (abs(m-4)<=l)
      mc[11] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[11] = 0;
    if (abs(m)<=l)
      mc[12] = ((18*pow(ll,3)+9*pow(ll,4)+6*ll*(-7+pow(mm,2))+pow(ll,2)*(-33+6*pow(mm,2))+9*(4-5*pow(mm,2)+pow(mm,4)))/(4.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[12] = 0;
    if (abs(m+2)<=l)
      mc[13] = ((-3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-3+ll+pow(ll,2)+2*mm+pow(mm,2)))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[13] = 0;
    if (abs(m+4)<=l)
      mc[14] = ((3*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[14] = 0;
    if (abs(m-2)<=l+2)
      mc[15] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*(-3+2*pow(ll,2)-mm+2*pow(mm,2)+2*ll*(2+mm)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[15] = 0;
    if (abs(m-4)<=l+2)
      mc[16] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[16] = 0;
    if (abs(m)<=l+2)
      mc[17] = ((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-2+3*ll+pow(ll,2)+pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[17] = 0;
    if (abs(m+2)<=l+2)
      mc[18] = ((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*(-3+2*pow(ll,2)-2*ll*(-2+mm)+mm+2*pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[18] = 0;
    if (abs(m+4)<=l+2)
      mc[19] = (-(sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[19] = 0;
    if (abs(m-2)<=l+4)
      mc[20] = (-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3)))))+(0)*I;
    else
      mc[20] = 0;
    if (abs(m-4)<=l+4)
      mc[21] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(8+ll-mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[21] = 0;
    if (abs(m)<=l+4)
      mc[22] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[22] = 0;
    if (abs(m+2)<=l+4)
      mc[23] = (-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3)))))+(0)*I;
    else
      mc[23] = 0;
    if (abs(m+4)<=l+4)
      mc[24] = ((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm)*sqrt(8+ll+mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[24] = 0;
    if (abs(m-2)<=l-2)
      mc[25] = (0)+((sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(5-2*pow(ll,2)+3*mm+2*ll*mm-2*pow(mm,2)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[25] = 0;
    if (abs(m-4)<=l-2)
      mc[26] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-3+2*ll)*sqrt(1+2*ll)*(60-104*ll-48*pow(ll,2)+32*pow(ll,3))))*I;
    else
      mc[26] = 0;
    if (abs(m+2)<=l-2)
      mc[27] = (0)+((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*(-5+2*pow(ll,2)+3*mm+2*ll*mm+2*pow(mm,2)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[27] = 0;
    if (abs(m+4)<=l-2)
      mc[28] = (0)+(-(sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(4.*sqrt(-3+2*ll)*sqrt(1+2*ll)*(15-26*ll-12*pow(ll,2)+8*pow(ll,3))))*I;
    else
      mc[28] = 0;
    if (abs(m-2)<=l-4)
      mc[29] = (0)+((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[29] = 0;
    if (abs(m-4)<=l-4)
      mc[30] = (0)+((sqrt(-7+ll+mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(240-736*ll+576*pow(ll,2)-128*pow(ll,3))))*I;
    else
      mc[30] = 0;
    if (abs(m+2)<=l-4)
      mc[31] = (0)+((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))*I;
    else
      mc[31] = 0;
    if (abs(m+4)<=l-4)
      mc[32] = (0)+((sqrt(-7+ll-mm)*sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(16.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[32] = 0;
    if (abs(m-2)<=l)
      mc[33] = (0)+((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-3+ll+pow(ll,2)-2*mm+pow(mm,2)))/(4.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[33] = 0;
    if (abs(m-4)<=l)
      mc[34] = (0)+((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[34] = 0;
    if (abs(m+2)<=l)
      mc[35] = (0)+((-3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-3+ll+pow(ll,2)+2*mm+pow(mm,2)))/(4.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[35] = 0;
    if (abs(m+4)<=l)
      mc[36] = (0)+((3*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[36] = 0;
    if (abs(m-2)<=l+2)
      mc[37] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*(3-2*pow(ll,2)+mm-2*pow(mm,2)-2*ll*(2+mm)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[37] = 0;
    if (abs(m-4)<=l+2)
      mc[38] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))*I;
    else
      mc[38] = 0;
    if (abs(m+2)<=l+2)
      mc[39] = (0)+((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*(-3+2*pow(ll,2)-2*ll*(-2+mm)+mm+2*pow(mm,2)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[39] = 0;
    if (abs(m+4)<=l+2)
      mc[40] = (0)+(-(sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))*I;
    else
      mc[40] = 0;
    if (abs(m-2)<=l+4)
      mc[41] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))*I;
    else
      mc[41] = 0;
    if (abs(m-4)<=l+4)
      mc[42] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(8+ll-mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[42] = 0;
    if (abs(m+2)<=l+4)
      mc[43] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[43] = 0;
    if (abs(m+4)<=l+4)
      mc[44] = (0)+((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm)*sqrt(8+ll+mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[44] = 0;
    if (abs(m-1)<=l-2)
      mc[45] = ((3*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(7+ll-2*pow(ll,2)+3*mm+2*ll*mm-4*pow(mm,2)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[45] = 0;
    if (abs(m-3)<=l-2)
      mc[46] = (((5+2*ll-4*mm)*sqrt(1+ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[46] = 0;
    if (abs(m+1)<=l-2)
      mc[47] = ((3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm)*(-7+2*pow(ll,2)+3*mm+4*pow(mm,2)+ll*(-1+2*mm)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[47] = 0;
    if (abs(m+3)<=l-2)
      mc[48] = (-(sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*(5+2*ll+4*mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[48] = 0;
    if (abs(m-1)<=l-4)
      mc[49] = ((3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[49] = 0;
    if (abs(m-3)<=l-4)
      mc[50] = ((sqrt(ll-mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))+(0)*I;
    else
      mc[50] = 0;
    if (abs(m+1)<=l-4)
      mc[51] = ((-3*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[51] = 0;
    if (abs(m+3)<=l-4)
      mc[52] = ((sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[52] = 0;
    if (abs(m-1)<=l)
      mc[53] = ((-3*sqrt(1+ll-mm)*sqrt(ll+mm)*(-1+2*mm)*(-6+ll+pow(ll,2)-3*mm+3*pow(mm,2)))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[53] = 0;
    if (abs(m-3)<=l)
      mc[54] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-3+2*mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[54] = 0;
    if (abs(m+1)<=l)
      mc[55] = ((-3*sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm)*(ll+pow(ll,2)+3*(-2+mm+pow(mm,2))))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[55] = 0;
    if (abs(m+3)<=l)
      mc[56] = ((3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(3+2*mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[56] = 0;
    if (abs(m-1)<=l+2)
      mc[57] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*(-4+2*pow(ll,2)-mm+4*pow(mm,2)+ll*(5+2*mm)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[57] = 0;
    if (abs(m-3)<=l+2)
      mc[58] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(ll+mm)*(-3+2*ll+4*mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[58] = 0;
    if (abs(m+1)<=l+2)
      mc[59] = ((-3*sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(-4+2*pow(ll,2)+ll*(5-2*mm)+mm+4*pow(mm,2)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[59] = 0;
    if (abs(m+3)<=l+2)
      mc[60] = (((-3+2*ll-4*mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[60] = 0;
    if (abs(m-1)<=l+4)
      mc[61] = ((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[61] = 0;
    if (abs(m-3)<=l+4)
      mc[62] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(1+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))+(0)*I;
    else
      mc[62] = 0;
    if (abs(m+1)<=l+4)
      mc[63] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[63] = 0;
    if (abs(m+3)<=l+4)
      mc[64] = (-(sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[64] = 0;
    if (abs(m-4)<=l-2)
      mc[65] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-3+2*ll)*sqrt(1+2*ll)*(60-104*ll-48*pow(ll,2)+32*pow(ll,3))))+(0)*I;
    else
      mc[65] = 0;
    if (abs(m)<=l-2)
      mc[66] = (-(sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-4-ll+pow(ll,2)+pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[66] = 0;
    if (abs(m+4)<=l-2)
      mc[67] = ((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(-3+2*ll)*sqrt(1+2*ll)*(60-104*ll-48*pow(ll,2)+32*pow(ll,3))))+(0)*I;
    else
      mc[67] = 0;
    if (abs(m-4)<=l-4)
      mc[68] = ((sqrt(-7+ll+mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(240-736*ll+576*pow(ll,2)-128*pow(ll,3))))+(0)*I;
    else
      mc[68] = 0;
    if (abs(m)<=l-4)
      mc[69] = ((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[69] = 0;
    if (abs(m+4)<=l-4)
      mc[70] = ((sqrt(-7+ll-mm)*sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(240-736*ll+576*pow(ll,2)-128*pow(ll,3))))+(0)*I;
    else
      mc[70] = 0;
    if (abs(m-4)<=l)
      mc[71] = ((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[71] = 0;
    if (abs(m)<=l)
      mc[72] = ((6*pow(ll,3)+3*pow(ll,4)+2*ll*(-7+pow(mm,2))+pow(ll,2)*(-11+2*pow(mm,2))+3*(4-5*pow(mm,2)+pow(mm,4)))/(4.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[72] = 0;
    if (abs(m+4)<=l)
      mc[73] = ((-3*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[73] = 0;
    if (abs(m-4)<=l+2)
      mc[74] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[74] = 0;
    if (abs(m)<=l+2)
      mc[75] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-2+3*ll+pow(ll,2)+pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[75] = 0;
    if (abs(m+4)<=l+2)
      mc[76] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[76] = 0;
    if (abs(m-4)<=l+4)
      mc[77] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(8+ll-mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[77] = 0;
    if (abs(m)<=l+4)
      mc[78] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))+(0)*I;
    else
      mc[78] = 0;
    if (abs(m+4)<=l+4)
      mc[79] = (-(sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm)*sqrt(8+ll+mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[79] = 0;
    if (abs(m-1)<=l-2)
      mc[80] = (0)+((sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-7+2*pow(ll,2)-3*mm+4*pow(mm,2)-ll*(1+2*mm)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[80] = 0;
    if (abs(m-3)<=l-2)
      mc[81] = (0)+(-((5+2*ll-4*mm)*sqrt(1+ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[81] = 0;
    if (abs(m+1)<=l-2)
      mc[82] = (0)+((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm)*(-7+2*pow(ll,2)+3*mm+4*pow(mm,2)+ll*(-1+2*mm)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[82] = 0;
    if (abs(m+3)<=l-2)
      mc[83] = (0)+(-(sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*(5+2*ll+4*mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[83] = 0;
    if (abs(m-1)<=l-4)
      mc[84] = (0)+((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))*I;
    else
      mc[84] = 0;
    if (abs(m-3)<=l-4)
      mc[85] = (0)+((sqrt(ll-mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[85] = 0;
    if (abs(m+1)<=l-4)
      mc[86] = (0)+((sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))*I;
    else
      mc[86] = 0;
    if (abs(m+3)<=l-4)
      mc[87] = (0)+((sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[87] = 0;
    if (abs(m-1)<=l)
      mc[88] = (0)+((sqrt(1+ll-mm)*sqrt(ll+mm)*(-1+2*mm)*(-6+ll+pow(ll,2)-3*mm+3*pow(mm,2)))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[88] = 0;
    if (abs(m-3)<=l)
      mc[89] = (0)+((3*(3-2*mm)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[89] = 0;
    if (abs(m+1)<=l)
      mc[90] = (0)+(-(sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm)*(ll+pow(ll,2)+3*(-2+mm+pow(mm,2))))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[90] = 0;
    if (abs(m+3)<=l)
      mc[91] = (0)+((3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(3+2*mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[91] = 0;
    if (abs(m-1)<=l+2)
      mc[92] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*(4-2*pow(ll,2)+mm-4*pow(mm,2)-ll*(5+2*mm)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[92] = 0;
    if (abs(m-3)<=l+2)
      mc[93] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(ll+mm)*(-3+2*ll+4*mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[93] = 0;
    if (abs(m+1)<=l+2)
      mc[94] = (0)+(-(sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(-4+2*pow(ll,2)+ll*(5-2*mm)+mm+4*pow(mm,2)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[94] = 0;
    if (abs(m+3)<=l+2)
      mc[95] = (0)+(((-3+2*ll-4*mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[95] = 0;
    if (abs(m-1)<=l+4)
      mc[96] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))*I;
    else
      mc[96] = 0;
    if (abs(m-3)<=l+4)
      mc[97] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(1+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[97] = 0;
    if (abs(m+1)<=l+4)
      mc[98] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))*I;
    else
      mc[98] = 0;
    if (abs(m+3)<=l+4)
      mc[99] = (0)+(-(sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[99] = 0;
    if (abs(m-2)<=l-2)
      mc[100] = ((sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-5+4*ll*(-1+mm)+6*mm-4*pow(mm,2)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[100] = 0;
    if (abs(m)<=l-2)
      mc[101] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-1+4*pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[101] = 0;
    if (abs(m+2)<=l-2)
      mc[102] = (-(sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*(5+6*mm+4*pow(mm,2)+4*ll*(1+mm)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[102] = 0;
    if (abs(m-2)<=l-4)
      mc[103] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[103] = 0;
    if (abs(m)<=l-4)
      mc[104] = ((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(30-92*ll+72*pow(ll,2)-16*pow(ll,3))))+(0)*I;
    else
      mc[104] = 0;
    if (abs(m+2)<=l-4)
      mc[105] = ((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[105] = 0;
    if (abs(m-2)<=l)
      mc[106] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-6+ll+pow(ll,2)+6*mm-3*pow(mm,2)))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[106] = 0;
    if (abs(m)<=l)
      mc[107] = ((3+2*pow(ll,3)+pow(ll,4)-3*pow(mm,4)+2*pow(ll,2)*(-2+pow(mm,2))+ll*(-5+2*pow(mm,2)))/(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4)))+(0)*I;
    else
      mc[107] = 0;
    if (abs(m+2)<=l)
      mc[108] = (-(sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(ll+pow(ll,2)-3*(2+2*mm+pow(mm,2))))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[108] = 0;
    if (abs(m-2)<=l+2)
      mc[109] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*(1+4*ll*(-1+mm)-2*mm+4*pow(mm,2)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[109] = 0;
    if (abs(m)<=l+2)
      mc[110] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-1+4*pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[110] = 0;
    if (abs(m+2)<=l+2)
      mc[111] = ((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*(-1-2*mm-4*pow(mm,2)+4*ll*(1+mm)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[111] = 0;
    if (abs(m-2)<=l+4)
      mc[112] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3))))+(0)*I;
    else
      mc[112] = 0;
    if (abs(m)<=l+4)
      mc[113] = (-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(210+284*ll+120*pow(ll,2)+16*pow(ll,3)))))+(0)*I;
    else
      mc[113] = 0;
    if (abs(m+2)<=l+4)
      mc[114] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3))))+(0)*I;
    else
      mc[114] = 0;
    if (abs(m-2)<=l-2)
      mc[115] = (0)+((sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(5-2*pow(ll,2)+3*mm+2*ll*mm-2*pow(mm,2)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[115] = 0;
    if (abs(m-4)<=l-2)
      mc[116] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*sqrt(1+2*ll)*(15-26*ll-12*pow(ll,2)+8*pow(ll,3))))*I;
    else
      mc[116] = 0;
    if (abs(m+2)<=l-2)
      mc[117] = (0)+((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*(-5+2*pow(ll,2)+3*mm+2*ll*mm+2*pow(mm,2)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[117] = 0;
    if (abs(m+4)<=l-2)
      mc[118] = (0)+((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(-3+2*ll)*sqrt(1+2*ll)*(60-104*ll-48*pow(ll,2)+32*pow(ll,3))))*I;
    else
      mc[118] = 0;
    if (abs(m-2)<=l-4)
      mc[119] = (0)+((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[119] = 0;
    if (abs(m-4)<=l-4)
      mc[120] = (0)+((sqrt(-7+ll+mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(16.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[120] = 0;
    if (abs(m+2)<=l-4)
      mc[121] = (0)+((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))*I;
    else
      mc[121] = 0;
    if (abs(m+4)<=l-4)
      mc[122] = (0)+((sqrt(-7+ll-mm)*sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(240-736*ll+576*pow(ll,2)-128*pow(ll,3))))*I;
    else
      mc[122] = 0;
    if (abs(m-2)<=l)
      mc[123] = (0)+((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-3+ll+pow(ll,2)-2*mm+pow(mm,2)))/(4.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[123] = 0;
    if (abs(m-4)<=l)
      mc[124] = (0)+((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[124] = 0;
    if (abs(m+2)<=l)
      mc[125] = (0)+((-3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-3+ll+pow(ll,2)+2*mm+pow(mm,2)))/(4.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[125] = 0;
    if (abs(m+4)<=l)
      mc[126] = (0)+((-3*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[126] = 0;
    if (abs(m-2)<=l+2)
      mc[127] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*(3-2*pow(ll,2)+mm-2*pow(mm,2)-2*ll*(2+mm)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[127] = 0;
    if (abs(m-4)<=l+2)
      mc[128] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))*I;
    else
      mc[128] = 0;
    if (abs(m+2)<=l+2)
      mc[129] = (0)+((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*(-3+2*pow(ll,2)-2*ll*(-2+mm)+mm+2*pow(mm,2)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[129] = 0;
    if (abs(m+4)<=l+2)
      mc[130] = (0)+((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))*I;
    else
      mc[130] = 0;
    if (abs(m-2)<=l+4)
      mc[131] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))*I;
    else
      mc[131] = 0;
    if (abs(m-4)<=l+4)
      mc[132] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(8+ll-mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[132] = 0;
    if (abs(m+2)<=l+4)
      mc[133] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[133] = 0;
    if (abs(m+4)<=l+4)
      mc[134] = (0)+(-(sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm)*sqrt(8+ll+mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[134] = 0;
    if (abs(m-1)<=l-2)
      mc[135] = ((sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(7+ll-2*pow(ll,2)+3*mm+2*ll*mm-4*pow(mm,2)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[135] = 0;
    if (abs(m-3)<=l-2)
      mc[136] = (-((5+2*ll-4*mm)*sqrt(1+ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[136] = 0;
    if (abs(m+1)<=l-2)
      mc[137] = ((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm)*(-7+2*pow(ll,2)+3*mm+4*pow(mm,2)+ll*(-1+2*mm)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[137] = 0;
    if (abs(m+3)<=l-2)
      mc[138] = ((sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*(5+2*ll+4*mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[138] = 0;
    if (abs(m-1)<=l-4)
      mc[139] = ((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[139] = 0;
    if (abs(m-3)<=l-4)
      mc[140] = ((sqrt(ll-mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[140] = 0;
    if (abs(m+1)<=l-4)
      mc[141] = ((sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))+(0)*I;
    else
      mc[141] = 0;
    if (abs(m+3)<=l-4)
      mc[142] = ((sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))+(0)*I;
    else
      mc[142] = 0;
    if (abs(m-1)<=l)
      mc[143] = (-(sqrt(1+ll-mm)*sqrt(ll+mm)*(-1+2*mm)*(-6+ll+pow(ll,2)-3*mm+3*pow(mm,2)))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[143] = 0;
    if (abs(m-3)<=l)
      mc[144] = ((3*(3-2*mm)*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[144] = 0;
    if (abs(m+1)<=l)
      mc[145] = (-(sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm)*(ll+pow(ll,2)+3*(-2+mm+pow(mm,2))))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[145] = 0;
    if (abs(m+3)<=l)
      mc[146] = ((-3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(3+2*mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[146] = 0;
    if (abs(m-1)<=l+2)
      mc[147] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*(-4+2*pow(ll,2)-mm+4*pow(mm,2)+ll*(5+2*mm)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[147] = 0;
    if (abs(m-3)<=l+2)
      mc[148] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(ll+mm)*(-3+2*ll+4*mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[148] = 0;
    if (abs(m+1)<=l+2)
      mc[149] = (-(sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(-4+2*pow(ll,2)+ll*(5-2*mm)+mm+4*pow(mm,2)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[149] = 0;
    if (abs(m+3)<=l+2)
      mc[150] = ((sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*(3-2*ll+4*mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[150] = 0;
    if (abs(m-1)<=l+4)
      mc[151] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[151] = 0;
    if (abs(m-3)<=l+4)
      mc[152] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(1+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[152] = 0;
    if (abs(m+1)<=l+4)
      mc[153] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))+(0)*I;
    else
      mc[153] = 0;
    if (abs(m+3)<=l+4)
      mc[154] = ((sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))+(0)*I;
    else
      mc[154] = 0;
    if (abs(m-2)<=l-2)
      mc[155] = (0)+((sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(5-4*ll*(-1+mm)-6*mm+4*pow(mm,2)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[155] = 0;
    if (abs(m+2)<=l-2)
      mc[156] = (0)+(-(sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*(5+6*mm+4*pow(mm,2)+4*ll*(1+mm)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[156] = 0;
    if (abs(m-2)<=l-4)
      mc[157] = (0)+((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*sqrt(1+2*ll)*(15-46*ll+36*pow(ll,2)-8*pow(ll,3))))*I;
    else
      mc[157] = 0;
    if (abs(m+2)<=l-4)
      mc[158] = (0)+((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[158] = 0;
    if (abs(m-2)<=l)
      mc[159] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-6+ll+pow(ll,2)+6*mm-3*pow(mm,2)))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[159] = 0;
    if (abs(m+2)<=l)
      mc[160] = (0)+(-(sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(ll+pow(ll,2)-3*(2+2*mm+pow(mm,2))))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[160] = 0;
    if (abs(m-2)<=l+2)
      mc[161] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*(1+4*ll*(-1+mm)-2*mm+4*pow(mm,2)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[161] = 0;
    if (abs(m+2)<=l+2)
      mc[162] = (0)+((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*(-1-2*mm-4*pow(mm,2)+4*ll*(1+mm)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[162] = 0;
    if (abs(m-2)<=l+4)
      mc[163] = (0)+(-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3)))))*I;
    else
      mc[163] = 0;
    if (abs(m+2)<=l+4)
      mc[164] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3))))*I;
    else
      mc[164] = 0;
    if (abs(m-1)<=l-2)
      mc[165] = ((sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(8-2*pow(ll,2)+ll*(3-2*mm)-3*mm+4*pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[165] = 0;
    if (abs(m+1)<=l-2)
      mc[166] = ((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm)*(-8+2*pow(ll,2)-3*mm-4*pow(mm,2)-ll*(3+2*mm)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[166] = 0;
    if (abs(m-1)<=l-4)
      mc[167] = ((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(30-92*ll+72*pow(ll,2)-16*pow(ll,3))))+(0)*I;
    else
      mc[167] = 0;
    if (abs(m+1)<=l-4)
      mc[168] = (-((sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(30-92*ll+72*pow(ll,2)-16*pow(ll,3)))))+(0)*I;
    else
      mc[168] = 0;
    if (abs(m-1)<=l)
      mc[169] = ((-3*sqrt(1+ll-mm)*sqrt(ll+mm)*(-1+2*mm)*(-3+ll+pow(ll,2)+mm-pow(mm,2)))/(2.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[169] = 0;
    if (abs(m+1)<=l)
      mc[170] = ((-3*sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm)*(-3+ll+pow(ll,2)-mm-pow(mm,2)))/(2.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[170] = 0;
    if (abs(m-1)<=l+2)
      mc[171] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*(-3+2*pow(ll,2)+ll*(7-2*mm)+mm-4*pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[171] = 0;
    if (abs(m+1)<=l+2)
      mc[172] = ((sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(3-2*pow(ll,2)+mm+4*pow(mm,2)-ll*(7+2*mm)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[172] = 0;
    if (abs(m-1)<=l+4)
      mc[173] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(210+284*ll+120*pow(ll,2)+16*pow(ll,3))))+(0)*I;
    else
      mc[173] = 0;
    if (abs(m+1)<=l+4)
      mc[174] = (-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(210+284*ll+120*pow(ll,2)+16*pow(ll,3)))))+(0)*I;
    else
      mc[174] = 0;
    if (abs(m-2)<=l-2)
      mc[175] = ((sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(5-2*pow(ll,2)+3*mm+2*ll*mm-2*pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[175] = 0;
    if (abs(m-4)<=l-2)
      mc[176] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*sqrt(1+2*ll)*(15-26*ll-12*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[176] = 0;
    if (abs(m)<=l-2)
      mc[177] = ((-3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-4-ll+pow(ll,2)+pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[177] = 0;
    if (abs(m+2)<=l-2)
      mc[178] = (-(sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*(-5+2*pow(ll,2)+3*mm+2*ll*mm+2*pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[178] = 0;
    if (abs(m+4)<=l-2)
      mc[179] = (-(sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(4.*sqrt(-3+2*ll)*sqrt(1+2*ll)*(15-26*ll-12*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[179] = 0;
    if (abs(m-2)<=l-4)
      mc[180] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[180] = 0;
    if (abs(m-4)<=l-4)
      mc[181] = ((sqrt(-7+ll+mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(16.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[181] = 0;
    if (abs(m)<=l-4)
      mc[182] = ((3*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[182] = 0;
    if (abs(m+2)<=l-4)
      mc[183] = ((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[183] = 0;
    if (abs(m+4)<=l-4)
      mc[184] = ((sqrt(-7+ll-mm)*sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(16.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[184] = 0;
    if (abs(m-2)<=l)
      mc[185] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-3+ll+pow(ll,2)-2*mm+pow(mm,2)))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[185] = 0;
    if (abs(m-4)<=l)
      mc[186] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[186] = 0;
    if (abs(m)<=l)
      mc[187] = ((18*pow(ll,3)+9*pow(ll,4)+6*ll*(-7+pow(mm,2))+pow(ll,2)*(-33+6*pow(mm,2))+9*(4-5*pow(mm,2)+pow(mm,4)))/(4.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[187] = 0;
    if (abs(m+2)<=l)
      mc[188] = ((3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-3+ll+pow(ll,2)+2*mm+pow(mm,2)))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[188] = 0;
    if (abs(m+4)<=l)
      mc[189] = ((3*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(8.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[189] = 0;
    if (abs(m-2)<=l+2)
      mc[190] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*(3-2*pow(ll,2)+mm-2*pow(mm,2)-2*ll*(2+mm)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[190] = 0;
    if (abs(m-4)<=l+2)
      mc[191] = (-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[191] = 0;
    if (abs(m)<=l+2)
      mc[192] = ((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-2+3*ll+pow(ll,2)+pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[192] = 0;
    if (abs(m+2)<=l+2)
      mc[193] = (-(sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*(-3+2*pow(ll,2)-2*ll*(-2+mm)+mm+2*pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[193] = 0;
    if (abs(m+4)<=l+2)
      mc[194] = (-(sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(4.*sqrt(1+2*ll)*sqrt(5+2*ll)*(-21+22*ll+36*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[194] = 0;
    if (abs(m-2)<=l+4)
      mc[195] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3))))+(0)*I;
    else
      mc[195] = 0;
    if (abs(m-4)<=l+4)
      mc[196] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(8+ll-mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[196] = 0;
    if (abs(m)<=l+4)
      mc[197] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[197] = 0;
    if (abs(m+2)<=l+4)
      mc[198] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3))))+(0)*I;
    else
      mc[198] = 0;
    if (abs(m+4)<=l+4)
      mc[199] = ((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm)*sqrt(8+ll+mm))/(16.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[199] = 0;
    if (abs(m-1)<=l-2)
      mc[200] = (0)+((3*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-7+2*pow(ll,2)-3*mm+4*pow(mm,2)-ll*(1+2*mm)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[200] = 0;
    if (abs(m-3)<=l-2)
      mc[201] = (0)+(((5+2*ll-4*mm)*sqrt(1+ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[201] = 0;
    if (abs(m+1)<=l-2)
      mc[202] = (0)+((3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm)*(-7+2*pow(ll,2)+3*mm+4*pow(mm,2)+ll*(-1+2*mm)))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[202] = 0;
    if (abs(m+3)<=l-2)
      mc[203] = (0)+((sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*(5+2*ll+4*mm))/(8.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[203] = 0;
    if (abs(m-1)<=l-4)
      mc[204] = (0)+((-3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[204] = 0;
    if (abs(m-3)<=l-4)
      mc[205] = (0)+((sqrt(ll-mm)*sqrt(-6+ll+mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))*I;
    else
      mc[205] = 0;
    if (abs(m+1)<=l-4)
      mc[206] = (0)+((-3*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))*I;
    else
      mc[206] = 0;
    if (abs(m+3)<=l-4)
      mc[207] = (0)+((sqrt(-6+ll-mm)*sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(120-368*ll+288*pow(ll,2)-64*pow(ll,3))))*I;
    else
      mc[207] = 0;
    if (abs(m-1)<=l)
      mc[208] = (0)+((3*sqrt(1+ll-mm)*sqrt(ll+mm)*(-1+2*mm)*(-6+ll+pow(ll,2)-3*mm+3*pow(mm,2)))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[208] = 0;
    if (abs(m-3)<=l)
      mc[209] = (0)+((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-3+2*mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[209] = 0;
    if (abs(m+1)<=l)
      mc[210] = (0)+((-3*sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm)*(ll+pow(ll,2)+3*(-2+mm+pow(mm,2))))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[210] = 0;
    if (abs(m+3)<=l)
      mc[211] = (0)+((-3*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(3+2*mm))/(8.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))*I;
    else
      mc[211] = 0;
    if (abs(m-1)<=l+2)
      mc[212] = (0)+((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*(-4+2*pow(ll,2)-mm+4*pow(mm,2)+ll*(5+2*mm)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[212] = 0;
    if (abs(m-3)<=l+2)
      mc[213] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(ll+mm)*(-3+2*ll+4*mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[213] = 0;
    if (abs(m+1)<=l+2)
      mc[214] = (0)+((-3*sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(-4+2*pow(ll,2)+ll*(5-2*mm)+mm+4*pow(mm,2)))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[214] = 0;
    if (abs(m+3)<=l+2)
      mc[215] = (0)+((sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*(3-2*ll+4*mm))/(8.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[215] = 0;
    if (abs(m-1)<=l+4)
      mc[216] = (0)+((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[216] = 0;
    if (abs(m-3)<=l+4)
      mc[217] = (0)+((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(7+ll-mm)*sqrt(1+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))*I;
    else
      mc[217] = 0;
    if (abs(m+1)<=l+4)
      mc[218] = (0)+((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(8.*sqrt(1+2*ll)*(7+2*ll)*sqrt(9+2*ll)*(15+16*ll+4*pow(ll,2))))*I;
    else
      mc[218] = 0;
    if (abs(m+3)<=l+4)
      mc[219] = (0)+((sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm)*sqrt(7+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(840+1136*ll+480*pow(ll,2)+64*pow(ll,3))))*I;
    else
      mc[219] = 0;
    if (abs(m-2)<=l-2)
      mc[220] = ((sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(5-4*ll*(-1+mm)-6*mm+4*pow(mm,2)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[220] = 0;
    if (abs(m)<=l-2)
      mc[221] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-1+4*pow(mm,2)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[221] = 0;
    if (abs(m+2)<=l-2)
      mc[222] = ((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*(5+6*mm+4*pow(mm,2)+4*ll*(1+mm)))/(4.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[222] = 0;
    if (abs(m-2)<=l-4)
      mc[223] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-5+ll+mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*sqrt(1+2*ll)*(15-46*ll+36*pow(ll,2)-8*pow(ll,3))))+(0)*I;
    else
      mc[223] = 0;
    if (abs(m)<=l-4)
      mc[224] = ((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(30-92*ll+72*pow(ll,2)-16*pow(ll,3))))+(0)*I;
    else
      mc[224] = 0;
    if (abs(m+2)<=l-4)
      mc[225] = ((sqrt(-5+ll-mm)*sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-7+2*ll)*sqrt(1+2*ll)*(15-46*ll+36*pow(ll,2)-8*pow(ll,3))))+(0)*I;
    else
      mc[225] = 0;
    if (abs(m-2)<=l)
      mc[226] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-6+ll+pow(ll,2)+6*mm-3*pow(mm,2)))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[226] = 0;
    if (abs(m)<=l)
      mc[227] = ((3+2*pow(ll,3)+pow(ll,4)-3*pow(mm,4)+2*pow(ll,2)*(-2+pow(mm,2))+ll*(-5+2*pow(mm,2)))/(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4)))+(0)*I;
    else
      mc[227] = 0;
    if (abs(m+2)<=l)
      mc[228] = ((sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(ll+pow(ll,2)-3*(2+2*mm+pow(mm,2))))/(2.*(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4))))+(0)*I;
    else
      mc[228] = 0;
    if (abs(m-2)<=l+2)
      mc[229] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*(1+4*ll*(-1+mm)-2*mm+4*pow(mm,2)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[229] = 0;
    if (abs(m)<=l+2)
      mc[230] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-1+4*pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[230] = 0;
    if (abs(m+2)<=l+2)
      mc[231] = ((sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*(1+2*mm+4*pow(mm,2)-4*ll*(1+mm)))/(4.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[231] = 0;
    if (abs(m-2)<=l+4)
      mc[232] = (-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(6+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3)))))+(0)*I;
    else
      mc[232] = 0;
    if (abs(m)<=l+4)
      mc[233] = (-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(210+284*ll+120*pow(ll,2)+16*pow(ll,3)))))+(0)*I;
    else
      mc[233] = 0;
    if (abs(m+2)<=l+4)
      mc[234] = (-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm)*sqrt(6+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(420+568*ll+240*pow(ll,2)+32*pow(ll,3)))))+(0)*I;
    else
      mc[234] = 0;
    if (abs(m-1)<=l-2)
      mc[235] = (0)+((sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-8+2*pow(ll,2)+3*mm-4*pow(mm,2)+ll*(-3+2*mm)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[235] = 0;
    if (abs(m+1)<=l-2)
      mc[236] = (0)+((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm)*(-8+2*pow(ll,2)-3*mm-4*pow(mm,2)-ll*(3+2*mm)))/(2.*(-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))*I;
    else
      mc[236] = 0;
    if (abs(m-1)<=l-4)
      mc[237] = (0)+(-((sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-4+ll+mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(30-92*ll+72*pow(ll,2)-16*pow(ll,3)))))*I;
    else
      mc[237] = 0;
    if (abs(m+1)<=l-4)
      mc[238] = (0)+(-((sqrt(-4+ll-mm)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*sqrt(1+2*ll)*(30-92*ll+72*pow(ll,2)-16*pow(ll,3)))))*I;
    else
      mc[238] = 0;
    if (abs(m-1)<=l)
      mc[239] = (0)+((3*sqrt(1+ll-mm)*sqrt(ll+mm)*(-1+2*mm)*(-3+ll+pow(ll,2)+mm-pow(mm,2)))/(2.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[239] = 0;
    if (abs(m+1)<=l)
      mc[240] = (0)+((-3*sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm)*(-3+ll+pow(ll,2)-mm-pow(mm,2)))/(2.*(-15+4*ll+4*pow(ll,2))*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[240] = 0;
    if (abs(m-1)<=l+2)
      mc[241] = (0)+(-(sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*(-3+2*pow(ll,2)+ll*(7-2*mm)+mm-4*pow(mm,2)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[241] = 0;
    if (abs(m+1)<=l+2)
      mc[242] = (0)+((sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*(3-2*pow(ll,2)+mm+4*pow(mm,2)-ll*(7+2*mm)))/(2.*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))*I;
    else
      mc[242] = 0;
    if (abs(m-1)<=l+4)
      mc[243] = (0)+(-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(5+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(210+284*ll+120*pow(ll,2)+16*pow(ll,3)))))*I;
    else
      mc[243] = 0;
    if (abs(m+1)<=l+4)
      mc[244] = (0)+(-((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm)*sqrt(5+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(210+284*ll+120*pow(ll,2)+16*pow(ll,3)))))*I;
    else
      mc[244] = 0;
    if (abs(m)<=l-2)
      mc[245] = ((2*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm)*(-7-2*ll+2*pow(ll,2)-2*pow(mm,2)))/((-5+2*ll)*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)))+(0)*I;
    else
      mc[245] = 0;
    if (abs(m)<=l-4)
      mc[246] = ((sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(sqrt(-7+2*ll)*(-5+2*ll)*sqrt(1+2*ll)*(3-8*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[246] = 0;
    if (abs(m)<=l)
      mc[247] = ((3*(3+4*pow(ll,3)+2*pow(ll,4)+10*pow(mm,2)+2*pow(mm,4)-4*ll*(2+pow(mm,2))-2*pow(ll,2)*(3+2*pow(mm,2))))/(45-72*ll-56*pow(ll,2)+32*pow(ll,3)+16*pow(ll,4)))+(0)*I;
    else
      mc[247] = 0;
    if (abs(m)<=l+2)
      mc[248] = ((2*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*(-3+6*ll+2*pow(ll,2)-2*pow(mm,2)))/((-1+2*ll)*sqrt(1+2*ll)*(3+2*ll)*sqrt(5+2*ll)*(7+2*ll)))+(0)*I;
    else
      mc[248] = 0;
    if (abs(m)<=l+4)
      mc[249] = ((sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(sqrt(1+2*ll)*sqrt(9+2*ll)*(105+142*ll+60*pow(ll,2)+8*pow(ll,3))))+(0)*I;
    else
      mc[249] = 0;
  }
}

static void initialize_mc_1() {
  int l,m;
  double ll,mm;
  COMPLEX *mc;

  first_mc_1 = 0;
  allocate_many(&mult_constant_1,mc_count_1);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant_1 + mc_count_1*ind(l,m);
    if (abs(m-2)<=l-2)
      mc[0] = (((1+ll)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[0] = 0;
    if (abs(m)<=l-2)
      mc[1] = (-((1+ll)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[1] = 0;
    if (abs(m+2)<=l-2)
      mc[2] = (((1+ll)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(8.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[2] = 0;
    if (abs(m-2)<=l)
      mc[3] = ((-3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[3] = 0;
    if (abs(m)<=l)
      mc[4] = ((ll+pow(ll,2)-3*pow(mm,2))/(12-16*ll-16*pow(ll,2)))+(0)*I;
    else
      mc[4] = 0;
    if (abs(m+2)<=l)
      mc[5] = ((-3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(8.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[5] = 0;
    if (abs(m-2)<=l+2)
      mc[6] = (-((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(24+16*ll))))+(0)*I;
    else
      mc[6] = 0;
    if (abs(m)<=l+2)
      mc[7] = ((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(12+8*ll)))+(0)*I;
    else
      mc[7] = 0;
    if (abs(m+2)<=l+2)
      mc[8] = (-((ll*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(24+16*ll))))+(0)*I;
    else
      mc[8] = 0;
    if (abs(m-2)<=l-2)
      mc[9] = (0)+(-((1+ll)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[9] = 0;
    if (abs(m+2)<=l-2)
      mc[10] = (0)+(((1+ll)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[10] = 0;
    if (abs(m-2)<=l)
      mc[11] = (0)+((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[11] = 0;
    if (abs(m+2)<=l)
      mc[12] = (0)+((-3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[12] = 0;
    if (abs(m-2)<=l+2)
      mc[13] = (0)+((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(12+8*ll)))*I;
    else
      mc[13] = 0;
    if (abs(m+2)<=l+2)
      mc[14] = (0)+(-((ll*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(12+8*ll))))*I;
    else
      mc[14] = 0;
    if (abs(m-1)<=l-2)
      mc[15] = (-((1+ll)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[15] = 0;
    if (abs(m+1)<=l-2)
      mc[16] = (((1+ll)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[16] = 0;
    if (abs(m-1)<=l)
      mc[17] = ((3*(1-2*mm)*sqrt(1+ll-mm)*sqrt(ll+mm))/(4.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[17] = 0;
    if (abs(m+1)<=l)
      mc[18] = ((-3*sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm))/(4.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[18] = 0;
    if (abs(m-1)<=l+2)
      mc[19] = (-((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(6+4*ll))))+(0)*I;
    else
      mc[19] = 0;
    if (abs(m+1)<=l+2)
      mc[20] = ((ll*sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(6+4*ll)))+(0)*I;
    else
      mc[20] = 0;
    if (abs(m-2)<=l-2)
      mc[21] = (-((1+ll)*sqrt(-3+ll+mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[21] = 0;
    if (abs(m)<=l-2)
      mc[22] = (-((1+ll)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(4.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[22] = 0;
    if (abs(m+2)<=l-2)
      mc[23] = (-((1+ll)*sqrt(-3+ll-mm)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm))/(8.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[23] = 0;
    if (abs(m-2)<=l)
      mc[24] = ((3*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(8.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[24] = 0;
    if (abs(m)<=l)
      mc[25] = ((ll+pow(ll,2)-3*pow(mm,2))/(12-16*ll-16*pow(ll,2)))+(0)*I;
    else
      mc[25] = 0;
    if (abs(m+2)<=l)
      mc[26] = ((3*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(8.*(-3+4*ll+4*pow(ll,2))))+(0)*I;
    else
      mc[26] = 0;
    if (abs(m-2)<=l+2)
      mc[27] = ((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(4+ll-mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(24+16*ll)))+(0)*I;
    else
      mc[27] = 0;
    if (abs(m)<=l+2)
      mc[28] = ((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(12+8*ll)))+(0)*I;
    else
      mc[28] = 0;
    if (abs(m+2)<=l+2)
      mc[29] = ((ll*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm)*sqrt(4+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(24+16*ll)))+(0)*I;
    else
      mc[29] = 0;
    if (abs(m-1)<=l-2)
      mc[30] = (0)+(((1+ll)*sqrt(ll-mm)*sqrt(-2+ll+mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[30] = 0;
    if (abs(m+1)<=l-2)
      mc[31] = (0)+(((1+ll)*sqrt(-2+ll-mm)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))*I;
    else
      mc[31] = 0;
    if (abs(m-1)<=l)
      mc[32] = (0)+((3*sqrt(1+ll-mm)*sqrt(ll+mm)*(-1+2*mm))/(4.*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[32] = 0;
    if (abs(m+1)<=l)
      mc[33] = (0)+((-3*sqrt(ll-mm)*sqrt(1+ll+mm)*(1+2*mm))/(4.*(-3+4*ll+4*pow(ll,2))))*I;
    else
      mc[33] = 0;
    if (abs(m-1)<=l+2)
      mc[34] = (0)+((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(3+ll-mm)*sqrt(1+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(6+4*ll)))*I;
    else
      mc[34] = 0;
    if (abs(m+1)<=l+2)
      mc[35] = (0)+((ll*sqrt(1+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm)*sqrt(3+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(6+4*ll)))*I;
    else
      mc[35] = 0;
    if (abs(m)<=l-2)
      mc[36] = (((1+ll)*sqrt(-1+ll-mm)*sqrt(ll-mm)*sqrt(-1+ll+mm)*sqrt(ll+mm))/(2.*sqrt(-3+2*ll)*(-1+2*ll)*sqrt(1+2*ll)))+(0)*I;
    else
      mc[36] = 0;
    if (abs(m)<=l)
      mc[37] = ((ll+pow(ll,2)-3*pow(mm,2))/(-6+8*ll+8*pow(ll,2)))+(0)*I;
    else
      mc[37] = 0;
    if (abs(m)<=l+2)
      mc[38] = (-((ll*sqrt(1+ll-mm)*sqrt(2+ll-mm)*sqrt(1+ll+mm)*sqrt(2+ll+mm))/(sqrt(1+2*ll)*sqrt(5+2*ll)*(6+4*ll))))+(0)*I;
    else
      mc[38] = 0;
    if (abs(m-1)<=l)
      mc[39] = (0)+(-(sqrt(1+ll-mm)*sqrt(ll+mm))/4.)*I;
    else
      mc[39] = 0;
    if (abs(m+1)<=l)
      mc[40] = (0)+(-(sqrt(ll-mm)*sqrt(1+ll+mm))/4.)*I;
    else
      mc[40] = 0;
    if (abs(m-1)<=l)
      mc[41] = (-(sqrt(1+ll-mm)*sqrt(ll+mm))/4.)+(0)*I;
    else
      mc[41] = 0;
    if (abs(m+1)<=l)
      mc[42] = ((sqrt(ll-mm)*sqrt(1+ll+mm))/4.)+(0)*I;
    else
      mc[42] = 0;
    if (abs(m)<=l)
      mc[43] = (0)+(-mm/2.)*I;
    else
      mc[43] = 0;
    if (abs(m)<=l)
      mc[44] = (-(ll*(1+ll)))+(0)*I;
    else
      mc[44] = 0;
  }
}

static void * thread_function_0(void *arg) {
  struct job_info_s* job_info = arg;
  while (1) {
    int lstart, lend;
    /* Wait until thread is told to start. */
    pthread_mutex_lock(&job_m);
    while (job_info->control != 1) {
      pthread_cond_wait(&job_c, &job_m);
    }
    lstart = job_info->lstart;
    lend = job_info->lend;
    pthread_mutex_unlock(&job_m);
    COMPLEX* psi;
  /* Copy data to thread. */
    memcpy(&(psi),&(thread_pass_args_0.psi),sizeof(psi));
    int l,m;
    COMPLEX *mc;
    for (l=lstart;l<lend;l+=2) for (m=0;m<=l;m++) {
      mc = mult_constant_0 + mc_count_0*ind(l,m);
      COMPLEX xxxx, xxxy, xxxz, xxyy, xxyz, xxzz, xyyy, xyyz, xyzz, xzzz, yyyy, yyyz, yyzz, yzzz, zzzz;
      xxxx = (mc[0]*index(psi,l-2,m-2)+mc[1]*index(psi,l-2,m-4)+mc[2]*index(psi,l-2,m)+mc[3]*index(psi,l-2,m+2)+mc[4]*index(psi,l-2,m+4)+mc[5]*index(psi,l-4,m-2)+mc[6]*index(psi,l-4,m-4)+mc[7]*index(psi,l-4,m)+mc[8]*index(psi,l-4,m+2)+mc[9]*index(psi,l-4,m+4)+mc[10]*index(psi,l,m-2)+mc[11]*index(psi,l,m-4)+mc[12]*index(psi,l,m)+mc[13]*index(psi,l,m+2)+mc[14]*index(psi,l,m+4)+mc[15]*index(psi,l+2,m-2)+mc[16]*index(psi,l+2,m-4)+mc[17]*index(psi,l+2,m)+mc[18]*index(psi,l+2,m+2)+mc[19]*index(psi,l+2,m+4)+mc[20]*index(psi,l+4,m-2)+mc[21]*index(psi,l+4,m-4)+mc[22]*index(psi,l+4,m)+mc[23]*index(psi,l+4,m+2)+mc[24]*index(psi,l+4,m+4));
      xxxy = (mc[25]*index(psi,l-2,m-2)+mc[26]*index(psi,l-2,m-4)+mc[27]*index(psi,l-2,m+2)+mc[28]*index(psi,l-2,m+4)+mc[29]*index(psi,l-4,m-2)+mc[30]*index(psi,l-4,m-4)+mc[31]*index(psi,l-4,m+2)+mc[32]*index(psi,l-4,m+4)+mc[33]*index(psi,l,m-2)+mc[34]*index(psi,l,m-4)+mc[35]*index(psi,l,m+2)+mc[36]*index(psi,l,m+4)+mc[37]*index(psi,l+2,m-2)+mc[38]*index(psi,l+2,m-4)+mc[39]*index(psi,l+2,m+2)+mc[40]*index(psi,l+2,m+4)+mc[41]*index(psi,l+4,m-2)+mc[42]*index(psi,l+4,m-4)+mc[43]*index(psi,l+4,m+2)+mc[44]*index(psi,l+4,m+4));
      xxxz = (mc[45]*index(psi,l-2,m-1)+mc[46]*index(psi,l-2,m-3)+mc[47]*index(psi,l-2,m+1)+mc[48]*index(psi,l-2,m+3)+mc[49]*index(psi,l-4,m-1)+mc[50]*index(psi,l-4,m-3)+mc[51]*index(psi,l-4,m+1)+mc[52]*index(psi,l-4,m+3)+mc[53]*index(psi,l,m-1)+mc[54]*index(psi,l,m-3)+mc[55]*index(psi,l,m+1)+mc[56]*index(psi,l,m+3)+mc[57]*index(psi,l+2,m-1)+mc[58]*index(psi,l+2,m-3)+mc[59]*index(psi,l+2,m+1)+mc[60]*index(psi,l+2,m+3)+mc[61]*index(psi,l+4,m-1)+mc[62]*index(psi,l+4,m-3)+mc[63]*index(psi,l+4,m+1)+mc[64]*index(psi,l+4,m+3));
      xxyy = (mc[65]*index(psi,l-2,m-4)+mc[66]*index(psi,l-2,m)+mc[67]*index(psi,l-2,m+4)+mc[68]*index(psi,l-4,m-4)+mc[69]*index(psi,l-4,m)+mc[70]*index(psi,l-4,m+4)+mc[71]*index(psi,l,m-4)+mc[72]*index(psi,l,m)+mc[73]*index(psi,l,m+4)+mc[74]*index(psi,l+2,m-4)+mc[75]*index(psi,l+2,m)+mc[76]*index(psi,l+2,m+4)+mc[77]*index(psi,l+4,m-4)+mc[78]*index(psi,l+4,m)+mc[79]*index(psi,l+4,m+4));
      xxyz = (mc[80]*index(psi,l-2,m-1)+mc[81]*index(psi,l-2,m-3)+mc[82]*index(psi,l-2,m+1)+mc[83]*index(psi,l-2,m+3)+mc[84]*index(psi,l-4,m-1)+mc[85]*index(psi,l-4,m-3)+mc[86]*index(psi,l-4,m+1)+mc[87]*index(psi,l-4,m+3)+mc[88]*index(psi,l,m-1)+mc[89]*index(psi,l,m-3)+mc[90]*index(psi,l,m+1)+mc[91]*index(psi,l,m+3)+mc[92]*index(psi,l+2,m-1)+mc[93]*index(psi,l+2,m-3)+mc[94]*index(psi,l+2,m+1)+mc[95]*index(psi,l+2,m+3)+mc[96]*index(psi,l+4,m-1)+mc[97]*index(psi,l+4,m-3)+mc[98]*index(psi,l+4,m+1)+mc[99]*index(psi,l+4,m+3));
      xxzz = (mc[100]*index(psi,l-2,m-2)+mc[101]*index(psi,l-2,m)+mc[102]*index(psi,l-2,m+2)+mc[103]*index(psi,l-4,m-2)+mc[104]*index(psi,l-4,m)+mc[105]*index(psi,l-4,m+2)+mc[106]*index(psi,l,m-2)+mc[107]*index(psi,l,m)+mc[108]*index(psi,l,m+2)+mc[109]*index(psi,l+2,m-2)+mc[110]*index(psi,l+2,m)+mc[111]*index(psi,l+2,m+2)+mc[112]*index(psi,l+4,m-2)+mc[113]*index(psi,l+4,m)+mc[114]*index(psi,l+4,m+2));
      xyyy = (mc[115]*index(psi,l-2,m-2)+mc[116]*index(psi,l-2,m-4)+mc[117]*index(psi,l-2,m+2)+mc[118]*index(psi,l-2,m+4)+mc[119]*index(psi,l-4,m-2)+mc[120]*index(psi,l-4,m-4)+mc[121]*index(psi,l-4,m+2)+mc[122]*index(psi,l-4,m+4)+mc[123]*index(psi,l,m-2)+mc[124]*index(psi,l,m-4)+mc[125]*index(psi,l,m+2)+mc[126]*index(psi,l,m+4)+mc[127]*index(psi,l+2,m-2)+mc[128]*index(psi,l+2,m-4)+mc[129]*index(psi,l+2,m+2)+mc[130]*index(psi,l+2,m+4)+mc[131]*index(psi,l+4,m-2)+mc[132]*index(psi,l+4,m-4)+mc[133]*index(psi,l+4,m+2)+mc[134]*index(psi,l+4,m+4));
      xyyz = (mc[135]*index(psi,l-2,m-1)+mc[136]*index(psi,l-2,m-3)+mc[137]*index(psi,l-2,m+1)+mc[138]*index(psi,l-2,m+3)+mc[139]*index(psi,l-4,m-1)+mc[140]*index(psi,l-4,m-3)+mc[141]*index(psi,l-4,m+1)+mc[142]*index(psi,l-4,m+3)+mc[143]*index(psi,l,m-1)+mc[144]*index(psi,l,m-3)+mc[145]*index(psi,l,m+1)+mc[146]*index(psi,l,m+3)+mc[147]*index(psi,l+2,m-1)+mc[148]*index(psi,l+2,m-3)+mc[149]*index(psi,l+2,m+1)+mc[150]*index(psi,l+2,m+3)+mc[151]*index(psi,l+4,m-1)+mc[152]*index(psi,l+4,m-3)+mc[153]*index(psi,l+4,m+1)+mc[154]*index(psi,l+4,m+3));
      xyzz = (mc[155]*index(psi,l-2,m-2)+mc[156]*index(psi,l-2,m+2)+mc[157]*index(psi,l-4,m-2)+mc[158]*index(psi,l-4,m+2)+mc[159]*index(psi,l,m-2)+mc[160]*index(psi,l,m+2)+mc[161]*index(psi,l+2,m-2)+mc[162]*index(psi,l+2,m+2)+mc[163]*index(psi,l+4,m-2)+mc[164]*index(psi,l+4,m+2));
      xzzz = (mc[165]*index(psi,l-2,m-1)+mc[166]*index(psi,l-2,m+1)+mc[167]*index(psi,l-4,m-1)+mc[168]*index(psi,l-4,m+1)+mc[169]*index(psi,l,m-1)+mc[170]*index(psi,l,m+1)+mc[171]*index(psi,l+2,m-1)+mc[172]*index(psi,l+2,m+1)+mc[173]*index(psi,l+4,m-1)+mc[174]*index(psi,l+4,m+1));
      yyyy = (mc[175]*index(psi,l-2,m-2)+mc[176]*index(psi,l-2,m-4)+mc[177]*index(psi,l-2,m)+mc[178]*index(psi,l-2,m+2)+mc[179]*index(psi,l-2,m+4)+mc[180]*index(psi,l-4,m-2)+mc[181]*index(psi,l-4,m-4)+mc[182]*index(psi,l-4,m)+mc[183]*index(psi,l-4,m+2)+mc[184]*index(psi,l-4,m+4)+mc[185]*index(psi,l,m-2)+mc[186]*index(psi,l,m-4)+mc[187]*index(psi,l,m)+mc[188]*index(psi,l,m+2)+mc[189]*index(psi,l,m+4)+mc[190]*index(psi,l+2,m-2)+mc[191]*index(psi,l+2,m-4)+mc[192]*index(psi,l+2,m)+mc[193]*index(psi,l+2,m+2)+mc[194]*index(psi,l+2,m+4)+mc[195]*index(psi,l+4,m-2)+mc[196]*index(psi,l+4,m-4)+mc[197]*index(psi,l+4,m)+mc[198]*index(psi,l+4,m+2)+mc[199]*index(psi,l+4,m+4));
      yyyz = (mc[200]*index(psi,l-2,m-1)+mc[201]*index(psi,l-2,m-3)+mc[202]*index(psi,l-2,m+1)+mc[203]*index(psi,l-2,m+3)+mc[204]*index(psi,l-4,m-1)+mc[205]*index(psi,l-4,m-3)+mc[206]*index(psi,l-4,m+1)+mc[207]*index(psi,l-4,m+3)+mc[208]*index(psi,l,m-1)+mc[209]*index(psi,l,m-3)+mc[210]*index(psi,l,m+1)+mc[211]*index(psi,l,m+3)+mc[212]*index(psi,l+2,m-1)+mc[213]*index(psi,l+2,m-3)+mc[214]*index(psi,l+2,m+1)+mc[215]*index(psi,l+2,m+3)+mc[216]*index(psi,l+4,m-1)+mc[217]*index(psi,l+4,m-3)+mc[218]*index(psi,l+4,m+1)+mc[219]*index(psi,l+4,m+3));
      yyzz = (mc[220]*index(psi,l-2,m-2)+mc[221]*index(psi,l-2,m)+mc[222]*index(psi,l-2,m+2)+mc[223]*index(psi,l-4,m-2)+mc[224]*index(psi,l-4,m)+mc[225]*index(psi,l-4,m+2)+mc[226]*index(psi,l,m-2)+mc[227]*index(psi,l,m)+mc[228]*index(psi,l,m+2)+mc[229]*index(psi,l+2,m-2)+mc[230]*index(psi,l+2,m)+mc[231]*index(psi,l+2,m+2)+mc[232]*index(psi,l+4,m-2)+mc[233]*index(psi,l+4,m)+mc[234]*index(psi,l+4,m+2));
      yzzz = (mc[235]*index(psi,l-2,m-1)+mc[236]*index(psi,l-2,m+1)+mc[237]*index(psi,l-4,m-1)+mc[238]*index(psi,l-4,m+1)+mc[239]*index(psi,l,m-1)+mc[240]*index(psi,l,m+1)+mc[241]*index(psi,l+2,m-1)+mc[242]*index(psi,l+2,m+1)+mc[243]*index(psi,l+4,m-1)+mc[244]*index(psi,l+4,m+1));
      zzzz = (mc[245]*index(psi,l-2,m)+mc[246]*index(psi,l-4,m)+mc[247]*index(psi,l,m)+mc[248]*index(psi,l+2,m)+mc[249]*index(psi,l+4,m));
      psi1[ind(l,m)] = psi[ind(l,m)]
        + kappa*(xxxx*pow(gamm[0][0],2) + 4*xxxy*gamm[0][0]*gamm[0][1] + 
                 4*xxyy*pow(gamm[0][1],2) + 4*xxxz*gamm[0][0]*gamm[0][2] + 
                 8*xxyz*gamm[0][1]*gamm[0][2] + 4*xxzz*pow(gamm[0][2],2) + 
                 2*xxyy*gamm[0][0]*gamm[1][1] + 4*xyyy*gamm[0][1]*gamm[1][1] + 
                 4*xyyz*gamm[0][2]*gamm[1][1] + yyyy*pow(gamm[1][1],2) + 
                 4*xxyz*gamm[0][0]*gamm[1][2] + 8*xyyz*gamm[0][1]*gamm[1][2] + 
                 8*xyzz*gamm[0][2]*gamm[1][2] + 4*yyyz*gamm[1][1]*gamm[1][2] + 
                 4*yyzz*pow(gamm[1][2],2) + 2*xxzz*gamm[0][0]*gamm[2][2] + 
                 4*xyzz*gamm[0][1]*gamm[2][2] + 4*xzzz*gamm[0][2]*gamm[2][2] + 
                 2*yyzz*gamm[1][1]*gamm[2][2] + 4*yzzz*gamm[1][2]*gamm[2][2] + 
                 zzzz*pow(gamm[2][2],2));
    }
    /* Broadcast that thread is finished. */
    pthread_mutex_lock(&job_m);
    job_info->control = 0;
    pthread_mutex_unlock(&job_m);
    pthread_cond_broadcast(&job_c);
  }
  return(NULL);
}

static void * thread_function_1(void *arg) {
  struct job_info_s* job_info = arg;
  while (1) {
    int lstart, lend;
    /* Wait until thread is told to start. */
    pthread_mutex_lock(&job_m);
    while (job_info->control != 1) {
      pthread_cond_wait(&job_c, &job_m);
    }
    lstart = job_info->lstart;
    lend = job_info->lend;
    pthread_mutex_unlock(&job_m);
    COMPLEX* psidot;
    COMPLEX* psi;
  /* Copy data to thread. */
    memcpy(&(psidot),&(thread_pass_args_1.psidot),sizeof(psidot));
    memcpy(&(psi),&(thread_pass_args_1.psi),sizeof(psi));
    int l,m;
    COMPLEX *mc;
    for (l=lstart;l<lend;l+=2) for (m=0;m<=l;m++) {
      mc = mult_constant_1 + mc_count_1*ind(l,m);
      psidot[ind(l,m)] += lambda*gamm[0][0]*(mc[0]*index(psi1,l-2,m-2)+mc[1]*index(psi1,l-2,m)+mc[2]*index(psi1,l-2,m+2)+mc[3]*index(psi1,l,m-2)+mc[4]*index(psi1,l,m)+mc[5]*index(psi1,l,m+2)+mc[6]*index(psi1,l+2,m-2)+mc[7]*index(psi1,l+2,m)+mc[8]*index(psi1,l+2,m+2));
      psidot[ind(l,m)] += lambda*gamm[0][1]*(mc[9]*index(psi1,l-2,m-2)+mc[10]*index(psi1,l-2,m+2)+mc[11]*index(psi1,l,m-2)+mc[12]*index(psi1,l,m+2)+mc[13]*index(psi1,l+2,m-2)+mc[14]*index(psi1,l+2,m+2));
      psidot[ind(l,m)] += lambda*gamm[0][2]*(mc[15]*index(psi1,l-2,m-1)+mc[16]*index(psi1,l-2,m+1)+mc[17]*index(psi1,l,m-1)+mc[18]*index(psi1,l,m+1)+mc[19]*index(psi1,l+2,m-1)+mc[20]*index(psi1,l+2,m+1));
      psidot[ind(l,m)] += lambda*gamm[1][1]*(mc[21]*index(psi1,l-2,m-2)+mc[22]*index(psi1,l-2,m)+mc[23]*index(psi1,l-2,m+2)+mc[24]*index(psi1,l,m-2)+mc[25]*index(psi1,l,m)+mc[26]*index(psi1,l,m+2)+mc[27]*index(psi1,l+2,m-2)+mc[28]*index(psi1,l+2,m)+mc[29]*index(psi1,l+2,m+2));
      psidot[ind(l,m)] += lambda*gamm[1][2]*(mc[30]*index(psi1,l-2,m-1)+mc[31]*index(psi1,l-2,m+1)+mc[32]*index(psi1,l,m-1)+mc[33]*index(psi1,l,m+1)+mc[34]*index(psi1,l+2,m-1)+mc[35]*index(psi1,l+2,m+1));
      psidot[ind(l,m)] += lambda*gamm[2][2]*(mc[36]*index(psi1,l-2,m)+mc[37]*index(psi1,l,m)+mc[38]*index(psi1,l+2,m));
  
      psidot[ind(l,m)] += w[0]*(mc[39]*index(psi,l,m-1)+mc[40]*index(psi,l,m+1));
      psidot[ind(l,m)] += w[1]*(mc[41]*index(psi,l,m-1)+mc[42]*index(psi,l,m+1));
      psidot[ind(l,m)] += w[2]*(mc[43]*index(psi,l,m));
  /* Folgar-Tucker correction */
      psidot[ind(l,m)] += Dr*(mc[44]*index(psi,l,m));
    }
    /* Broadcast that thread is finished. */
    pthread_mutex_lock(&job_m);
    job_info->control = 0;
    pthread_mutex_unlock(&job_m);
    pthread_cond_broadcast(&job_c);
  }
  return(NULL);
}
