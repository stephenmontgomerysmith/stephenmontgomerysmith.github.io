#/usr/bin/perl -w

# To use maxima instead of mathematica, set the environment variable USE_MAXIMA

use strict;

use Expect::Simple;

my $tensor = defined($ENV{"TENSOR"}) && $ENV{"TENSOR"};
my $use_maxima = defined($ENV{"USE_MAXIMA"}) && $ENV{"USE_MAXIMA"};

my %attr;
if ($use_maxima) {
  %attr = (Cmd => "maxima",
    Prompt => [-re => '\(\%i\d+\)'],
    DisconnectCmd => "quit();"
  );
} else {
  %attr = (Cmd => "math",
    Prompt => [-re => 'In\[\d+\]\:\=\s+'],
    DisconnectCmd => "Exit"
  );
}

my $mathcmd = Expect::Simple->new(\%attr);

if ($tensor) {
  if ($use_maxima) {
    $mathcmd->send("l:0;m:0;");
  } else {
    $mathcmd->send("l=0;m=0");
  }
  my $junk = $mathcmd->before;
}

sub cform {
  my $return;
  if ($use_maxima) {
    if ($tensor) {
      $mathcmd->send("$_[0], numer;");
      $return = $mathcmd->before;
      $return =~ s/.*?\(\%o\d+\)(.*)/\1/s || die;
      $return =~ s/\s//g;
      $return =~ s/\r//g;
      $return =~ s/\\//g;
    } else {
      $return = $_[0];
      $return =~ s/(\w+)\^(\d+)/pow\($1\,$2p\)/g;
      $return =~ s/(\d+)(?!p)/$1\./g;
      $return =~ s/(\d+)p/$1/g;
    }
  } else {
    if ($tensor) {
      $mathcmd->send("CForm[N[$_[0],20]]");
    } else {
      $mathcmd->send("CForm[Simplify[$_[0]]]");
    }
    $return = $mathcmd->before;
    $return =~ s/.*?Out\[\d+\]\/\/CForm\=\s+(.*)/\1/s || die;
    $return =~ s/\s//g;
    $return =~ s/\r//g;
    $return =~ s/Power/pow/g;
    $return =~ s/Sqrt/sqrt/g;
  }
  return $return;
}

sub texform {
  my $return;
  if ($use_maxima) {
    my $in = $_[0];
    $in =~ s/I/\%i/;
    $mathcmd->send("tex($in);");
    $return = $mathcmd->before;
    $return =~ s/.*\$\$(.*)\$\$.*/$1/s || die;
  } else {
    $mathcmd->send("TeXForm[Simplify[$_[0]]]");
    $return = $mathcmd->before;
    $return =~ s/.*?Out\[\d+\]\/\/TeXForm\=\s+(.*)/\1/s || die;
    $return =~ s/\s//g;
    $return =~ s/\r//g;
  }
  return $return;
}

sub simplify {
  my $return;
  if ($use_maxima) {
    my $in = $_[0];
    $in =~ s/\[/\(/g;
    $in =~ s/\]/\)/g;
    $in =~ s/Sqrt/sqrt/g;
    $in =~ s/Rationalize/rationalize/g;
    $mathcmd->send("string(fullratsimp($in));");
    $return = $mathcmd->before;
    $return =~ s/.*?\(\%o\d+\)(.*)/\1/s || die;
    $return =~ s/\s//g;
    $return =~ s/\r//g;
    $return =~ s/\\//g;
  } else {
    $mathcmd->send("InputForm[Simplify[$_[0]]]");
    $return = $mathcmd->before;
    $return =~ s/.*?Out\[\d+\]\/\/InputForm\=\s+(.*)/\1/s || die;
    $return =~ s/\s//g;
    $return =~ s/\r//g;
  }
  return $return;
}

sub simplifycomp {
  my @result;
  foreach (@_) {
    my ($l,$m,$r,$i) = split /\,/,$_;
    if (($r ne '0' && $r ne '0.' && $r ne '0.0') || ($i ne '0' && $i ne '0.' && $i ne '0.0')) {
      push @result, "$l,$m,".simplify($r).",".simplify($i);
    }
  }
  return @result;
}

sub mult {
  my $term;
  my ($l,$m,$r,$i);
  my @result;
  my $n=shift @_;
  foreach $term (@_) {
    ($l,$m,$r,$i) = split /\,/,$term;
    push @result, "$l,$m,($n)*($r),($n)*($i)";
  }
  return simplifycomp(@result);
}

sub multI {
  my $term;
  my ($l,$m,$r,$i);
  my @result;
  my $n=shift @_;
  foreach $term (@_) {
    ($l,$m,$r,$i) = split /\,/,$term;
    push @result, "$l,$m,-($n)*($i),($n)*($r)";
  }
  return simplifycomp(@result);
}

sub add {
  my $term;
  my ($l,$m,$r,$i);
  my ($c_l,$c_m,$c_r,$c_i);
  my @result;
  my $first = 1;
  foreach $term (sort @_) {
    ($l,$m,$r,$i) = split /\,/,$term;
    if (!$first && $c_l==$l && $c_m==$m) {
      $c_r .= "+($r)";
      $c_i .= "+($i)";
    } else {
      if (!$first) {
        push @result, "$c_l,$c_m,$c_r,$c_i";
      }
      $c_l = $l;
      $c_m = $m;
      $c_r = "($r)";
      $c_i = "($i)";
      $first = 0;
    }
  }
  if (!$first) {
    push @result, "$c_l,$c_m,$c_r,$c_i";
  }
  return simplifycomp(@result);
}

sub lm {
  my $term;
  my ($l,$m,$r,$i);
  my @result;
  foreach $term (@_) {
    ($l,$m,$r,$i) = split /\,/,$term;
    push @result, "$l,".($m+1).",($r)*Sqrt[l-m+($l)-($m)]*Sqrt[l+m+($l)+($m)+1],($i)*Sqrt[l-m+($l)-($m)]*Sqrt[l+m+($l)+($m)+1]";
  }
  return simplifycomp(@result);
}

sub lp {
  my $term;
  my ($l,$m,$r,$i);
  my @result;
  foreach $term (@_) {
    ($l,$m,$r,$i) = split /\,/,$term;
    push @result, "$l,".($m-1).",($r)*Sqrt[l+m+($l)+($m)]*Sqrt[l-m+($l)-($m)+1],($i)*Sqrt[l+m+($l)+($m)]*Sqrt[l-m+($l)-($m)+1]";
  }
  return simplifycomp(@result);
}

sub ilx {
  return add(multI("(1/2)",lp(@_)),multI("(1/2)",lm(@_)));
}

sub ily {
  return add(mult("(1/2)",lp(@_)),mult("(-1/2)",lm(@_)));
}

sub ilz {
  my $term;
  my ($l,$m,$r,$i);
  my @result;
  foreach $term (@_) {
    ($l,$m,$r,$i) = split /\,/,$term;
    push @result, "$l,$m,(m+($m))*($i),-(m+($m))*($r)";
  }
  return simplifycomp(@result);
}

sub zz {
  my $term;
  my ($l,$m,$r,$i);
  my @result;
  foreach $term (@_) {
    ($l,$m,$r,$i) = split /\,/,$term;
    push @result, ($l-1).",".($m).
        ",($r)*Sqrt[l+m+($l)+($m)]*Sqrt[l-m+($l)-($m)]/Sqrt[2*l+2*($l)-1]/Sqrt[2*l+2*($l)+1]".
        ",($i)*Sqrt[l+m+($l)+($m)]*Sqrt[l-m+($l)-($m)]/Sqrt[2*l+2*($l)-1]/Sqrt[2*l+2*($l)+1]";
    push @result, ($l+1).",".($m).
        ",($r)*Sqrt[l+m+($l)+($m)+1]*Sqrt[l-m+($l)-($m)+1]/Sqrt[2*l+2*($l)+1]/Sqrt[2*l+2*($l)+3]".
        ",($i)*Sqrt[l+m+($l)+($m)+1]*Sqrt[l-m+($l)-($m)+1]/Sqrt[2*l+2*($l)+1]/Sqrt[2*l+2*($l)+3]";
  }
  return add(@result);
}

sub xx {
  return add(zz(ily(@_)),mult(-1,ily(zz(@_))));
}

sub yy {
  return add(ilx(zz(@_)),mult(-1,zz(ilx(@_))));
}

sub dx {
  return add(zz(ily(@_)),mult(-1,yy(ilz(@_))));
}

sub dy {
  return add(xx(ilz(@_)),mult(-1,zz(ilx(@_))));
}

sub dz {
  return add(yy(ilx(@_)),mult(-1,xx(ily(@_))));
}

print "> ";
while (my $line=<>) {
  chomp $line;
  exit if $line eq 'q';
  my @start_c;
  if ($line =~ s/^start\s+//) {
    @start_c = split /\;/, $line;
    print "> ";
    $line=<>;
    chomp $line;
  } else {
    @start_c = ("0,0,1,0");
  }
  my $intermediate = ($line =~ s/^i\s+//);
  my $latex = ($line =~ s/^t\s+//);
  my @comp = ();
  while($line =~ s/^(\+|\-|)([^\-\+]+)//) {
    my $sign = $1;
    my @c = @start_c;
    foreach my $a (reverse split /\*/,$2) {
      @c = xx(@c) if $a eq 'x';
      @c = yy(@c) if $a eq 'y';
      @c = zz(@c) if $a eq 'z';
      @c = dx(@c) if $a eq 'dx';
      @c = dy(@c) if $a eq 'dy';
      @c = dz(@c) if $a eq 'dz';
      @c = ilx(@c) if $a eq 'ilx';
      @c = ily(@c) if $a eq 'ily';
      @c = ilz(@c) if $a eq 'ilz';
      @c = lp(@c) if $a eq 'lp';
      @c = lm(@c) if $a eq 'lm';
      @c = mult("Rationalize[$1]",@c) if $a =~ /^([\d\.]+)$/;
    }
    @c = mult(-1,@c) if $sign eq '-';
    @comp = add(@comp,@c);
  }

  my $first = 1;
  foreach my $c (@comp) {
    my ($l,$m,$r,$i) = split ',',$c;
    if ($intermediate) {
      if (($r ne '0' && $r ne '0.' && $r ne '0.0') || ($i ne '0' && $i ne '0.' && $i ne '0.0')) {
        print ";" if !$first;
        $first = 0;
        print "$l,$m,$r,$i";
      }
    } elsif ($latex) {
      my $n = texform("$r+I*($i)");
      if (($n ne '0' && $n ne '0.' && $n ne '0.0')) {
        print "\n" if !$first;
        $first = 0;
        if ($tensor) {
          print "c_{$l,$m} = $n ";
        } else {
          $l = "+$l" if $l>0;
          $l = "" if $l==0;
          $m = "+$m" if $m>0;
          $m = "" if $m==0;
          print "c_{l,l$l}^{m,m$m} = $n ";
        }
      }
    } else {
      $r = cform($r);
      $i = cform($i);
      if (($r ne '0' && $r ne '0.' && $r ne '0.0') || ($i ne '0' && $i ne '0.' && $i ne '0.0')) {
        print "\n" if !$first;
        $first = 0;
        print "$l;$m;($r)+($i)*I";
      }
    }
  }
  print "\n> ";
}
