#include "spherical.h"

extern double kappa;
static int first_time=1;

void compute_psidot_wot(COMPLEX* psidot, COMPLEX* psi) {
  double a2[3][3];
  double da2[3][3];
  double collapsed_da2[3][3];
  int i,j;

  if (first_time) {
    char answer[10];
    printf("Do you have permission from the holders of U.S. Patent No. 7,266,469? ");
    fgets(answer,10,stdin);
    if (strcmp(answer,"yes\n")!=0) {
      printf("This program will not run if given an answer other than \"yes\" (written in full).\n");
      exit(0);
    }
    first_time = 0;
  }

  tensor2(psi,a2);
  tensor2(psidot,da2);
  collapse(3,da2,collapsed_da2,a2);
  for (i=0;i<3;i++) for (j=0;j<3;j++)
    collapsed_da2[i][j] *= -(1-kappa);
  reverse_tensor2(collapsed_da2,psidot);
}
