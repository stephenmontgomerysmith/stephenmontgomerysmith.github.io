#include "spherical.h"

double h;
int print_every;
int nr_threads;
int max_order;
char *outfilename = "s.out";
int verbose = 0;
int verbose_print = 0;

double tstart;
double tend;
double lambda;
double w[3];
double gamm[3][3];
int do_koch;
int do_dd;
int do_dd_2;
int do_fd;
double CI;
double C1;
double C2;
double alpha;
double beta;
COMPLEX *lap_psi;
double do_vl;
double lambda1;
double lambda2;
int print_aij, print_aijkl, print_aijklmn;
int param_filename_set = 0;

double Dr;
double normgamma;

void derivs(double t, COMPLEX *x, COMPLEX *dx) {
  t = t; /* artificial way to avoid compiler warnings */
  memset(dx,0,sizeof(COMPLEX)*length);
  if (do_vl) compute_psidot_vl(dx,x);
  else compute_psidot(dx,x);
  if (do_koch) compute_psidot_koch(dx,x);
  if (do_dd) compute_psidot_dd(dx,x);
  if (do_dd_2) compute_psidot_dd_2(dx,x);
  if (do_fd) compute_psidot_fd(dx,x);
}

int main(int argc, char **argv) {
  int i,j;
  FILE *sout;
  COMPLEX *x;
  double t;
  int iteration;
  double a2[3][3];

  for (i=1;i<argc; i++) {
    if (strcmp(argv[i],"-p")==0 && i+1<argc) {
      i++;
      set_param_filename(argv[i]);
      param_filename_set = 1;
    }
    else if (strcmp(argv[i],"-o")==0 && i+1<argc) {
      i++;
      outfilename = argv[i];
    }
    else if (strcmp(argv[i],"-v")==0) {
      verbose = 1;
      if (i+1 < argc) {
        verbose_print = strtol(argv[i+1],NULL,10);
        if (verbose_print>=1) i++;
        if (verbose_print<=0) verbose_print = 0;
      }
    }
    else {
      param_filename_set = 0;
      break;
    }
  }
  if (!param_filename_set) {
    printf("Usage: %s -p <parameters-file> [-o <output-file>] [-v [<number>]]\n"
           "  if -o is not set, <output-file> defaults to \"s.out\".\n"
           "  -v gives verbose output.\n"
           "  <number> is how often to print output to terminal.\n", argv[0]);
    exit(0);
  }
  set_param_verbose_level(verbose);

  h = param_double("h");
  print_every = param_int("print_every");
  if (getenv("NR_THREADS")==NULL)
    nr_threads = param_int("nr_threads");
  else {
    nr_threads = strtol(getenv("NR_THREADS"),NULL,10);
    if (verbose) printf("nr_threads=%d\n",nr_threads);
  }
  max_order = param_int("max_order");
  tstart = param_double("tstart");
  tend = param_double("tend");
  do_vl = param_bool("do_vl");
  if (do_vl) {
    lambda1 = param_double("lambda1");
    lambda2 = param_double("lambda2");
  } else
    lambda = param_double("lambda");
  w[0] = param_double("w1");
  w[1] = param_double("w2");
  w[2] = param_double("w3");
  gamm[0][0] = param_double("gamma11");
  gamm[0][1] = gamm[1][0] = param_double("gamma12");
  gamm[0][2] = gamm[2][0] = param_double("gamma13");
  gamm[1][1] = param_double("gamma22");
  gamm[1][2] = gamm[2][1] = param_double("gamma23");
  gamm[2][2] = param_double("gamma33");
  do_koch = param_bool("do_koch");
  do_dd = param_bool("do_dd");
  do_dd_2 = param_bool("do_dd_2");
  do_fd = param_bool("do_fd");
  if (do_koch || do_dd || do_dd_2) {
    C1 = param_double("C1");
    C2 = param_double("C2");
    CI = 0;
  } else if (do_fd) {
    C1 = param_double("C1");
    CI = 0;
    alpha = param_double("alpha");
    beta = param_double("beta");
  } else
    CI = param_double("CI");
  print_aij = param_bool("print_aij");
  print_aijkl = param_bool("print_aijkl");
  print_aijklmn = param_bool("print_aijklmn");

  normgamma = 0;
  for (i=0;i<3;i++) for (j=0;j<3;j++) normgamma += gamm[i][j]*gamm[i][j];
  normgamma = sqrt(normgamma/2);
  Dr = CI*normgamma;

  if (do_vl) compute_psidot_vl_initialize(nr_threads);
  else compute_psidot_initialize(nr_threads);
  if (do_koch) compute_psidot_koch_initialize(nr_threads);
  if (do_dd) {
    allocate(&lap_psi);
    compute_lap_psi_initialize(nr_threads);
    compute_psidot_dd_initialize(nr_threads);
  } else if (do_dd_2) {
    allocate(&lap_psi);
    compute_lap_psi_initialize(nr_threads);
    compute_psidot_dd_2_initialize(nr_threads);
  }
  ode_adams_bash_2_initialise(&t,x,h,derivs);
  allocate(&x);
  x[0] = 1;

  t = tstart;
  iteration=0;

  sout = fopen(outfilename,"w");
  if (sout==NULL) {
    perror("unable to open output file");
    exit(1);
  }

  while (1) {
    if (iteration%print_every==0) {
      fprintf(sout,"%g",t);
      tensor2(x,a2);
      if (!print_aij)
        fprintf(sout," %g %g %g",a2[0][0],a2[1][1],a2[2][2]);
      else
        for (i=0;i<3;i++) for (j=i;j<3;j++) fprintf(sout," %g",a2[i][j]);
      if (print_aijkl) {
        double a4[3][3][3][3];
        int k,l;
        tensor4(x,a4);
        for (i=0;i<3;i++) for (j=i;j<3;j++) for (k=j;k<3;k++) for (l=k;l<3;l++)
          fprintf(sout," %g",a4[i][j][k][l]);
      }
      if (print_aijklmn) {
        double a6[3][3][3][3][3][3];
        int k,l,m,n;
        tensor6(x,a6);
        for (i=0;i<3;i++) for (j=i;j<3;j++) for (k=j;k<3;k++)
          for (l=k;l<3;l++) for (m=l;m<3;m++) for (n=m;n<3;n++)
            fprintf(sout," %g",a6[i][j][k][l][m][n]);
      }
      fprintf(sout,"\n");
      fflush(sout);
      if (verbose_print!=0 && (iteration/print_every)%verbose_print==0) {
        printf("%g %g %g %g\n",t, a2[0][0],a2[1][1],a2[2][2]);
      }
    }
    if (t>=tend) break;
    ode_adams_bash_2_solve(&t,x,h,derivs);
    iteration++;
  }

  exit(0);
}
