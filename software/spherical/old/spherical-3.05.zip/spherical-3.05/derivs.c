#include "spherical.h"

/*
If param->do_manage_stiffness is set, the program solves the Folgar-Tucker
equation:
   d psi/dt = c Lap psi + F(psi)
by rewriting it as
   d phi/dt = exp(-c(t-t_0)Lap) F(exp(c(t-t_0)Lap)phi),
   psi = exp(c(t-t_0)Lap)phi .
It is easy to compute exp(nu Lap), because in spherical harmonics, Lap is a
diagonal operator.  It is calculated using the function apply_exp_lap.
Here t_0 is stored as param->base_t, and is reset in spherical.c to the
current value of t before each new step is calculated.
*/

static int first = 1;
static REAL *psi;

void derivs(REAL t, REAL *psi_in, REAL *psidot,param_list_t *param) {

  if (first) {
    first = 0;
    if (param->do_manage_stiffness) {
      psi = (REAL*)malloc(sizeof(REAL)*param->length);
      memset(psi,0,sizeof(REAL)*param->length);
    }
  }

  if (param->do_manage_stiffness)
    apply_exp_lap(param->Dr*(t-param->base_t),psi,psi_in,param);
  else
    psi = psi_in;

  memset(psidot,0,sizeof(REAL)*param->length);

  condon_shortley(psi,param);

  if (param->do_vl) compute_psidot_vl(psidot,psi,param);
  else compute_psidot(psidot,psi,param);

  if (param->do_koch) compute_psidot_koch(psidot,psi,param);
  else if (param->do_dd) compute_psidot_dd(psidot,psi,param);
  else if (param->do_dd_2) compute_psidot_dd_2(psidot,psi,param);
  else if (param->do_vd) compute_psidot_vd(psidot,psi,param);
  else if (param->do_ard) compute_psidot_ard(psidot,psi,param);

  if (param->do_rsc) compute_psidot_rsc(psidot,psi,param);

  if (param->do_manage_stiffness)
    apply_exp_lap(param->Dr*(param->base_t-t),psidot,psidot,param);
}

/* Y_l^(-m) = (-1)^m conj(Y_l^m) */

void condon_shortley(REAL *psi, param_list_t *param) {
  int l,m,c;

  for (l=0;l<=param->max_order;l+=2)
    for (m=-PADDING;m<0;m++)
      for (c=0;c<=1;c++)
        psi[ind(l,m,c)] = (m%2)^c ? -psi[ind(l,-m,c)] : psi[ind(l,-m,c)];
}

void apply_exp_lap(REAL nu, REAL *psi_out, REAL *psi_in, param_list_t *param) {
  int l,m,c;

  for (l=4;l<=param->max_order;l+=2)
    for (m=0;m<=l;m++)
      for (c=0;c<=1;c++)
        psi_out[ind(l,m,c)] = exp(-nu*l*(l+1))*psi_in[ind(l,m,c)];
  for (l=0;l<=2;l+=2)
    for (m=0;m<=l;m++)
      for (c=0;c<=1;c++)
        if (param->do_rsc)
          psi_out[ind(l,m,c)] = exp(-nu*param->kappa*l*(l+1))*psi_in[ind(l,m,c)];
        else
          psi_out[ind(l,m,c)] = exp(-nu*l*(l+1))*psi_in[ind(l,m,c)];
}
