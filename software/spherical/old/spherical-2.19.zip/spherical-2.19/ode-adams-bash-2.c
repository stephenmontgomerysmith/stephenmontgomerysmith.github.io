#include "spherical.h"

static COMPLEX *diffx;
static COMPLEX *olddiffx;
static COMPLEX *tempx;
static int iter=0;
static int first = 1;

extern int max_order;

static void ode_adams_bash_2_initialize()
{
  first = 0;
  iter = 0;
  allocate(&diffx);
  allocate(&tempx);
  allocate(&olddiffx);
}

static void midpoint(double t, COMPLEX *x, double h,
              void derivs(double t, COMPLEX *x, COMPLEX *diffx))
{
  int i;

  derivs(t,x,diffx);
  for (i=0;i<length;i++)
    olddiffx[i] = diffx[i];
  for (i=0;i<length;i++) tempx[i] = x[i] + h*diffx[i]/2;
  derivs(t+h/2,tempx,diffx);
  for (i=0;i<length;i++) x[i] += h*diffx[i];
}

static void adams_bashforth(double t, COMPLEX *x, double h,
                     void derivs(double t, COMPLEX *x, COMPLEX *diffx))
{
  int i;

  derivs(t,x,diffx);
  for (i=0;i<length;i++)
    x[i] = x[i] + h/2 * (3*diffx[i] - olddiffx[i]);
  for (i=0;i<length;i++)
    olddiffx[i] = diffx[i];
}

void ode_adams_bash_2_solve(double *t, COMPLEX *x, double h,
               void derivs(double t, COMPLEX *x, COMPLEX *diffx))
{
  if (first) ode_adams_bash_2_initialize();
#ifdef RK_ONLY
  iter = 0; /* Force always using Runge-Kutta */
#endif
  if (iter == 0)
    midpoint(*t,x,h,derivs);
  else
    adams_bashforth(*t,x,h,derivs);
  iter++;
  *t += h;
}
