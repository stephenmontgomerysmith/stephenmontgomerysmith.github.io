#include "spherical.h"

/* Adds to psi sqrt(4 pi) times tensor of rank 2 */
void reverse_tensor2(double a[3][3], COMPLEX *psi) {
  psi[ind(0,0)] += a[0][0] + a[1][1] + a[2][2];
  psi[ind(2,0)] += - 1.1180339887498948482*a[0][0] 
                   - 1.1180339887498948482*a[1][1]
                   + 2.2360679774997896964*a[2][2];
  psi[ind(2,1)] += - 2.7386127875258305673*a[0][2]
                   + 2.7386127875258305673*I*a[1][2];
  psi[ind(2,2)] +=   1.3693063937629152836*a[0][0]
                   - 2.7386127875258305673*I*a[0][1]
                   - 1.3693063937629152836*a[1][1];
}

/* In case you want to test it

double max_order = 2;

main () {
  double a2[3][3] = {{3,11,26},
                    {11,5,16},
                    {26,16,9}};
  COMPLEX *psi;
  int i,j;
  psi = malloc(sizeof(COMPLEX)*length);
  memset(psi,0,sizeof(COMPLEX)*length);
  reverse_tensor2(a2,psi);
  tensor2(psi,a2);
  for (i=0;i<3;i++) {
    for (j=0;j<3;j++)
      printf("%g ",a2[i][j]);
    printf("\n");
  }
  reverse_tensor2(a2,psi);
  tensor2(psi,a2);
  for (i=0;i<3;i++) {
    for (j=0;j<3;j++)
      printf("%g ",a2[i][j]);
    printf("\n");
  }
}

*/
