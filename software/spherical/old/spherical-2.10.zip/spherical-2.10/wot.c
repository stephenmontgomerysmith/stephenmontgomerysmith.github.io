#include "spherical.h"

extern double kappa;

void compute_psidot_wot(COMPLEX* psidot, COMPLEX* psi) {
  double a2[3][3];
  double da2[3][3];
  double collapsed_da2[3][3];
  int i,j;

  tensor2(psi,a2);
  tensor2(psidot,da2);
  collapse(3,da2,collapsed_da2,a2);
  for (i=0;i<3;i++) for (j=0;j<3;j++)
    collapsed_da2[i][j] *= -(1-kappa);
  reverse_tensor2(collapsed_da2,psidot);
}
