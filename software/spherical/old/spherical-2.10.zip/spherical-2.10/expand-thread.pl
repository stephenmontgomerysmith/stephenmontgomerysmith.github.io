#/usr/bin/perl -w

use strict;

my $main_proc;
my $arg;
my $inside_function=0;
my $inside_threading=0;
my $thread_text;
my $main_text = "";
my $function_name;

my $struct;
my $memcpy;
my $memcpy2;

while(my $line = <>) {
  if ($line =~ s/^(void\s+)(\S+)(\s*)\((.*?)\)(.*)$/void $2$3\($4\)$5/) {
    $function_name = $2;
    $arg = $4;
    $arg = "  $arg;\n" if $arg =~ s/\,/\;/;
    $inside_function = 1;
    $main_text .= "/* Converted into a threaded program by $0. */\n";
    $main_text .= "#include <pthread.h>\n";
    $main_text .= "static pthread_mutex_t job_m = PTHREAD_MUTEX_INITIALIZER;\n";
    $main_text .= "static pthread_cond_t job_c = PTHREAD_COND_INITIALIZER;\n";
    $main_text .= "static struct {\n\$struct} ${function_name}_pass_args;\n";
    $main_text .= "static void *${function_name}_thread(void *arg);\n";
    $main_text .= "static struct job_info_s {int control, lstart, lend;} *job_info;\n";
    $main_text .= "static int first_thread = 1;\n";
    $main_text .= "extern int nr_threads;\n\n";
    $main_text .= $line;
  } elsif ($inside_function && $line =~ /^\}/) {
    $inside_function = 0;
    $main_text .= $line;
  } elsif ($line =~ /\/\* Start\-Threading \*\//) {
    $line = <>;
    $thread_text = "";
    $inside_threading = 1;
  } elsif ($line =~ /\/\* Stop\-Threading \*\//) {
    $inside_threading = 0;
    $struct = "";
    $memcpy = "";
    $memcpy2 = "";
    foreach my $a (split ';',$arg) {
      $a =~ s/^\s*(\S+)//;
      my $type = $1;
      if ($a =~ /\S/) {
        foreach my $b (split ',',$a) {
          $b =~ s/^\s*//;
          $b =~ s/\s*$//;
          my $c = $b;
          $c =~ s/\*//g;
          $c =~ s/\[.*?\]//g;
          if ($thread_text =~ /\b${c}\b/) {
            $struct .= "  $type $b;\n";
            $memcpy .= "  memcpy(&(${function_name}_pass_args.$c),&($c),sizeof($c));\n";
            $memcpy2 .= "  memcpy(&($c),&(${function_name}_pass_args.$c),sizeof($c));\n";
          }
        }
      }
    }
    $main_text .= "  pthread_t pid;\n";
    $main_text .= "  int i;\n";
    $main_text .= "  /* Start threads the first time around. */\n";
    $main_text .= "  if (first_thread) {\n";
    $main_text .= "    first_thread = 0;\n";
    $main_text .= "    job_info = malloc(nr_threads*sizeof(struct job_info_s));\n";
    $main_text .= "    for (i=0;i<nr_threads;i++) {\n";
    $main_text .= "      job_info[i].control = 0;\n";
    $main_text .= "      job_info[i].lstart = 0;\n";
    $main_text .= "      job_info[i].lend = 0;\n";
    $main_text .= "      pthread_create(&pid, NULL, ${function_name}_thread, job_info+i);\n";
    $main_text .= "      pthread_detach(pid);\n";
    $main_text .= "    }\n";
    $main_text .= "  }\n";
    $main_text .= "  /* Copy data to threads. */\n";
    $main_text .= $memcpy;
    $main_text .= "  pthread_mutex_lock(&job_m);\n";
    $main_text .= "  /* The ranges for l are assigned to each thread.  Note that the work\n";
    $main_text .= "     required to calculate for l between lstart and lend is proportional to\n";
    $main_text .= "     lend^2 - lstart^2. */\n";
    $main_text .= "  for (i=0;i<nr_threads;i++) {\n";
    $main_text .= "    if (i==0) job_info[i].lstart = 0;\n";
    $main_text .= "    else      job_info[i].lstart = job_info[i-1].lend;\n";
    $main_text .= "    if (i==nr_threads-1) job_info[i].lend=max_order+1;\n";
    $main_text .= "    else job_info[i].lend = (double)(max_order+1)*sqrt((i+1.)/(double)nr_threads);\n";
    $main_text .= "    job_info[i].lend += (job_info[i].lend)%2; /* round up to next even number. */\n";
    $main_text .= "  }\n";
    $main_text .= "  /* Start each thread, and then wait for each thread to finish. */\n";
    $main_text .= "  for (i=0;i<nr_threads;i++) {\n";
    $main_text .= "    job_info[i].control = 1;\n";
    $main_text .= "  }\n";
    $main_text .= "  pthread_mutex_unlock(&job_m);\n";
    $main_text .= "  pthread_cond_broadcast(&job_c);\n";
    $main_text .= "  for (i=0;i<nr_threads;i++) {\n";
    $main_text .= "    pthread_mutex_lock(&job_m);\n";
    $main_text .= "    while (job_info[i].control != 0) {\n";
    $main_text .= "      pthread_cond_wait(&job_c, &job_m);\n";
    $main_text .= "    }\n";
    $main_text .= "    pthread_mutex_unlock(&job_m);\n";
    $main_text .= "  }\n";
    $thread_text = "$struct  /* Copy data to thread. */\n$memcpy2$thread_text";
  } else {
    if ($inside_threading) {
      $thread_text .= $line;
    } elsif ($inside_function) {
      $arg .= $line if $line =~ /^\s*(int|double|COMPLEX)/;
      $main_text .= $line;
    } else {
      $main_text .= $line;
    }
  }
}

$main_text =~ s/\$struct/$struct/;
print $main_text;

print "\nstatic void * ${function_name}_thread(void *arg) {\n";
print "  struct job_info_s* job_info = arg;\n";
print "  while (1) {\n";
print "    int lstart, lend;\n";
print "    /* Wait until thread is told to start. */\n";
print "    pthread_mutex_lock(&job_m);\n";
print "    while (job_info->control != 1) {\n";
print "      pthread_cond_wait(&job_c, &job_m);\n";
print "    }\n";
print "    lstart = job_info->lstart;\n";
print "    lend = job_info->lend;\n";
print "    pthread_mutex_unlock(&job_m);\n";
$thread_text =~ s/^/  /gm;
print $thread_text;
print "    /* Broadcast that thread is finished. */\n";
print "    pthread_mutex_lock(&job_m);\n";
print "    job_info->control = 0;\n";
print "    pthread_mutex_unlock(&job_m);\n";
print "    pthread_cond_broadcast(&job_c);\n";
print "  }\n  return(NULL);\n}\n";
