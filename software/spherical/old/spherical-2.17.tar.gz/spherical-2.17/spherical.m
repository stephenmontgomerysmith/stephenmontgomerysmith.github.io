fid = fopen('s.out');
stuff = fscanf(fid,'%g',[4,Inf]);
xlabel('t')
ylabel('a')
plot(stuff(1,:),stuff(2,:),";a11;");
hold on
plot(stuff(1,:),stuff(3,:),";a22;");
plot(stuff(1,:),stuff(4,:),";a33;");
hold off
print('s-out.eps','-deps');
