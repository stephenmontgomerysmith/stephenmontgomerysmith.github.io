#/usr/bin/perl -w

use strict;

use Expect::Simple;

sub plus {
  return $_[0] if $_[1]==0;
  return "$_[0]+$_[1]" if $_[1]>0;
  return "$_[0]$_[1]" if $_[1]<0;
}

my $filename = $ARGV[0];
open(IN,$filename);
my $filenameout = $filename;
$filenameout =~ s/onf$//;
my $function_name;

my $mc_count = 0;
my $init_proc_assign;
my $main_proc;
my $arg;
my $inside_function=0;

my %attr = (Cmd => "env TENSOR=0 perl expand-method.pl",
  Prompt => '> ',
  DisconnectCmd => "q"
);

my $methodcmd = Expect::Simple->new(\%attr);

while(my $line = <IN>) {
  my $text;
  if ($line=~/\@spherical_iterate\s*\{/) {
    while ($line = <IN>) {
      if ($line =~ /\}/) {
        last;
      } else {
        $text .= $line;
      }
    }
    $text =~s/^[\s^\n]*\n//;
    $text =~s/\s*$//;

    $main_proc .= "    for (l=local_lstart;l<local_lend;l+=2) for (m=0;m<=l;m++) {\n";
    $main_proc .= "      mc = mult_constant + mc_count*ind(l,m);\n";

    foreach $line (split "\n",$text) {
      $line =~ s/\@index/ind(l,m)/g;
      $line = "  $line";
      while ($line =~ s/(.*?)\@method\((.*?)\,(.*?)\)//) {
        my $line_start = "$1(";
        my $var = $2;
        $methodcmd->send($3);
        my $response = $methodcmd->before;
        $response =~ s/\r//g;
        $response =~ s/.*?\n//;
        my @line_part;
        foreach my $comp(split "\n",$response) {
          my ($l,$m,$c) = split ';',$comp;
          $c =~ s/([lm])/\1\1/g;
          $init_proc_assign .= "    if (abs(".plus("m",$m).")<=".plus("l",$l).")\n".
                               "      mc[${mc_count}] = $c;\n".
                               "    else\n".
                               "      mc[${mc_count}] = 0;\n";
          push @line_part, "mc[${mc_count}]*index($var,".plus("l",$l).",".plus("m",$m).")";
          $mc_count++;
        }
        if ($#line_part >= 0) {
          $main_proc .= $line_start.join("+",@line_part).")";
        } else {
          $main_proc .= "${line_start}0)";
        }
      }
      $main_proc .= "$line\n";
    }
    $main_proc .= "    }\n"
  } elsif ($line =~ s/^(void\s+)(\S+)(\s*)\((.*?)\)(.*)$/static void *\2\_thread\3\(void *arg\)\5/) {
    $function_name = $2;
    $arg = $4;
    $arg =~ s/\,/\;/;
    $main_proc .= $line;
    $main_proc .= "  int job_nr = *(int*)arg;\n";
    $main_proc .= "  free(arg);\n";
    $main_proc .= "  int l,m,local_lstart,local_lend;\n";
    $main_proc .= "  COMPLEX *mc;\n";
    $main_proc .= "  $arg;\n";
    $main_proc .= "  while (1) {\n";
    $main_proc .= "    wait_job_until(job_control+job_nr,1);\n";
    foreach my $a (split ';',$arg) {
      $a =~ s/.*\s+//;
      $main_proc .= "    $a = data_arg.$a;\n";
    }
    $main_proc .= "    local_lstart = lstart[job_nr];\n";
    $main_proc .= "    local_lend = lend[job_nr];\n";
    $inside_function = 1;
  } elsif ($line =~ /^\}/) {
    $main_proc .= "    set_job_to(job_control+job_nr,0);\n";
    $main_proc .= "  }\n";
    $main_proc .= "  return NULL;\n";
    $main_proc .= $line;
    $inside_function = 0;
  } else {
    $main_proc .= "  " if $inside_function;
    $main_proc .= $line;
  }
}

chomp $init_proc_assign;
chomp $main_proc;

open(OUT,"> $filenameout");

print OUT <<EOM;
/*
 * Created from $filename by $0.
 */

\#include "spherical.h"

/* Used to pass arguments to the threads. */
static struct {$arg;} data_arg;

/* Used to switch the threads on and off, and to set the range of l for each thread.*/
static int nr_jobs, *job_control, *lstart, *lend;

static int first = 1;
extern int max_order;

/* The multiplication constants. */
static COMPLEX *mult_constant;
#define mc_count $mc_count

/*
 * This is the function that does all the work.  It is run several times
 * by different threads.
 */
$main_proc

/*
 * This function initializes ${function_name} in the following ways:
 * 1. allocate space and calculate the multiplication constants;
 * 2. if called the first time, allocate the thread control variables
 *    job_control[] and start the threads;
 * 3. tell each thread which range to calculate via the lstart[] and lend[]
 *    variables.
 */
void ${function_name}_initialize(int nr_threads) {
  int l,m;
  int i;
  double ll,mm;
  COMPLEX *mc;

  allocate_many(&mult_constant,mc_count);
  for (l=0;l<=max_order;l+=2) for (m=0;m<=l;m++) {
    ll = l;
    mm = m;
    mc = mult_constant + mc_count*ind(l,m);
$init_proc_assign
  }

/* The first time the function is called, start the background threads. */
  if (first) {
    nr_jobs = nr_threads;
    job_control = malloc(nr_jobs*sizeof(int));
    lstart = malloc(nr_jobs*sizeof(int));
    lend = malloc(nr_jobs*sizeof(int));
    memset(job_control,0,nr_jobs*sizeof(int));
    for (i=0;i<nr_jobs;i++) {
      start_background_job(${function_name}_thread,i);
    }
    first = 0;
  }
/* The ranges for l are assigned to each thread.  Note that the work
   required to calculate for l between lstart and lend is proportional to
   lend^2 - lstart^2. */
  for (i=0;i<nr_jobs;i++) {
    if (i==0) lstart[i] = 0;
    else      lstart[i] = lend[i-1];
    if (i==nr_jobs-1) lend[i]=max_order+1;
    else lend[i] = (double)(max_order+1)*sqrt((i+1.)/(double)nr_jobs);
    lend[i] += lend[i]%2; /* round up to next even number. */
  }
}

EOM

$arg =~ s/\;/\,/;

print OUT <<EOM;
/*
 * The main function.  After passing the arguments, it starts each
 * thread, and then waits for each thread to finish.
 */
void $function_name($arg) {
  int i;
EOM
foreach my $a (split ',',$arg) {
  $a =~ s/.*\s+//;
  print OUT "  data_arg.$a = $a;\n";
}
print OUT <<EOM;
  for (i=0;i<nr_jobs;i++) set_job_to(job_control+i,1);
  for (i=0;i<nr_jobs;i++) wait_job_until(job_control+i,0);
}
EOM
exit;

print OUT <<EOM;
/*
 * This function can be useful for diagnostic purposes.
 */
void ${function_name}_print_max_mc() {
  int l,m;
  double max,a;

  for (l=0;l<=max_order;l+=2) {
    max = 0;
    for (m=0;m<=l;m++) {
EOM
for (my $i=0;$i<$mc_count;$i++) {
  print OUT "      a = cabs(mc${i}(ind(l,m)));\n";
  print OUT "      if (isinf(a)) printf(\"mc${i} infinite at %d %d\\n\",l,m);\n";
  print OUT "      if (max<a) max = a;\n";
}
print OUT <<EOM;
    }
    printf("max mc at l=%d is %g\\n",l,max);
  }
}
EOM
