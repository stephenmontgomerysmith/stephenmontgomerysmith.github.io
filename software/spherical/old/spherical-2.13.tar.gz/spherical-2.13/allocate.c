#include "spherical.h"

extern int max_order;

void allocate(COMPLEX **x) {
  *x = malloc(sizeof(COMPLEX)*length);
  memset(*x,0,sizeof(COMPLEX)*length);
}

void allocate_many(COMPLEX **x, int m) {
  *x = malloc(sizeof(COMPLEX)*length*m);
}
