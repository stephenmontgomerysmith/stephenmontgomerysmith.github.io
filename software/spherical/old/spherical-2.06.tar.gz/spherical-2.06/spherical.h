#include <complex.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>

#ifdef USE_COMPLEX_DOUBLE
#define COMPLEX complex double
#else
#define COMPLEX complex
#endif

/*
 * psi[ind(l,m)] represents the Y_l^m spherical harmonic coefficient of psi.
*/
#define ind(l,m) ((l)*(l)/4+(m))

/* 
 * Y_l^(-m) = (-1)^m conj(Y_l^m)
 */
#define index(v,l,m) ( \
  ((l)>max_order) ? 0 : \
  (abs(m)>(l))    ? 0 : \
  ((m)>=0)        ? v[ind(l,m)] : \
  ((m)%2)         ? -conj(v[ind(l,-(m))]) : \
                    conj(v[ind(l,-(m))]) )

#define length ind(max_order+2,0)

void ode_adams_bash_2_initialise();
void ode_adams_bash_2_solve(double *t, COMPLEX *x, double h,
                            void derivs(double t, COMPLEX *x, COMPLEX *diffx));
void compute_psidot(COMPLEX* psidot, COMPLEX* psi);
void compute_psidot_initialize(int nr_threads);
void compute_psidot_koch(COMPLEX* psidot, COMPLEX* psi);
void compute_psidot_koch_initialize(int nr_threads);
void compute_psidot_dd(COMPLEX* psidot, COMPLEX* psi);
void compute_psidot_dd_initialize(int nr_threads);
void compute_psidot_dd_2(COMPLEX* psidot, COMPLEX* psi);
void compute_psidot_dd_2_initialize(int nr_threads);
void compute_psidot_fd(COMPLEX* psidot, COMPLEX* psi);
void compute_lap_psi(COMPLEX* lap_psi, COMPLEX* psi);
void compute_lap_psi_initialize(int nr_threads);
void tensor2(COMPLEX *psi, double a[3][3]);
void tensor4(COMPLEX *psi, double a[3][3][3][3]);
void tensor6(COMPLEX *psi, double a[3][3][3][3][3][3]);
void set_job_to(int *job, int val);
void wait_job_until(int *job, int val);
void start_background_job(void*(*job)(void*), int job_nr);
void allocate(COMPLEX **x);
void allocate_many(COMPLEX **x, int m);
double param_bool(char *p);
double param_int(char *p);
double param_double(char *p);
int param_choice(char *p, ...);
void print_parameters(FILE *sout);
void set_param_filename(char *f);
void set_param_verbose_level(int v);
