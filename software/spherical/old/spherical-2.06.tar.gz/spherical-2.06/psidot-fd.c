#include "spherical.h"

extern double gamm[3][3];
extern double normgamma;
extern double C1, C2;
extern COMPLEX *lap_psi;
extern double alpha, beta;
extern max_order;

void compute_psidot_fd(COMPLEX* psidot, COMPLEX* psi) {
  int i,j;
  double a2[3][3];
  double s;
  double Dr2;
  int l,m;
  double lap_p;

  tensor2(psi,a2);
  s = 0;
  for (i=0;i<3;i++) for (j=0;j<3;j++) s += a2[i][j]*gamm[i][j];
  Dr2 = pow(normgamma,1-beta)*pow(fabs(s),beta);

  for (l=0;l<=max_order;l+=2) {
    lap_p = pow(l*l+l,alpha/2);
    for (m=0;m<=l;m++) {
      psidot[ind(l,m)] -= (C1*Dr2 + C2*normgamma)*lap_p*psi[ind(l,m)];
    }
  }
}
