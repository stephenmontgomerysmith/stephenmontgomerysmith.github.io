#include "fec.h"

void reset(double *X) {
  double b2[9];
  double evec[9];
  double b2eval[3];
  double a2[9];

  b2[0*3+0] = X[B11];
  b2[0*3+1] = b2[1*3+0] = X[B12];
  b2[0*3+2] = b2[2*3+0] = X[B13];
  b2[1*3+1] = X[B22];
  b2[1*3+2] = b2[2*3+1] = X[B23];
  b2[2*3+2] = (1+pow(X[B13],2)*X[B22]-2*X[B12]*X[B13]*X[B23]+X[B11]*pow(X[B23],2))
              /(X[B11]*X[B22]-pow(X[B12],2));

  diagonalize_sym(3, b2, b2eval, evec);

  if (fabs(b2eval[0]-b2eval[1]) + fabs(b2eval[0]-b2eval[2]) + fabs(b2eval[1]-b2eval[2]) < 3e-2) {
    double c1 = b2eval[0]-1;
    double c2 = b2eval[1]-1;
    double c3 = b2eval[2]-1;

#define calc_a_three_close(c1,c2,c3) 0.3333333333333333 \
   - (3*c1)/10. - c2/10. - c3/10. \
   +(15*pow(c1,2))/56. + (3*c1*c2)/28. + (3*pow(c2,2))/56. + \
    (3*c1*c3)/28. + (c2*c3)/28. + (3*pow(c3,2))/56. \
   -(35*pow(c1,3))/144. - (5*pow(c1,2)*c2)/48. - \
    (c1*pow(c2,2))/16. - (5*pow(c2,3))/144. - \
    (5*pow(c1,2)*c3)/48. - (c1*c2*c3)/24. - (pow(c2,2)*c3)/48. - \
    (c1*pow(c3,2))/16. - (c2*pow(c3,2))/48. - (5*pow(c3,3))/144. \
   +(315*pow(c1,4))/1408. + (35*pow(c1,3)*c2)/352. + \
    (45*pow(c1,2)*pow(c2,2))/704. + (15*c1*pow(c2,3))/352. + \
    (35*pow(c2,4))/1408. + (35*pow(c1,3)*c3)/352. + \
    (15*pow(c1,2)*c2*c3)/352. + (9*c1*pow(c2,2)*c3)/352. + \
    (5*pow(c2,3)*c3)/352. + (45*pow(c1,2)*pow(c3,2))/704. + \
    (9*c1*c2*pow(c3,2))/352. + (9*pow(c2,2)*pow(c3,2))/704. + \
    (15*c1*pow(c3,3))/352. + (5*c2*pow(c3,3))/352. + \
    (35*pow(c3,4))/1408.

    memset(a2,0,sizeof(a2));
    a2[0*3+0] = calc_a_three_close(c1,c2,c3);
    a2[1*3+1] = calc_a_three_close(c2,c1,c3);
    a2[2*3+2] = calc_a_three_close(c3,c1,c2);
  }
#define else_if_two_close(arg0,arg1,arg2) \
  else if (fabs(b2eval[arg0]-b2eval[arg1]) < 1e-2) { \
    double b0 = 0.5*(b2eval[arg0]+b2eval[arg1]); \
    double e = 0.5*(b2eval[arg0]-b2eval[arg1]); \
    double b3 = b2eval[arg2]; \
    double I[7]; \
    int n; \
    I[1] = (b0>b3) ? \
           2./sqrt(b0-b3)*acos(sqrt(b3/b0)) : \
           2./sqrt(b3-b0)*acosh(sqrt(b3/b0)); \
    for (n=1;n<6;n++) \
      I[n+1] = (2*n-1)/2./n/(b0-b3)*I[n] - sqrt(b3)/n/pow(b0,n)/(b0-b3); \
    memset(a2,0,sizeof(a2)); \
    a2[arg0*3+arg0] = 1./2*I[2] - 1./2*I[3]*e + 3./4*I[4]*e*e \
                      - 3./4*I[5]*e*e*e + 15./16*I[6]*e*e*e*e; \
    a2[arg1*3+arg1] = 1./2*I[2] + 1./2*I[3]*e + 3./4*I[4]*e*e \
                      + 3./4*I[5]*e*e*e + 15./16*I[6]*e*e*e*e; \
    a2[arg2*3+arg2] = 1 - a2[arg0*3+arg0] - a2[arg1*3+arg1]; \
  }
  else_if_two_close(0,1,2)
  else_if_two_close(0,2,1)
  else_if_two_close(1,2,0)
  else {
    return;
  }

  reverse_rotate(a2,evec);

  X[A11] = a2[0*3+0];
  X[A12] = a2[0*3+1];
  X[A13] = a2[0*3+2];
  X[A22] = a2[1*3+1];
  X[A23] = a2[1*3+2];
}
