/*
 * Copyright (c) 1999 Stephen J Montgomery-Smith
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Stephen J Montgomery-Smith
 *      and his contributors.
 * 4. Neither the name of Stephen J Montgomery-Smith nor the names of his 
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL STEPHEN J MONTGOMERY-SMITH OR HIS 
 * CONTRIBUTORS OR HIS EMPLOYERS OR HIS FAMILY OR HIS FRIENDS BE LIABLE FOR ANY 
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

/* calibrate-0.0.1 */

#include <machine/joystick.h>
#include <fcntl.h>
#include <stdio.h>
#include <ncurses.h>
#include <stdlib.h>

#define NR_JOYSTICKS 2

int main() {
  int fd,id,answer;
  struct joystick joystate;
  int minx,maxx,miny,maxy,centerx,centery;
  FILE *joyfile;
  char joyfname[1024],*home;

  home = getenv("HOME");
  if (home == NULL)
  {
    printf("Cannot find environment variable $HOME\n");
    exit(1);
  }

  initscr();
  noecho();

  for (id=0;id<NR_JOYSTICKS;id++)
  {
    nocbreak();
    cbreak();
    printf("Would you like to calibrate joystick %d (/dev/joy%d) ? (y/n)",id,id);
    fflush(stdout);
    do {
      answer = getch();
      if (answer != 'n' && answer != 'N' && answer != 'y' && answer != 'Y')
      {
        printf("\nPress y or n");
        fflush(stdout);
      }
    } while (answer != 'n' && answer != 'N' && answer != 'y' && answer != 'Y');
    printf("\n");
    fflush(stdout);
    if (answer == 'y' || answer == 'Y')
    {
      sprintf(joyfname,"/dev/joy%d",id);
      fd = open (joyfname, O_RDONLY, 0);
      if (fd >= 0)
        read (fd,&joystate,sizeof (struct joystick));
      if (fd == -1 || joystate.x < -1000000000)
      {
        printf("Joystick %d not found\n",id);
        fflush(stdout);
      }
      else
      {
        minx = maxx = joystate.x;
        miny = maxy = joystate.y;
        halfdelay(1);
        printf("Wiggle joystick %d - press button 1 or 2 or a key when done\n",id);
        fflush(stdout);
        do {
          read (fd,&joystate,sizeof (struct joystick));
          if (minx > joystate.x) minx = joystate.x;
          if (maxx < joystate.x) maxx = joystate.x;
          if (miny > joystate.y) miny = joystate.y;
          if (maxy < joystate.y) maxy = joystate.y;
        } while (joystate.b1 == 0 && joystate.b2 == 0 && getch()==ERR);
        printf("Center joystick %d - press a key when done\n",id);
        fflush(stdout);
        nocbreak();
        cbreak();
        getch();
        read (fd,&joystate,sizeof (struct joystick));
        centerx = joystate.x;
        centery = joystate.y;
        sprintf(joyfname,"%s/.joy%drc",home,id);
        joyfile = fopen(joyfname,"w");
        if (joyfile == NULL)
        {
          printf("Unable to open file %s\n",joyfname);
          fflush(stdout);
        }
        else
        {
          fprintf(joyfile,"%d\n%d %d %d\n%d %d %d\n",
                  2,minx,centerx,maxx,miny,centery,maxy);
          if (fclose(joyfile) != 0)
            printf("Unable to close file %s\n",joyfname);
          else
            printf("Data successfully written to file %s\n",joyfname);
          fflush(stdout);
        }
      }
      if (fd >= 0) close (fd);
    }
  }
}
