/*
 * Program euler2d.c
 *
 * Copywrite Stephen Montgomery-Smith (2000)
 * All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted,
 * provided that the above copyright notice appear in all copies and that
 * both that copyright notice and this permission notice appear in
 * supporting documentation.
 *
 * This file is provided AS IS with no warranties of any kind.  The author
 * shall have no liability with respect to the infringement of copyrights,
 * trade secrets or any patents by this file or any part thereof.  In no
 * event will the author be liable for any lost revenue or profits or
 * other special, indirect and consequential damages.
 *
 */

/*
 * If you have ideas to improve this program, please tell me at
 * stephen@math.missouri.edu
 *
 */

#include <sys/time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <strings.h>
#include <string.h>
#include <GL/glut.h>

#define screen_width 1000
#define number_of_points 300
#define number_of_vortex_points 20
#define delta_t 0.001
/* number of iterations to compute before displaying */
#define showinterval 10
/* The next two explain how the points are displayed, giving the length
   of their tails. */
#define showtail_interval 1
#define showtail_len 50

/* total number of points */ 
#define N (number_of_points+number_of_vortex_points)
#define Nvortex number_of_vortex_points

#define PI 3.1415926535897932385

#define length 2*N

int go = 1;
int cross = 0;
int show_vortex_points = 0;
int show_boundary=1;
GLuint boundary;

/* 
x[2n+0] = x1 coord for nth point
x[2n+1] = x2 coord for nth point
w[n] = vorticity at nth point
*/

double x[2*N];
double w[N], diffx[2*N];
double t;

GLfloat showtail_x[showtail_len*2*N];
GLfloat color[3*N*showtail_len];

double olddiffs[3][length];
int olddiffindex[3] = {0,1,2};
#define olddiff(i) olddiffs[olddiffindex[i]]
int iter=0;

void runge_kutta_4(double *x, double t, double h,
                   void derivs(double t, double *x, double *diffx))
{
  double k1[length], k2[length], k3[length], k4[length],
         diffx[length],
         tempx[length];
  int i;

  derivs(t,x,diffx);
  for (i=0;i<length;i++) k1[i] = h*diffx[i];
  for (i=0;i<length;i++) tempx[i] = x[i] + k1[i]/2;
  derivs(t+h/2,tempx,diffx);
  for (i=0;i<length;i++) k2[i] = h*diffx[i];
  for (i=0;i<length;i++) tempx[i] = x[i] + k2[i]/2;
  derivs(t+h/2,tempx,diffx);
  for (i=0;i<length;i++) k3[i] = h*diffx[i];
  for (i=0;i<length;i++) tempx[i] = x[i] + k2[i];
  derivs(t+h,tempx,diffx);
  for (i=0;i<length;i++) k4[i] = h*diffx[i];
  for (i=0;i<length;i++) x[i] += (k1[i]+2*k2[i]+2*k3[i]+k4[i])/6;
}

void pushdiff(double *diff)
{
  int i,t;

  t = olddiffindex[2];
  for (i=1;i>=0;i--)
    olddiffindex[i+1] = olddiffindex[i];
  olddiffindex[0] = t;
  memcpy(olddiff(0),diff,sizeof(double)*length);
}

void error_predictor(double *x, double t, double h,
                     void derivs(double t, double *x, double *diffx))
{
  int i;
  double diffx[length];

  for (i=0;i<length;i++)
    x[i] += h/12 * (23*olddiff(0)[i]-16*olddiff(1)[i]+5*olddiff(2)[i]);
  derivs(t+h,x,diffx);
  for (i=0;i<length;i++)
    x[i] += h/24 * (9*diffx[i]+19*olddiff(0)[i]-5*olddiff(1)[i]+olddiff(2)[i]);
}

void ode_solve(double *x, double *diffx, double t, double h,
               void derivs(double t, double *x, double *diffx))
{
  if (iter <= 3)
    runge_kutta_4(x,t,h,derivs);
  else
    error_predictor(x,t,h,derivs);
  derivs(t,x,diffx);
  pushdiff(diffx);
  iter++;
}

void calc_u(double z1, double z2, 
            double a1, double a2,
            double *u1, double *u2, int self)
{
  double na,za1,za2,nza,as1,as2,zas1=0.0,zas2=0.0,nzas=0.0;
  int azero;

  na = a1*a1+a2*a2;
  azero = na < 1e-20;
  za1 = z1 - a1;
  za2 = z2 - a2;
  nza = za1*za1+za2*za2;
  if (!azero)
  {
/* as is the reflection of a in the unit sphere */
    as1 = a1/na;
    as2 = a2/na;
    zas1 = z1 - as1;
    zas2 = z2 - as2;
    nzas = zas1*zas1+zas2*zas2;
  }
  *u1 = (self?0.0:(-za1/nza)) + (azero?0.0:(zas1/nzas));
  *u2 = (self?0.0:(-za2/nza)) + (azero?0.0:(zas2/nzas));
}

void derivs(double t, double *x, double *diffx)
{
  int i,j;
  double u1,u2;

  memset(diffx,0,sizeof(double)*2*N);

  for (i=0;i<N;i++) for (j=0;j<Nvortex;j++) if (w[j] != 0.0)
  {
    calc_u(x[2*i+0],x[2*i+1],x[2*j+0],x[2*j+1],&u1,&u2,i==j);
    diffx[2*i+0] += u2*w[j];
    diffx[2*i+1] -= u1*w[j];
  }
}

double rrandom()
{
  return random()/2.147483e9;
}

void random_init()
{
  int i;
  double r, theta;

  for (i=0;i<Nvortex;i++)
  {
    r = sqrt(rrandom());
    theta = rrandom()*2*PI;
    x[2*i+0]=r*cos(theta);
    x[2*i+1]=r*sin(theta);
    w[i]=i<Nvortex/2 ? 1.0/Nvortex : -1.0/Nvortex;
  }
}

void circle_init()
{
  int i;

  for (i=0;i<Nvortex;i++)
  {
    x[2*i+0]=0.5*cos((double)i/Nvortex*2*PI);
    x[2*i+1]=0.5*sin((double)i/Nvortex*2*PI);
    w[i]=(i<Nvortex/2) ? 1.0/Nvortex : -1.0/Nvortex;
    w[i]=1.0/Nvortex;
  }
}

void two_circle_init()
{
  int i;

  for (i=0;i<Nvortex/2;i++)
  {
    x[2*i+0]=0.25*cos((double)i/Nvortex*4*PI);
    x[2*i+1]=0.5+0.25*sin((double)i/Nvortex*4*PI);
    w[i]=1.0/Nvortex;
  }

  for (i=Nvortex/2;i<Nvortex;i++)
  {
    x[2*i+0]=0.25*cos((double)i/Nvortex*4*PI);
    x[2*i+1]=-0.5+0.25*sin((double)i/Nvortex*4*PI);
    w[i]=-1.0/Nvortex;
  }
}

void four_circle_init()
{
  int i,j;

  for (j=0;j<4;j++) for (i=j*Nvortex/4;i<(j+1)*Nvortex/4;i++)
  {
    x[2*i+0]=0.5*cos((double)j/4*2*PI) + 0.1*cos((double)i/Nvortex*8*PI);
    x[2*i+1]=0.5*sin((double)j/4*2*PI) + 0.1*sin((double)i/Nvortex*8*PI);
    w[i]=j%2 ? 1.0/Nvortex : -1.0/Nvortex;
  }
}

void two_line_init()
{
  int i;

  for (i=0;i<Nvortex/2;i++)
  {
    x[2*i+0]=(double)i/Nvortex-0.25;
    x[2*i+1]=0.1+0.02*rrandom();
    w[i]=1.0/Nvortex;
  }

  for (i=Nvortex/2;i<Nvortex;i++)
  {
    x[2*i+0]=(double)(i-Nvortex/2)/Nvortex-0.25;
    x[2*i+1]=-0.1-0.02*rrandom();
    w[i]=-1.0/Nvortex;
  }
}

void two_point_init()
{
  int i;

  for (i=0;i<Nvortex/2;i++)
  {
    x[2*i+0]=-0.6+0.02*(rrandom()-0.5);
    x[2*i+1]=0.1+0.02*rrandom();
    w[i]=1.0/Nvortex;
  }

  for (i=Nvortex/2;i<Nvortex;i++)
  {
    x[2*i+0]=-0.6+0.02*(rrandom()-0.5);
    x[2*i+1]=-0.1-0.02*rrandom();
    w[i]=-1.0/Nvortex;
  }
}

void random_all()
{
  int i, j;
  double r, theta;
  float minc, maxc, f;

  for (i=0;i<N;i++)
  {
    r = sqrt(rrandom());
    theta = rrandom()*2*PI;
    x[2*i+0]=r*cos(theta);
    x[2*i+1]=r*sin(theta);
    w[i]=0.0;

    if (i<Nvortex)
    {
      color[3*i*showtail_len+0]=1.0;
      color[3*i*showtail_len+1]=1.0;
      color[3*i*showtail_len+2]=1.0;
    }
    else
    {
      while(1)
      {
        color[3*i*showtail_len+0] = rrandom();
        color[3*i*showtail_len+1] = rrandom();
        color[3*i*showtail_len+2] = rrandom();
        minc=maxc=color[3*i*showtail_len+0];
        if (color[3*i*showtail_len+1]>maxc) maxc=color[3*i*showtail_len+1];
        if (color[3*i*showtail_len+2]>maxc) maxc=color[3*i*showtail_len+2];
        if (color[3*i*showtail_len+1]<minc) minc=color[3*i*showtail_len+1];
        if (color[3*i*showtail_len+2]<minc) minc=color[3*i*showtail_len+2];
        if (maxc-minc>1e-5)
        {
          color[3*i*showtail_len+0] = (color[3*i*showtail_len+0]-minc)/(maxc-minc);
          color[3*i*showtail_len+1] = (color[3*i*showtail_len+1]-minc)/(maxc-minc);
          color[3*i*showtail_len+2] = (color[3*i*showtail_len+2]-minc)/(maxc-minc);
          break;
        }
      }
    }
    for(j=1;j<showtail_len;j++)
    {
      f=(float)(showtail_len-j)/(float)(showtail_len);
      color[3*i*showtail_len+3*j+0] = f*color[3*i*showtail_len+0];
      color[3*i*showtail_len+3*j+1] = f*color[3*i*showtail_len+1];
      color[3*i*showtail_len+3*j+2] = f*color[3*i*showtail_len+2];
    }
  }
  glEnableClientState(GL_COLOR_ARRAY);
  glColorPointer(3,GL_FLOAT,0,color);
}

void diffx_init()
{
  memset(diffx,0,sizeof(double)*length);
}

void showtail_x_init()
{
  int i,j;

  for (i=0;i<showtail_len;i++) for(j=0;j<N;j++)
  {
    showtail_x[2*showtail_len*j+i*2+0] = x[2*j+0];
    showtail_x[2*showtail_len*j+i*2+1] = x[2*j+1];
  }
}

void initialise()
{
  struct timeval tv;
  struct timezone tz;

  gettimeofday(&tv,&tz);
  srandom(tv.tv_usec+1000000*tv.tv_sec);

  t=0.0;

  random_all();
  two_point_init();
  diffx_init();
  showtail_x_init();
}

void getdata()
{
  int i,j;
  double mag;

  do
  {
    if (iter % showtail_interval == 0)
      for (i=showtail_len-1;i>0;i--) for(j=0;j<N;j++)
      {
        showtail_x[2*showtail_len*j+2*i+0] = showtail_x[2*showtail_len*j+2*(i-1)+0];
        showtail_x[2*showtail_len*j+2*i+1] = showtail_x[2*showtail_len*j+2*(i-1)+1];
      }
    ode_solve(x,diffx,t,delta_t,derivs);
    t=t+delta_t;
    for (i=0;i<N;i++)
    {
      mag = x[2*i+0]*x[2*i+0] + x[2*i+1]*x[2*i+1];
      if (mag > 1.0)
      {
        x[2*i+0] /= sqrt(mag);
        x[2*i+1] /= sqrt(mag);
      }
    }
    if (iter % showtail_interval == 0)
      for(j=0;j<N;j++)
      {
        showtail_x[2*showtail_len*j+0] = x[2*j+0];
        showtail_x[2*showtail_len*j+1] = x[2*j+1];
      }
  } while (iter % showinterval != 0);
}

void init()
{
  int i;
  double x1,x2;

  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel (GL_FLAT);
  gluOrtho2D(0.0,1.0,0.0,1.0);

  boundary = glGenLists(1);
  glNewList(boundary,GL_COMPILE);
  glColor3f (1.0, 1.0, 1.0);
  glBegin(GL_LINE_LOOP);
  for (i=0;i<100;i++)
  {
    x1=cos((double)i/100*2*PI);
    x2=sin((double)i/100*2*PI);
    glVertex2f(x1,x2);
  }
  glEnd();
  glEndList();

  initialise();
}

void reshape(int w, int h)
{
  if (h>w)
    glViewport (0, (h-w)/2, w, w);
  else
    glViewport ((w-h)/2, 0, h, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(-1.01, 1.01, -1.01, 1.01, -1.0, 1.0);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void display()
{
  int i;
  double x1,x2;

  if (go) cross = 0;

  glClear (GL_COLOR_BUFFER_BIT);

  if (cross)
  {
    for (i=0;i<N;i++)
    {
      glColor3f(color[3*i*showtail_len+0],color[3*i*showtail_len+1],color[3*i*showtail_len+2]);
      glBegin(GL_LINES);
      x1 = x[2*i+0];
      x2 = x[2*i+1];
      glVertex2f(x1+0.01,x2+0.01);
      glVertex2f(x1-0.01,x2-0.01);
      glVertex2f(x1+0.01,x2-0.01);
      glVertex2f(x1-0.01,x2+0.01);
      glEnd();
    }
  }
  else
  {
    glEnableClientState(GL_VERTEX_ARRAY);
    glVertexPointer(2,GL_FLOAT,0,showtail_x);
    for (i=0;i<N;i++)
    {
      if (w[i] == 0.0 || show_vortex_points)
      {
        glDrawArrays(GL_LINE_STRIP,i*showtail_len,showtail_len);
      }
    }
  }

  if (show_boundary)
    glCallList(boundary);

  glutSwapBuffers();

}

void idle()
{ 
  getdata();
  glutPostRedisplay();
}

void keyboard(unsigned char key, int xcoord, int ycoord)
{
  if (!go && key >= '1' && key <= '9')
  {
    random_all();
    diffx_init();
    iter = 0;
    t = 0.0;
  }
  switch(key)
  { 
    case 's':
      go^=1;
      if (go)
        glutIdleFunc(idle);
      else
        glutIdleFunc(NULL);
      break;
    case 'v':
      show_vortex_points^=1;
      break;
    case 'b':
      show_boundary^=1;
      break;
    case 'q':
      exit(0);
    case '1':
      if (!go)
        random_init();
      break;
    case '2':
      if (!go)
        two_line_init();
      break;
    case '3':
      if (!go)
        circle_init();
      break;
    case '4':
      if (!go)
        two_circle_init();
      break;
    case '5':
      if (!go)
        four_circle_init();
      break;
    case '6':
      if (!go)
        two_point_init();
      break;
  }
  if (!go && key >= '1' && key <= '9')
  {
    showtail_x_init();
    cross = 1;
  }
  glutPostRedisplay();
}



int main(int argc, char** argv)
{
  glutInit(&argc, argv);
  glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
  glutInitWindowSize (screen_width, screen_width); 
  glutInitWindowPosition (0, 0);
  glutCreateWindow ("2 Dimensional Euler");
  init ();
  glutDisplayFunc(display); 
  glutReshapeFunc(reshape);
  glutKeyboardFunc(keyboard);
  glutIdleFunc(idle);
  glutMainLoop();
  return 0;
}
