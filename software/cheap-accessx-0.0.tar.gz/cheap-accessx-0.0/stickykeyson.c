#include<X11/Xlib.h>
#include<X11/XKBlib.h>

main()
{
  Display *display;
  unsigned int auto_ctrls, auto_values;

  display = XOpenDisplay(NULL);

/*printf("%s\n",XDisplayString(display));*/

/*XkbGetAutoResetControls(display,&auto_ctrls,&auto_values);*/

/*printf("%d %d\n",auto_ctrls,auto_values);*/

  auto_ctrls = XkbStickyKeysMask;
  auto_values = XkbStickyKeysMask;
  XkbSetAutoResetControls(display,XkbStickyKeysMask,&auto_ctrls,&auto_values);
}
